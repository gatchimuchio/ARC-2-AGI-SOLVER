from __future__ import annotations
Grid = list[list[int]]

def clone_grid(grid: Grid) -> Grid:
    return [row[:] for row in grid]

def grid_shape(grid: Grid) -> tuple[int, int]:
    return len(grid), len(grid[0]) if grid else 0

def superposed_cell_value(runs: list[dict[str, int]], distance: int, background: int) -> int:
    for run in runs:
        if distance % run["length"] == 0:
            return run["color"]
    return background
