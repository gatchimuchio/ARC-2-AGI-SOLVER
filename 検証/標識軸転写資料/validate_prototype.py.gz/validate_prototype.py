"""Teacher-only and synthetic validation; no canonical tasks, queries, or scoring."""
from __future__ import annotations

import copy
import hashlib
import importlib.util
import json
import sys
from collections import Counter
from pathlib import Path
from unittest.mock import patch

C = Path(__file__).resolve().parent
OLD = C.parent
ROOT = C.parent.parent.parent
sys.path.insert(0, str(ROOT / "arc2-second-half"))
spec = importlib.util.spec_from_file_location("candidate010", C / "prototype.py")
core = importlib.util.module_from_spec(spec)
spec.loader.exec_module(core)

IMMUTABLE = {
    "00-contract-before-fit.json": "30c8e8731894f61f10357e6f4d1b203b4130b67536dfc0b8329c3c8cb57e90ca",
    "scope.json": "08263d4a4a29d559261178510c9a26c5ee2a09951a150be379ff52adf779cf8a",
    "teacher-transform-facts.json": "c8e204e144b5c2cffb20d60058ba540cedf92e70638afafca31ace9752044fe5",
    "teachers.json": "0f084b103a8febe171eca2e1960cc0d87ac495f3e554ee50f9fe0fa32d17085b",
}


def independent_transform(grid, name):
    """Explicit coordinate oracle, independent of existing list/zip D4 code."""
    h, w = len(grid), len(grid[0])
    swap = name in ("rot90", "rot270", "transpose", "anti_transpose")
    out = [[None] * (h if swap else w) for _ in range(w if swap else h)]
    for r in range(h):
        for c in range(w):
            nr, nc = {
                "identity": (r, c), "rot90": (c, h - r - 1),
                "rot180": (h - r - 1, w - c - 1), "rot270": (w - c - 1, r),
                "flip_h": (r, w - c - 1), "flip_v": (h - r - 1, c),
                "transpose": (c, r), "anti_transpose": (w - c - 1, h - r - 1),
            }[name]
            out[nr][nc] = grid[r][c]
    return out


def fixture(transform="identity", width=1, glyph=(5, 5), marker_shape=((0, 0),),
            sides=("top", "bottom", "left", "right"), target=(22, 22)):
    n, bg, body, marker = 30, 0, 8, 9
    walls = dict(top=2, bottom=3, left=4, right=7)
    grid = [[bg] * n for _ in range(n)]
    for r in range(n):
        for c in range(n):
            if r < width: grid[r][c] = walls["top"]
            elif r >= n-width: grid[r][c] = walls["bottom"]
            elif c < width: grid[r][c] = walls["left"]
            elif c >= n-width: grid[r][c] = walls["right"]
    gh, gw = glyph
    crop = [[bg] * (gw + 2) for _ in range(gh + 2)]
    for r in range(1, gh + 1):
        for c in range(1, gw + 1): crop[r][c] = body
    # Leave the body bounding box untouched even for a large internal marker.
    for dr, dc in marker_shape: crop[2 + dr][2 + dc] = marker
    locations = dict(top=(0, 2), bottom=(gh + 1, 2), left=(2, 0), right=(2, gw + 1))
    for side in sides:
        r, c = locations[side]
        crop[r][c] = walls[core.SIDE_TRANSFORM_MAPS[transform][side]]
    origin = (width + 2, width + 2)
    source = []
    for r, row in enumerate(crop):
        for c, value in enumerate(row):
            if value != bg:
                grid[r+origin[0]][c+origin[1]] = value
                source.append((r+origin[0], c+origin[1]))
    transformed = independent_transform(crop, transform)
    marker_cells = [(r, c) for r, row in enumerate(transformed) for c, value in enumerate(row) if value == marker]
    vr, vc = target[0]-min(r for r,c in marker_cells), target[1]-min(c for r,c in marker_cells)
    for r, c in marker_cells:
        rr, cc = r+vr, c+vc
        if 0 <= rr < n and 0 <= cc < n: grid[rr][cc] = marker
    expected = copy.deepcopy(grid)
    for r, c in source: expected[r][c] = bg
    for r, row in enumerate(transformed):
        for c, value in enumerate(row):
            if value != bg and 0 <= r+vr < n and 0 <= c+vc < n: expected[r+vr][c+vc] = value
    return grid, expected


def run():
    for name, digest in IMMUTABLE.items():
        assert hashlib.sha256((OLD/name).read_bytes()).hexdigest() == digest
    teachers = json.loads((OLD / "teachers.json").read_text())["train"]
    fit = json.loads((C / "fit-exhaustive-evidence.json").read_text())
    models = fit["retained_programs"]
    assert len(core.programs()) == 360 == len(fit["programs"])
    assert fit["completed_program_teacher_returns"] == 720
    assert len(models) == 2
    results = []
    full = (C / "synthetic-full-returns.jsonl").open("w")

    def record(name, passed, **data):
        data = dict(name=name, passed=bool(passed), **data)
        full.write(json.dumps(data, ensure_ascii=False, separators=(",", ":"))+"\n")
        full.flush()
        results.append(dict(name=name, passed=bool(passed)))

    def check_render(name, grid, p, expected, disposition="equal"):
        out, detail = core.render(grid, p)
        passed = out == expected if disposition == "equal" else out is None
        record(name, passed, grid=grid, program=p, expected=expected, output=out, detail=detail)
        return out, detail

    base = dict(body_color=8, marker_color=9, object_connectivity=4, unconstrained_axis_chirality=-1)
    for index, pair in enumerate(teachers):
        out, detail = core.consensus(pair["input"], models)
        record(f"teacher_consensus_{index}", out == pair["output"], output=out, detail=detail)

    # Every old D4 and every side transform is independently checked on a nonsquare matrix.
    matrix = [[1, 2, 3], [4, 5, 6]]
    for transform in core.SIDE_TRANSFORM_MAPS:
        got = core.transform_grid_by_name(matrix, transform)
        record("independent_D4_"+transform, got == independent_transform(matrix, transform), output=got)

    # Two constrained source axes admit all satisfying D4 independently of free sign.
    # All eight transforms, widths 1/3/4, non-square/larger glyphs, 1/2/3/5-cell markers.
    scenarios = [(1, (5, 5), ((0, 0),)), (3, (5, 7), ((0, 0), (0, 1))),
                 (4, (7, 6), ((0, 0), (1, 0), (1, 1))),
                 (1, (7, 8), ((0, 0), (0, 1), (1, 1), (2, 1), (2, 2)))]
    for transform in core.SIDE_TRANSFORM_MAPS:
        for i, (width, glyph, marker_shape) in enumerate(scenarios):
            grid, expected = fixture(transform, width, glyph, marker_shape, target=(18, 18))
            for sign in (-1, 1):
                p = dict(base, unconstrained_axis_chirality=sign)
                check_render(f"all_D4_{transform}_shape{i}_sign{sign}", grid, p, expected)

    # An underconstrained axis is a learned convention, not a geometrical implication.
    grid, expected = fixture("rot90", sides=("top",), target=(20, 20))
    plus, plus_trace = core.render(grid, dict(base, unconstrained_axis_chirality=1))
    minus, minus_trace = core.render(grid, base)
    record("one_axis_opposite_chiralities_produce_distinct_valid_grids",
           plus is not None and minus is not None and plus != minus,
           input=grid, plus=plus, minus=minus, plus_trace=plus_trace, minus_trace=minus_trace)
    out, detail = core.consensus(grid, [base, dict(base, unconstrained_axis_chirality=1)])
    record("retained_chirality_ambiguity_HOLD", out is None and detail.get("failure") == "retained_program_outputs_disagree",
           output=out, detail=detail)

    diagonal, diagonal_expected = fixture("identity", marker_shape=((0, 0), (1, 1)), target=(20, 20))
    c4, c4_trace = core.render(diagonal, base)
    c8, c8_trace = core.render(diagonal, dict(base, object_connectivity=8))
    out, detail = core.consensus(diagonal, models)
    record("teacher_unidentified_connectivities_both_retained_HOLD",
           c4 is None and c8 == diagonal_expected and out is None
           and len(detail["program_returns"]) == 2,
           input=diagonal, c4_output=c4, c4_detail=c4_trace,
           c8_output=c8, c8_detail=c8_trace, output=out, detail=detail)

    # Two real objects and two real anchors: preserve every bijection, including
    # distinct assignments that happen to produce the same complete output.
    multi, _ = fixture("identity", glyph=(3, 3), target=(20, 20))
    _, one_trace = core.render(multi, base)
    object_cells = one_trace["views"][0]["roles"]["objects"][0]["cells"]
    for r, c in object_cells: multi[r][c+10] = multi[r][c]
    multi[20][8] = 9
    out, detail = core.render(multi, base)
    record("real_two_objects_all_bijections_same_output",
           out is not None and all(len(v.get("assignments", [])) == 2 for v in detail["views"]),
           input=multi, output=out, detail=detail)
    original_assignment_render = core.render_assignment
    assignment_calls = [0]
    def one_assignment_fails(*args, **kwargs):
        output, detail = original_assignment_render(*args, **kwargs)
        assignment_calls[0] += 1
        if assignment_calls[0] % 2 == 0:
            detail["failures"].append("synthetic_complete_assignment_failure")
            return None, detail
        return output, detail
    with patch.object(core, "render_assignment", one_assignment_fails):
        out, detail = core.render(multi, base)
        record("one_failed_complete_assignment_blocks_successful_alternative",
               out is None and assignment_calls[0] == 4
               and all(v.get("failure") == "complete_assignment_failed" for v in detail["views"]),
               output=out, detail=detail, limitation="Failure injection isolates complete-assignment consensus")
    asymmetric = copy.deepcopy(multi)
    asymmetric[4][14] = 0
    out, detail = core.render(asymmetric, base)
    record("real_all_bijections_disagree_HOLD",
           out is None and all(v.get("failure") == "complete_assignment_outputs_disagree" for v in detail["views"])
           and all(len(v.get("assignments", [])) == 2 for v in detail["views"]),
           input=asymmetric, output=out, detail=detail)

    # The same two assignments across two chambers exercise chamber × anchor
    # enumeration. Mirrored side colors also retain both valid raw D4 choices.
    chambers = [[0]*30 for _ in range(30)]
    for r in range(30):
        for c in range(30):
            if r == 0: chambers[r][c] = 2
            elif r == 29: chambers[r][c] = 3
            elif c in (0, 14, 29): chambers[r][c] = 4
    for r, c in object_cells:
        value = multi[r][c]
        if value == 7: value = 4
        chambers[r][c] = value
        chambers[r][c+15] = value
    chambers[20][7] = 9
    chambers[20][22] = 9
    out, detail = core.render(chambers, base)
    record("real_multiple_chambers_preserve_all_raw_transforms",
           all(len(v["partition"]["chambers"]) == 2 and len(v["proposals"]) == 64
               and len(v.get("assignments", [])) == 8 for v in detail["views"]),
           input=chambers, output=out, detail=detail)

    # All structurally admitted views participate in consensus. Inject two
    # independently obtained, valid complete returns to isolate this guard.
    grid_for_roles, _ = fixture("identity", target=(20, 20))
    original_assignments = core.all_assignments
    role_calls = [0]
    def conflicting_role_outputs(*args, **kwargs):
        output, failure = original_assignments(*args, **kwargs)
        role_calls[0] += 1
        if role_calls[0] == 2 and output is not None:
            output = copy.deepcopy(output)
            output[15][15] = 6
        return output, failure
    with patch.object(core, "all_assignments", conflicting_role_outputs):
        out, detail = core.render(grid_for_roles, base)
        record("admitted_role_view_ambiguity_HOLD",
               out is None and detail.get("failure") == "admitted_role_outputs_disagree"
               and role_calls[0] == 2, output=out, detail=detail,
               limitation="Fault injection isolates consensus; it is not a naturally occurring partition witness")

    # Whole-scene D4 measurement of the frozen teacher-fitted programs, all outcomes retained.
    covariance = []
    for ti, pair in enumerate(teachers):
        for transform in core.SIDE_TRANSFORM_MAPS:
            transformed_input = independent_transform(pair["input"], transform)
            transformed_expected = independent_transform(pair["output"], transform)
            out, detail = core.consensus(transformed_input, models)
            item = dict(teacher=ti, transform=transform, covariant=out == transformed_expected,
                        held=out is None, input=transformed_input, expected=transformed_expected,
                        output=out, detail=detail)
            covariance.append(item)
            record(f"measured_teacher_D4_covariance_{ti}_{transform}", True, **item)
    (C / "whole-D4-covariance.json").write_text(json.dumps(covariance, ensure_ascii=False, separators=(",", ":")))
    record("chirality_all16_teacher_D4_covariant", all(x["covariant"] for x in covariance))

    # Color roles are learned program parameters: a permutation changes colors, not the geometry.
    permutation = {0: 6, 1: 8, 2: 9, 3: 0, 4: 2, 5: 3, 6: 1, 7: 4, 8: 5, 9: 7}
    for ti, pair in enumerate(teachers):
        recolored = lambda g: [[permutation[v] for v in row] for row in g]
        remapped_models = [dict(p, body_color=permutation[p["body_color"]],
                                marker_color=permutation[p["marker_color"]]) for p in models]
        out, detail = core.consensus(recolored(pair["input"]), remapped_models)
        record(f"palette_equivariance_{ti}", out == recolored(pair["output"]), output=out, detail=detail)

    grid, expected = fixture("identity", target=(20, 20))
    # A label in the body rectangle and a corner label both violate complete outside-face ownership.
    inside_label = copy.deepcopy(grid); inside_label[7][7] = 6
    check_render("label_inside_body_HOLD", inside_label, base, None, "hold")
    corner_label = copy.deepcopy(grid); corner_label[3][3] = 6
    check_render("unowned_corner_component_HOLD", corner_label, base, None, "hold")
    side_conflict = copy.deepcopy(grid); side_conflict[3][6] = 6
    check_render("inconsistent_label_side_HOLD", side_conflict, base, None, "hold")
    unmatched_label = copy.deepcopy(grid); unmatched_label[3][5] = 6
    check_render("unmatched_label_HOLD", unmatched_label, base, None, "hold")
    extra_anchor = copy.deepcopy(grid); extra_anchor[25][5] = 9
    check_render("unused_anchor_HOLD", extra_anchor, base, None, "hold")
    missing_anchor = copy.deepcopy(grid); missing_anchor[20][20] = 0
    check_render("unmatched_object_HOLD", missing_anchor, base, None, "hold")
    marker_shape = copy.deepcopy(grid); marker_shape[20][21] = 9
    check_render("marker_shape_mismatch_HOLD", marker_shape, base, None, "hold")
    foreign = copy.deepcopy(grid); foreign[24][6] = 6
    check_render("unowned_foreground_HOLD", foreign, base, None, "hold")
    no_labels, _ = fixture("identity", sides=(), target=(20, 20))
    check_render("zero_label_axes_out_of_scope_HOLD", no_labels, base, None, "hold")
    oob, _ = fixture("identity", target=(1, 1))
    _, oob_trace = check_render("destination_bar_or_OOB_HOLD", oob, base, None, "hold")
    nearwall, _ = fixture("identity", target=(2, 2))
    check_render("nearwall_destination_HOLD", nearwall, base, None, "hold")

    invalid_grids = [[], [[]], [[0], [0, 1]], [[True]], [[10]], [[0]*31], [[0]]*31]
    for i, bad in enumerate(invalid_grids):
        check_render(f"malformed_grid_{i}", bad, base, None, "hold")
    check_render("mode_tie_HOLD", [[0, 1], [1, 0]], base, None, "hold")
    for i, bad in enumerate([{}, dict(base, body_color=9), dict(base, body_color=True),
                             dict(base, object_connectivity=5), dict(base, unconstrained_axis_chirality=0)]):
        check_render(f"malformed_program_{i}", grid, bad, None, "hold")
    for i, bad_output in enumerate([None, [[False]], [], [[10]], [[0], [0, 1]]]):
        retained, detail = core.fit([dict(input=grid, output=bad_output)])
        record(f"malformed_teacher_output_{i}_cannot_fit",
               not retained and detail.get("failure") == "invalid_teacher_pair_or_grid",
               retained=retained, detail=detail)
    for i, bad_teachers in enumerate([None, [], [None], [dict(input=grid)],
                                     [dict(input=grid, output=grid, test=grid)]]):
        retained, detail = core.fit(bad_teachers)
        record(f"malformed_teacher_container_{i}_cannot_fit", not retained,
               retained=retained, detail=detail)

    # Complete assignment enumeration independent of the parser: all permutations,
    # all duplicate-anchor rejection prefixes, same-color overlaps, and failures.
    _, trace = core.render(grid, base)
    view = trace["views"][0]
    roles = view["roles"]
    proposal = next(x for x in view["proposals"] if x["admitted"])
    roles2 = copy.deepcopy(roles)
    roles2["objects"].append(dict(roles2["objects"][0], index=1))
    roles2["anchors"].append(dict(roles2["anchors"][0], index=1))
    proposals = [dict(proposal, index=i*2+j, object=i, anchor=j)
                 for i in range(2) for j in range(2)]
    assignments = {}
    out, failure = core.all_assignments(grid, 0, base, view["partition"], roles2, proposals, assignments)
    record("all_bijections_enumerated_and_same_color_overlap_HOLD",
           out is None and failure == "complete_assignment_failed"
           and len(assignments["assignments"]) == 2 and len(assignments["assignment_rejections"]) == 2
           and all("moved_object_overlap_including_same_color" in x["detail"]["failures"]
                   for x in assignments["assignments"]),
           output=out, failure=failure, detail=assignments)

    # Injected raw faults directly test the renderer's safety invariants.
    for name, mutator, expect in [
        ("same_color_overlap", lambda x: x["footprint"].append(x["footprint"][0]), "moved_object_overlap_including_same_color"),
        ("OOB", lambda x: x["footprint"].append((-1, -1, 8)), "out_of_bounds"),
        ("fixed_bar", lambda x: x["footprint"].append((0, 0, 2)), "fixed_bar_overlap"),
        ("conservation", lambda x: x["footprint"].pop(), "color_count_conservation_failed"),
    ]:
        raw = copy.deepcopy(proposal)
        mutator(raw)
        out, detail = core.render_assignment(grid, 0, base, view["partition"], roles, [raw])
        record("raw_assignment_"+name, out is None and expect in detail["failures"], output=out, detail=detail)

    # All models must execute even when an earlier retained program holds.
    out, detail = core.consensus(grid, [dict(base, body_color=1), base])
    record("retained_failure_does_not_short_circuit_later_model",
           out is None and len(detail["program_returns"]) == 2
           and detail["program_returns"][1]["output"] is not None, output=out, detail=detail)

    # Propagate resource exceptions, with the complete finished prefix and current trace.
    original_transform = core.transform_grid_by_name
    for exception_type in (MemoryError, RecursionError, TimeoutError):
        calls = [0]
        def interrupted_transform(*args, **kwargs):
            calls[0] += 1
            if calls[0] == 3: raise exception_type("synthetic resource failure")
            return original_transform(*args, **kwargs)
        with patch.object(core, "transform_grid_by_name", interrupted_transform):
            try:
                core.render(grid, base)
                record("resource_render_"+exception_type.__name__, False)
            except exception_type as exc:
                partial = exc.partial_full_return
                record("resource_render_"+exception_type.__name__,
                       partial["resource_exception"] == exception_type.__name__
                       and len(partial["views"][0]["proposals"]) == 2,
                       partial_full_return=partial)
    original_render = core.render
    for operation in ("fit", "consensus"):
        calls = [0]
        def interrupted_render(*args, **kwargs):
            calls[0] += 1
            if calls[0] == 2:
                exc = MemoryError("synthetic second render failure")
                exc.partial_full_return = {"inner_completed_prefix": "synthetic"}
                raise exc
            return original_render(*args, **kwargs)
        with patch.object(core, "render", interrupted_render):
            try:
                core.fit(teachers) if operation == "fit" else core.consensus(grid, models)
                record("resource_"+operation+"_partial_returns", False)
            except MemoryError as exc:
                partial = exc.partial_full_return
                count = partial.get("completed_program_teacher_returns", len(partial.get("program_returns", [])))
                record("resource_"+operation+"_partial_returns", count == 1,
                       partial_full_return=partial)

    # Regression for interrupted inner stages: these used to lose the entire
    # stage because their records were appended only after a successful return.
    with patch.object(core, "intervals", side_effect=MemoryError("interrupt band chamber construction")):
        try:
            core.render(grid, base)
            record("resource_band_stage_keeps_partial_decisions", False)
        except MemoryError as exc:
            partial = exc.partial_full_return
            v = partial["views"][0]
            record("resource_band_stage_keeps_partial_decisions",
                   v["stage"] == "band_view" and bool(v["partition"]["removal_rounds"])
                   and bool(v["partition"]["fixed_cells"]), partial_full_return=partial)
    original_bbox = core.bbox
    calls = [0]
    def interrupted_bbox(*args, **kwargs):
        calls[0] += 1
        if calls[0] == 2: raise MemoryError("interrupt role construction after label decisions")
        return original_bbox(*args, **kwargs)
    with patch.object(core, "bbox", interrupted_bbox):
        try:
            core.render(grid, base)
            record("resource_role_stage_keeps_partial_decisions", False)
        except MemoryError as exc:
            partial = exc.partial_full_return
            v = partial["views"][0]
            record("resource_role_stage_keeps_partial_decisions",
                   v["stage"] == "parse_roles" and bool(v["roles"]["components"][0]["constraints"])
                   and bool(v["roles"]["owned_foreground"]), partial_full_return=partial)
    original_counter = core.Counter
    calls = [0]
    def interrupted_counter(*args, **kwargs):
        calls[0] += 1
        if calls[0] == 2: raise MemoryError("interrupt assignment after complete paint checks")
        return original_counter(*args, **kwargs)
    with patch.object(core, "Counter", interrupted_counter):
        try:
            core.render(grid, base)
            record("resource_assignment_stage_keeps_partial_decisions", False)
        except MemoryError as exc:
            partial = exc.partial_full_return
            v = partial["views"][0]
            a = v["assignments"][0]
            record("resource_assignment_stage_keeps_partial_decisions",
                   v["stage"] == "all_assignments" and not a["complete"]
                   and bool(a["detail"]["erased_source_cells"])
                   and bool(a["detail"]["checked_paint_cells"]), partial_full_return=partial)
    with patch.object(core, "mixed_region_dicts_for_grid", side_effect=MemoryError("legacy atomic extraction interrupted")):
        try:
            core.render(grid, base)
            record("resource_legacy_primitive_boundary_explicit", False)
        except MemoryError as exc:
            partial = exc.partial_full_return
            v = partial["views"][0]
            record("resource_legacy_primitive_boundary_explicit",
                   v["stage"] == "parse_roles"
                   and not v["roles"]["component_extraction"]["complete"], partial_full_return=partial)
    partial_band = {}
    class InterruptedRow(list):
        def __getitem__(self, index):
            chambers = partial_band.get("chambers", [])
            if chambers and len(chambers[0]["wall_records"]) == 1:
                raise MemoryError("interrupt second wall after first wall decision")
            return super().__getitem__(index)
    interrupted_grid = [InterruptedRow(row) for row in grid]
    try:
        core.band_view(interrupted_grid, 0, ("row", "col"), record=partial_band)
        record("resource_partial_chamber_wall_kept", False)
    except MemoryError:
        chamber = partial_band["chambers"][0]
        record("resource_partial_chamber_wall_kept",
               not chamber["complete"] and len(chamber["walls"]) == 1
               and len(chamber["wall_records"]) == 1, partial_full_return=partial_band)

    # No optimization was introduced. Verify the inherited component cache by
    # calling its undecorated function on every teacher, connectivity, and view.
    from 接続.ARC2 import 既存領域転写 as old_regions
    for ti, pair in enumerate(teachers):
        grid = pair["input"]
        background = Counter(v for row in grid for v in row).most_common(1)[0][0]
        for ci, diagonal in enumerate((False, True)):
            for oi, order in enumerate((("row", "col"), ("col", "row"))):
                partition = core.band_view(grid, background, order)
                fixed = set(map(tuple, partition["fixed_cells"]))
                masked = [[background if (r,c) in fixed else v for c,v in enumerate(row)]
                          for r,row in enumerate(grid)]
                args = (old_regions.grid_key(masked), background, diagonal)
                cached = old_regions._mixed_region_feature_records(*args)
                uncached = old_regions._mixed_region_feature_records.__wrapped__(*args)
                record(f"inherited_component_cache_parity_{ti}_{ci}_{oi}", cached == uncached)

    full.close()
    summary = dict(scope="teacher-only + synthetic; no query, scoring, HDS, all120, or publication",
                   checks=len(results), passed=sum(x["passed"] for x in results),
                   failures=[x for x in results if not x["passed"]], results=results,
                   covariance=[{k:x[k] for k in ("teacher", "transform", "covariant", "held")} for x in covariance],
                   immutable_hashes_verified=IMMUTABLE)
    (C / "synthetic-summary.json").write_text(json.dumps(summary, ensure_ascii=False, indent=2)+"\n")
    print(json.dumps({k: summary[k] for k in ("checks", "passed", "failures", "covariance")}, indent=2))
    return summary


if __name__ == "__main__":
    summary = run()
    raise SystemExit(bool(summary["failures"]))
