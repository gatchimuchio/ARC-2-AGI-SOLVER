"""Synthetic/metamorphic controls only; selected teachers contain train pairs only."""
import gzip, json
from collections import Counter
from pathlib import Path
from prototype import render, parse_input, execute_graph, fit_teachers, consensus, PROGRAMS
from reused_primitives import transform_grid_by_name

ROOT=Path(__file__).resolve().parent
P=(1,'reflector','reflect')
records=[]

def check(name, grid, expected=None, failure=None, inspect=None):
    y,r=render(grid,P)
    okay = (y == expected) if expected is not None else ((y is None and r.get('failure')==failure) if failure else y is not None)
    if inspect:
        okay = okay and inspect(y,r)
    records.append(dict(name=name,passed=bool(okay),input=grid,expected=expected,expected_failure=failure,output=y,record=r))
    assert okay, name
    return y,r


def grid(h=13,w=13): return [[0]*w for _ in range(h)]
def put(g,c,cells):
    for r,k in cells: g[r][k]=c
    return g

def source(g,r,c,dr=1,dc=1,colour=1):
    return put(g,colour,[(r,c),(r-dr,c),(r,c-dc)])

teachers=json.loads((ROOT/'selected-teachers.json').read_text())['train']
transforms=('identity','rot90','rot180','rot270','flip_h','flip_v','transpose','anti_transpose')
for i,pair in enumerate(teachers):
    for t in transforms:
        check(f'teacher_{i}_d4_{t}',transform_grid_by_name(pair['input'],t),transform_grid_by_name(pair['output'],t))
    for shift in range(1,10):
        f=lambda g:[[ (v+shift)%10 for v in row] for row in g]
        check(f'teacher_{i}_palette_{shift}',f(pair['input']),f(pair['output']))
    f=lambda g:[[1 if v else 0 for v in row] for row in g]
    check(f'teacher_{i}_foreground_alias',f(pair['input']),f(pair['output']))

x=source(grid(7,11),1,1)
y=[row[:] for row in x]
for r in range(2,7):y[r][r]=1
check('rectangular_boundary',x,y)
x=source(grid(7,11),6,10)
check('source_exits_immediately',x,x,inspect=lambda y,r:len(r['boundary_exits'])==1 and r['state_count']==0)
x=source(grid(),1,1);put(x,2,[(6,5),(5,6)])
y,r=check('equal_colour_two_contact_branch',x,inspect=lambda y,r:any(len(s.get('contacts',[]))==2 for s in r['states']) and len(r['boundary_exits'])==2)
assert y[0][10]==2 and y[10][0]==2
x=source(grid(),1,1);put(x,2,[(6,5)]);put(x,3,[(5,6)])
check('different_colour_two_contact_branch',x,failure='simultaneous_colour_conflict',inspect=lambda y,r:len(r['boundary_exits'])==2 and any(c['cell']==[5,5] for c in r['paint_conflicts']))
x=source(grid(),1,1);source(x,1,9,1,-1,2);put(x,3,[(4,4)])
check('one_source_collision_does_not_discard_other_source',x,failure='causal_collision',inspect=lambda y,r:bool(r['failed_states']) and bool(r['boundary_exits']) and len({s['state'][0] for s in r['states']})==2)
for col in [1,2]:
    x=source(grid(11,11),1,1);source(x,1,9,1,-1,col)
    check(f'crossing_sources_colour_{col}',x,failure='simultaneous_colour_conflict' if col==2 else None,
          inspect=lambda y,r:len(r['boundary_exits'])==2 and (col==1 or bool(r['paint_conflicts'])))
x=source(grid(),1,1);put(x,2,[(8,5),(8,6),(8,7),(8,8),(8,9)])
check('whole_unrecognized_bar_not_partially_used',x,failure='role_coverage_failed',inspect=lambda y,r:len(r['failed_roles'])==1)
x=source(grid(),1,1);put(x,2,[(2,10)])
check('unhit_point_retains_passive_role',x,inspect=lambda y,r:len(r['unhit_reflectors'])==1 and y[2][10]==2)
x=grid();put(x,2,[(3,3)])
check('no_source',x,failure='role_coverage_failed')
x=source(grid(),1,1);x[2][2]=True
check('boolean_cell_rejected',x,failure='invalid_grid')

# The graph engine has a closed orbit. Its explicit injected state exercises the
# fixed-point contract independently of whether L-source syntax can enter it.
x=source(grid(),0,0,-1,-1,1)
for c,cells in [(2,[(2,5),(2,6),(2,7)]),(2,[(5,10),(6,10),(7,10)]),
                (2,[(10,5),(10,6),(10,7)]),(2,[(5,2),(6,2),(7,2)])]:put(x,c,cells)
scene,rec=parse_input(x);assert scene is not None
sid=scene['sources'][0]['id'];initial=[(sid,3,6,-1,1,1)]
y,r=execute_graph(x,scene,rec,P,initial)
ss={tuple(s['state']) for s in r['states']}
assert y is not None and r['state_count']==13 and not r['boundary_exits']
assert all(tuple(e['target']) in ss for e in r['edges'])
assert len({s[-1] for s in ss if s[1:5]==(3,6,-1,1)})==2
records.append(dict(name='engine_closed_cycle_complete_colour_states',passed=True,input=x,initial=initial,output=y,record=r,
                    limitation='Injected engine state; no claim that an L-source input can enter this isolated orbit.'))

# Ordering affects only diagnostic list order; full causal state/edge sets persist.
for i,pair in enumerate(teachers):
    scene,rec=parse_input(pair['input']);initial=[]
    for s in reversed(scene['sources']):
        dr,dc=s['direction'];r,c=s['center'];initial.append((s['id'],r+dr,c+dc,dr,dc,s['colour']))
    a,ar=execute_graph(pair['input'],scene,rec,P,initial)
    b,br=render(pair['input'],P)
    signature=lambda r: (set(tuple(s['state']) for s in r['states']),
                         Counter(json.dumps(e,sort_keys=True) for e in r['edges']),
                         r['proposals'],r['failed_states'],r['paint_conflicts'])
    assert a==b==pair['output'] and signature(ar)==signature(br)
    records.append(dict(name=f'teacher_{i}_source_order',passed=True,output=a,record=ar))

keep,returns=fit_teachers(teachers)
old=json.loads((ROOT/'teacher-returns.json').read_text())
assert json.loads(json.dumps(returns))==old['all_program_returns']
assert keep==(P,)
for seq in (teachers[::-1],teachers[1:]+teachers[:1]):
    k,_=fit_teachers(seq);assert k==keep
bad=[[1]]
y,r=consensus(bad,keep);assert y is None
records.append(dict(name='all_eight_programs_and_teacher_order',passed=True,retained=keep,all_programs=PROGRAMS))
summary={'passed':sum(x['passed'] for x in records),'total':len(records),'all_passed':all(x['passed'] for x in records),
         'cycle_scope':'Engine-only injected cycle; input-source reachability unproven.',
         'names':[x['name'] for x in records]}
(ROOT/'control-summary.json').write_text(json.dumps(summary,indent=2))
with gzip.open(ROOT/'control-returns.json.gz','wt') as f:json.dump(records,f)
print(json.dumps(summary,indent=2))
