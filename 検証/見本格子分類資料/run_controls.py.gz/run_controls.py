import copy,itertools,json,pathlib,sys
sys.dont_write_bytecode=True
from prototype import consensus,fit,features,regions,canonical_shape,parse,render,rot,transform
P=pathlib.Path(__file__).parent
R=json.loads((P/'teacher-returns.json').read_text());models=R['retained'];teachers=json.loads((P/'teachers.json').read_text())['train']
checks=[]
def record(name,g,expected=None,hold=False,detail=None,ms=models):
 out,rec=consensus(g,ms)
 passed=(out is None)if hold else out==expected
 if out is not None:
  parsed,_=parse(g);bg=parsed['background']
  passed=passed and all(out[r][c]==v for r,row in enumerate(g)for c,v in enumerate(row)if v!=bg)
 row={'name':name,'pass':passed,'expected':'HOLD'if hold else 'exact_grid','output':out,'record':{k:v for k,v in rec.items()if k!='returns'},'detail':detail}
 if 'returns'in rec:row['retained_outcomes']=[{'returned':x['output']is not None,'failure':x['record'].get('failure'),'selected_sets':[a['selected']for a in x['record'].get('allocations',[])]}for x in rec['returns']]
 checks.append(row)

# Independently generated full-span C8 glyphs; choose representatives unique under every retained geometric feature.
glyphs=[];by_nine={};collision=None
for bits in itertools.product((False,True),repeat=9):
 mask={(i//3,i%3)for i,b in enumerate(bits)if b}
 if not mask or regions._bbox_for_cells(list(mask))!=(0,0,2,2):continue
 g=[[1 if (r,c)in mask else 8 for c in range(3)]for r in range(3)]
 if len(regions.mixed_region_dicts_for_grid(g,8,True))!=1:continue
 obj={'bbox':(0,0,2,2),'cells':mask};f=tuple(features.edge_pack_component_feature(obj));d=canonical_shape(tuple(sorted(mask)))
 if f in by_nine and by_nine[f]!=mask and collision is None:collision=(by_nine[f],mask)
 by_nine[f]=mask
 if not any(f==q[1]or d==q[2]for q in glyphs):glyphs.append((mask,f,d))
shapes=[x[0]for x in glyphs]

def make(nr,nc,refs,grid_shapes=None):
 # refs/grid_shapes contain independent (mask,color) objects.
 objects=grid_shapes or [(shapes[i],1)for i in range(nr*nc)]
 w=5*max(nc,len(refs))+2;b=5*nr+7;g=[[8]*w for _ in range(b+3)]
 g[5]=[6]*w;g[b]=[6]*w
 for j,(mask,color)in enumerate(refs):
  for r,c in mask:g[1+r][2+5*j+c]=color
 for i,(mask,color)in enumerate(objects):
  for r,c in mask:g[8+5*(i//nc)+r][2+5*(i%nc)+c]=color
 return g

def expected_grid(g,nc,selected,success):
 out=copy.deepcopy(g);b=len(g)-3
 for i in selected:
  for r in range(7+5*(i//nc),12+5*(i//nc)):
   for c in range(1+5*(i%nc),6+5*(i%nc)):
    if g[r][c]==8:out[r][c]=3
 if success:
  for r in range(5):
   for c in range(len(g[0])):
    if g[r][c]==8:out[r][c]=3
 for r in range(b+1,len(g)):
  for c in range(len(g[0])):out[r][c]=3 if success else 2
 return out
for nr,nc,sel,success,name in [(2,3,[0,1,2],True,'different_grid_2x3_full_row'),(3,2,[0,2,4],True,'different_grid_3x2_full_column'),(3,3,[0,4,8],False,'different_grid_3x3_scattered')]:
 g=make(nr,nc,[(shapes[i],1)for i in sel]);record(name,g,expected_grid(g,nc,sel,success))
for nr,nc,sel,name in [(2,3,[0,1],'incomplete_collinear_vs_complete'),(2,2,[0,1,2,3],'all_matched'),(3,2,[0,1,2,3],'multiple_complete_rows')]:
 g=make(nr,nc,[(shapes[i],1)for i in sel]);record(name,g,hold=True)
g=make(2,3,[(shapes[10],1)]);record('none_matched_membership_vs_total_allocation',g,hold=True)
g=make(2,3,[(shapes[0],1),(shapes[0],1)]);record('duplicate_reference_multiplicity',g,hold=True)
objects=[(shapes[i],1)for i in range(6)];objects[5]=objects[0];g=make(2,3,[objects[0]],objects);record('multiple_equal_matches_no_first_match',g,hold=True)
objects=[(shapes[i],1)for i in range(6)];objects[5]=(shapes[0],4);g=make(2,3,[objects[0]],objects);record('same_shape_different_color',g,hold=True)
asym=next(m for m in shapes if {(c,2-r)for r,c in m}!=m)
objects=[(shapes[i],4)for i in range(6)];objects[0]=(asym,1);objects[5]=({(c,2-r)for r,c in asym},1);g=make(2,3,[objects[0]],objects);record('colored_rotated_decoy',g,hold=True)
assert collision
objects=[(shapes[i],4)for i in range(6)];objects[0]=(collision[0],1);objects[5]=(collision[1],1);g=make(2,3,[objects[0]],objects);record('nine_feature_collision_distinct_masks',g,hold=True,detail={'masks':[sorted(m)for m in collision]})
g=make(2,3,[(shapes[0],1),(shapes[1],1),(shapes[2],1)]);g[-1][2]=1;record('both_outer_bands_nonempty_role_unresolved',g,hold=True)
g=make(2,3,[(shapes[0],1),(shapes[1],1),(shapes[2],1)]);g[6]=[6]*len(g[0]);record('extra_separator_no_cherry_pick',g,hold=True)
record('background_frequency_tie',[[0,1],[1,0]],hold=True)
g=make(2,3,[(shapes[0],1),(shapes[1],1),(shapes[2],1)]);g[16][1]=7;record('foreign_component_lattice_ownership',g,hold=True)
for i,pair in enumerate(teachers):
 for mirror in (False,True):
  for rotation in range(4):
   g=[r[::-1]for r in pair['input']]if mirror else pair['input'];o=[r[::-1]for r in pair['output']]if mirror else pair['output']
   record(f'teacher_{i}_D4_{mirror}_{rotation}',transform(g,rotation),transform(o,rotation))
# Learn paint roles again under palette permutations, retaining all declared hypotheses.
for permutation in ([9,8,7,6,5,4,3,2,1,0],[2,5,8,1,4,7,0,3,6,9]):
 mapped=[{k:[[permutation[v]for v in row]for row in pair[k]]for k in ('input','output')}for pair in teachers]
 mm,rr=fit(mapped)
 checks.append({'name':'palette_refit_exhaustive','pass':len(rr)==576 and len(mm)==len(models),'evaluated':len(rr),'retained':len(mm)})
 for i,pair in enumerate(mapped):record(f'palette_teacher_{i}_{permutation[0]}',pair['input'],pair['output'],ms=mm)
# Every input paint cell remains at its exact original coordinate in every accepted control.
result={'total':len(checks),'passed':sum(x['pass']for x in checks),'failed':[x['name']for x in checks if not x['pass']],'checks':checks,'limitations':'Synthetic ambiguity cases demonstrate conservative HOLD, not additional learning evidence or permission to choose a surviving hypothesis.'}
(P/'controls.json').write_text(json.dumps(result,ensure_ascii=False,separators=(',',':'))+'\n')
print(json.dumps({k:result[k]for k in ('total','passed','failed')},ensure_ascii=False))
