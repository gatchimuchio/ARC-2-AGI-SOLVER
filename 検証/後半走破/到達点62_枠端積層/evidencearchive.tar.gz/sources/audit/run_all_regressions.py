"""Execute every discovered independent regression script, retaining all failures."""
import argparse
from concurrent.futures import ThreadPoolExecutor
import hashlib
import json
import os
from pathlib import Path
import re
import subprocess
import sys
import time

p=argparse.ArgumentParser();p.add_argument('root',type=Path);p.add_argument('output',type=Path);p.add_argument('--workers',type=int,default=3);a=p.parse_args();root=a.root.resolve()
files=sorted((root/'検証').glob('*回帰.py'));started=time.monotonic()
def run(file):
    row={'file':str(file.relative_to(root)),'sha256':hashlib.sha256(file.read_bytes()).hexdigest()}
    try:
        result=subprocess.run([sys.executable,str(file)],cwd=root,capture_output=True,text=True,timeout=120,env={**os.environ,'PYTHONDONTWRITEBYTECODE':'1'})
        raw=result.stdout+result.stderr;counts=re.findall(r'Ran (\d+) tests?',raw);valid=True
        if counts:
            total=sum(map(int,counts));valid=result.returncode==0 and re.search(r'^OK(?:\s|$)',raw,re.MULTILINE) is not None
        else:
            try:
                structured=json.loads(result.stdout);total=structured.get('tests_run',0)
                valid=structured.get('successful') is True and len(structured.get('passed_cases',[]))==total
            except (ValueError,AttributeError):
                total=0;valid=False
        return {**row,'exit_code':result.returncode,'tests':total,'passed':result.returncode==0 and valid,'stdout':result.stdout,'stderr':result.stderr}
    except subprocess.TimeoutExpired as exc:
        return {**row,'exit_code':None,'tests':0,'passed':False,'resource_failure':'timeout','stdout':str(exc.stdout),'stderr':str(exc.stderr)}
with ThreadPoolExecutor(max_workers=a.workers) as pool:rows=list(pool.map(run,files))
report={'files':len(rows),'manifest':[x['file'] for x in rows],'tests':sum(x['tests'] for x in rows),'success':bool(rows) and all(x['passed'] for x in rows),'workers':a.workers,'elapsed_seconds':time.monotonic()-started,'records':rows}
a.output.write_text(json.dumps(report,ensure_ascii=False,indent=2))
print(json.dumps({k:v for k,v in report.items() if k not in ('manifest','records')}));sys.exit(0 if report['success'] else 1)
