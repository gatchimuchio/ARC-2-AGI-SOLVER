"""Versioned per-attempt index of observed failures; original raw records are immutable."""
import argparse
from collections import Counter
import gzip, hashlib, json
from pathlib import Path

p=argparse.ArgumentParser()
p.add_argument('replay',type=Path)
p.add_argument('--attempt-id',required=True)
a=p.parse_args()
raw=gzip.decompress((a.replay/'raw.jsonl.gz').read_bytes())
raw_hash=hashlib.sha256(raw).hexdigest()
events=[];counts=Counter();reasons=Counter()

def event(task,line_index,pointer,kind,**detail):
    row={'event_id':f'{a.attempt_id}:{task}:{pointer or "root"}',
         'attempt_id':a.attempt_id,'task_id_audit_only':task,'type':kind,
         'evidence':{'artifact':'raw.jsonl.gz','decompressed_sha256':raw_hash,
                     'jsonl_line_zero_based':line_index,'pointer':pointer},**detail}
    events.append(row);counts[kind]+=1

for line_index,line in enumerate(raw.splitlines()):
    record=json.loads(line);task=record['task_id']
    base=record;prefix=''
    if 'error' in record:
        code=record.get('returncode')
        kind='timeout' if record['error']=='wall_limit' else ('resource_signal' if code in (-9,-24) else 'runtime_failure')
        event(task,line_index,'',kind,observed_error=record['error'],returncode=code,
              diagnostics_complete=False,scope='Exact saved error retained; absent calls do not imply no candidate')
        base=record.get('partial_diagnostics') or {};prefix='/partial_diagnostics'
    if 'exception' in base:
        exc=base['exception'];name=exc.get('type') if isinstance(exc,dict) else None
        kind='resource_exception' if name in ('MemoryError','RecursionError','TimeoutError') else 'runtime_exception'
        event(task,line_index,prefix+'/exception',kind,exception=exc,diagnostics_complete=False)
    for index,call in enumerate(base.get('calls',[])):
        if not call.get('candidate_is_none') and 'exception' not in call:continue
        detail=call.get('detail') or {}
        reason=detail.get('failure',detail.get('code','returned_no_candidate_without_failure_key')) if isinstance(detail,dict) else 'non_dictionary_detail'
        kind='candidate_exception' if 'exception' in call else 'candidate_generation_failure'
        event(task,line_index,prefix+f'/calls/{index}',kind,stage=call.get('phase'),family_or_callable=call.get('callable'),
              call_sequence=call.get('sequence'),observed_reason=reason,input_sha256=call.get('input_sha256_before'),
              root_cause_status='Returned guard/failure only; underlying task semantics may remain unconfirmed')
        reasons[str(reason)]+=1
    for index,result in enumerate(base.get('result',{}).get('results',[])):
        if result.get('answer') is not None:continue
        event(task,line_index,prefix+f'/result/results/{index}','query_HOLD',query_index_audit_only=index,
              status=result.get('status'),reasons=result.get('reasons'))

assert len({x['event_id'] for x in events})==len(events)
out=''.join(json.dumps(x,ensure_ascii=False)+'\n' for x in events).encode()
compressed=gzip.compress(out,mtime=0)
dest=a.replay/'failure-events-v2.jsonl.gz'
if dest.exists():raise FileExistsError(dest)
dest.write_bytes(compressed)
summary={'attempt_id':a.attempt_id,'events':len(events),'counts':dict(counts),'reason_counts':dict(reasons),
         'source_raw_sha256':raw_hash,'raw_sha256':hashlib.sha256(out).hexdigest(),'gzip_sha256':hashlib.sha256(compressed).hexdigest(),
         'scope':'Index points to complete saved records. No inference from missing diagnostics. Candidate calls are not HDS support; generic guard reasons are not proved semantic causes.'}
(a.replay/'failure-index-summary-v2.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2))
print(json.dumps({k:v for k,v in summary.items() if k!='reason_counts'},ensure_ascii=False))
