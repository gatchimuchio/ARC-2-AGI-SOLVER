"""Compare saved full public evaluations without reading target grids."""
import argparse
from collections import Counter
import hashlib
import json
from pathlib import Path

p=argparse.ArgumentParser();p.add_argument('previous',type=Path);p.add_argument('current',type=Path);p.add_argument('output',type=Path);p.add_argument('--family',default='');a=p.parse_args()
before=json.loads(a.previous.read_text());after=json.loads(a.current.read_text())
ps,cs=before['summary'],after['summary'];pr={x['task_id']:x for x in before['execution']};cr={x['task_id']:x for x in after['execution']}
if set(pr)!=set(cr) or len(pr)!=120 or ps['test_examples']!=167 or cs['test_examples']!=167:
    raise ValueError('Full 120/167 scope must match')
settings=('tasks','test_examples','challenge_sha256','solutions_sha256','cpu_seconds_per_task','address_space_mib','wall_seconds_per_task','workers')
if any(ps[k]!=cs[k] for k in settings):raise ValueError('evaluation settings changed')
wrong=lambda s:s['test_examples']-s['unanswered']-s['correct_examples']
if wrong(ps)!=0:raise ValueError('Previous accepted run must have no wrong grids')
rows=[];changed=[];lost=[];family_changes=[];hold_changes=[]
for task_id in sorted(pr):
    b,c=pr[task_id],cr[task_id]
    bp=b.get('results',[{'answer':None}]*b['test_count']);cp=c.get('results',[{'answer':None}]*c['test_count'])
    if len(bp)!=len(cp):raise ValueError('query count mismatch')
    for i,(x,y) in enumerate(zip(bp,cp)):
        old,new=x.get('answer'),y.get('answer')
        identity={'task_id':task_id,'test_index':i}
        if old is not None:
            rows.append({**identity,'exact_equal':old==new,'previous_grid_sha256':hashlib.sha256(json.dumps(old,separators=(',',':')).encode()).hexdigest()})
            if old!=new:lost.append(identity)
        if old!=new:changed.append({**identity,'previous_answered':old is not None,'current_answered':new is not None})
        if x.get('status')!=y.get('status') or x.get('reasons')!=y.get('reasons'):
            hold_changes.append({**identity,'previous':{'status':x.get('status'),'reasons':x.get('reasons')},'current':{'status':y.get('status'),'reasons':y.get('reasons')}})
    bf={x['境界']:x for x in b.get('families',[])};cf={x['境界']:x for x in c.get('families',[])}
    for family in sorted(set(bf)|set(cf)):
        if bf.get(family)!=cf.get(family):family_changes.append({'task_id':task_id,'family':family,'active_candidate_family':family==a.family,'previous':bf.get(family),'current':cf.get(family)})
partial=lambda d:sorted(k for k,v in d.items() if 0<v['correct_examples']<v['test_count'])
res_before=ps['resource_failures'];res_after=cs['resource_failures'];resource_increase=any(v>res_before.get(k,0) for k,v in res_after.items())
report={'previous_file':str(a.previous),'current_file':str(a.current),'previous_sha256':hashlib.sha256(a.previous.read_bytes()).hexdigest(),'current_sha256':hashlib.sha256(a.current.read_bytes()).hexdigest(),'previous':{**ps,'wrong_grids':wrong(ps)},'current':{**cs,'wrong_grids':wrong(cs)},'delta':{'correct_tasks':cs['correct_tasks']-ps['correct_tasks'],'correct_examples':cs['correct_examples']-ps['correct_examples'],'unanswered':cs['unanswered']-ps['unanswered']},'old_correct_grid_checks':rows,'old_correct_grid_count':len(rows),'regressions':lost,'changed_predictions':changed,'hold_changes':hold_changes,'family_record_changes':family_changes,'partial_tasks':{'previous':partial(pr),'current':partial(cr)},'support_counts':{'previous':dict(Counter(str(x.get('minimum_support')) for x in pr.values())),'current':dict(Counter(str(x.get('minimum_support')) for x in cr.values()))},'settings_identical':True,'resource_increase':resource_increase,'score_gate':not lost and wrong(cs)==0 and not resource_increase,'remaining_required_gates':['teacher reproduction','frozen query input-only','full regression PASS','protected file identity','independent exact package review'],'scope':'Saved scorer counts only; no target-grid access by this comparison script'}
a.output.write_text(json.dumps(report,ensure_ascii=False,indent=2))
print(json.dumps({k:report[k] for k in ('delta','old_correct_grid_count','regressions','resource_increase','score_gate')},ensure_ascii=False))
