# Metadata revision 2: precise preservation scope

This revision corrects only preservation-scope wording. The original and prospective sources, fixed priors, raw returns, retained models, and contracts are unchanged. The previous metadata remains available as history; this directory supersedes its preservation wording only.

The independently checkable pre-prospective manifest is prospective-cue-rotation/original-evidence-before.json. It contains exactly these six original-study artifacts, all rechecked with matching SHA256:

1. PRIOR.md
2. prototype.py
3. retained-programs.json
4. all-program-teacher-results.jsonl
5. teacher-result-catalog.json
6. all-control-program-returns.json

Thus the supported claim is: the important six source/prior/model and teacher/control evidence artifacts of the original 15,360-program, 24-retained-model study match their pre-prospective hashes. This does not assert that all earlier metadata remained unchanged.

The root manifests, README, summaries, and root artifact-sha256.json are current metadata generated or updated after adding the prospective prior. The root 42-file hash catalog is a final catalog, not a complete pre-prospective baseline. No other complete before catalog covering all old metadata is available.

preservation-scope-addendum.json names the exact six files, before and current hashes, and the previous/new metadata paths. Both manifest files retain exactly the original ten fields. All evidence references in both revised manifests are relative to the candidate root; the addendum is at metadata-v2/preservation-scope-addendum.json.

No fit, control, raw result, model count, agreement guard, or staging finding changes. Queries remain unexamined. Native/HDS validation is a separate unperformed stage; teacher-fit and artifact checks are not HDS learning.
