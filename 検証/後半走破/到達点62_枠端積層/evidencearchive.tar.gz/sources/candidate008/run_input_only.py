"""Frozen candidate008 input-only check; complete observer prefixes, no scoring."""
import argparse, copy, dataclasses, enum, hashlib, json, os, resource, subprocess, sys, traceback
from pathlib import Path
sys.dont_write_bytecode=True
HERE=Path(__file__).resolve().parent
ROOT=HERE.parents[1]/'arc2-second-half'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()

def serial(value):
    if dataclasses.is_dataclass(value): return serial(dataclasses.asdict(value))
    if isinstance(value,enum.Enum): return serial(value.value)
    if isinstance(value,dict): return {str(k):serial(v) for k,v in value.items()}
    if isinstance(value,(list,tuple)): return [serial(v) for v in value]
    if isinstance(value,(set,frozenset)): return [serial(v) for v in sorted(value,key=repr)]
    return value

p=argparse.ArgumentParser();p.add_argument('--freeze-sha',required=True);p.add_argument('--child',action='store_true');p.add_argument('--journal');args=p.parse_args()
freeze_path=HERE/'production-freeze.json'
if sha(freeze_path)!=args.freeze_sha:raise ValueError('freeze changed')
freeze=json.loads(freeze_path.read_text())
for path,expected in freeze['files'].items():
    if sha(Path(path))!=expected:raise ValueError(('frozen file changed',path))

if args.child:
    resource.setrlimit(resource.RLIMIT_CPU,(10,11));resource.setrlimit(resource.RLIMIT_AS,(512*1024**2,512*1024**2))
    payload=json.load(sys.stdin)
    if set(payload)!={'task','frozen_models'}:raise ValueError('invalid payload')
    task=payload['task'];frozen_models=tuple(tuple(x) for x in payload['frozen_models'])
    if set(task)!={'train','test'} or any(set(x)!={'input'} for x in task['test']):raise ValueError('invalid input-only contract')
    journal_path=Path(args.journal).resolve()
    if journal_path.parent != (HERE/'input-only-journals').resolve():raise ValueError('invalid journal destination')
    opens=[];direct=[];phase={'name':'teacher_fit'};events=0
    def audit(event,arguments):
        if event!='open' or not isinstance(arguments[0],(str,bytes,os.PathLike)):return
        path=str(Path(os.fsdecode(arguments[0])).resolve())
        if '/data/evaluation/' in path or 'solutions' in Path(path).name:raise PermissionError('Python audited original evaluation/solution reads forbidden')
        if path.endswith(('.json','.jsonl','.gz')):opens.append({'path':path,'mode':str(arguments[1])})
    sys.addaudithook(audit)
    sys.path[:0]=[str(ROOT),str(ROOT/'HDS/学習系統/v0.4.2')]
    journal=journal_path.open('x',encoding='utf-8')
    def observe(value):
        global events
        snapshot=serial(copy.deepcopy(value))
        journal.write(json.dumps({'sequence':events,'phase':copy.deepcopy(phase),'event':snapshot},ensure_ascii=False,allow_nan=False)+'\n')
        journal.flush();events+=1
    try:
        from 接続.ARC2.枠端積層教材 import 枠端積層教材
        from 接続.ARC2.HDS接続 import 課題を解く,事前教材を読む
        before_task=copy.deepcopy(task)
        model=枠端積層教材(task['train'],観測=observe)
        if not model.モデル群 or model.モデル群!=frozen_models:raise ValueError('frozen teacher models changed')
        for index,pair in enumerate(task['test']):
            phase={'name':'direct_query','query_index':index}
            before=copy.deepcopy(pair['input']);grid,record=model.候補(pair['input'],{},観測=observe)
            direct.append({'input':before,'candidate':serial(copy.deepcopy(grid)),'record':serial(copy.deepcopy(record)),'input_unchanged':before==pair['input']})
        phase={'name':'whole_solver'}
        result=課題を解く(task,事前教材を読む())
        envelope={'direct':direct,'whole_solver':result,'task_unchanged':before_task==task,'audited_data_opens':opens,
                  'journal_events':events,'contract':{'task_id_received':False,'test_fields':[sorted(x) for x in task['test']],
                  'frozen_models':frozen_models,'fixed_prior':'Input cue directed edge to right using the same proper C4 rotation for all payloads; all six teacher-retained programs remain',
                  'python_open_audit_not_os_isolation':True,'observer_scope':'Direct teacher fit and direct query completed-model prefixes; native whole-solver path is unchanged and has final-return observation only'}}
    except BaseException as exc:
        envelope={'error':'resource_failure' if isinstance(exc,(MemoryError,RecursionError,TimeoutError)) else 'runtime_exception',
                  'exception':{'type':type(exc).__name__,'message':str(exc),'traceback':traceback.format_exc()},
                  'partial_direct':direct,'audited_data_opens':opens,'journal_events':events,'failed_phase':phase}
        journal.close();print(json.dumps(serial(envelope),ensure_ascii=False));raise SystemExit(1)
    journal.close();print(json.dumps(serial(envelope),ensure_ascii=False));raise SystemExit(0)

challenge=ROOT.parent/'arc2-restored-592d2c5-audit/data/arc-agi_evaluation_challenges.json'
if sha(challenge)!='bd9a3bdd8d176764412108eb3a1a6cb8b792a9c6fe2567532c186b2e3e4bd3bb':raise ValueError('challenge changed')
tasks=json.loads(challenge.read_text())
if any(set(t)!={'train','test'} or any(set(q)!={'input'} for q in t['test']) for t in tasks.values()):raise ValueError('challenge fields invalid')
preflight=json.loads((HERE/'production-integration/production-teacher-parity.json').read_text())
out=HERE/'input-only.json'
if out.exists():raise FileExistsError(out)
journals=HERE/'input-only-journals';journals.mkdir(exist_ok=False)
records=[]
for fitted in preflight['records']:
    if not fitted['fit']:continue
    task=tasks[fitted['task_id_audit_only']]
    journal=journals/('run-%03d.jsonl'%len(records))
    try:
        result=subprocess.run([sys.executable,__file__,'--freeze-sha',args.freeze_sha,'--child','--journal',str(journal)],input=json.dumps({'task':task,'frozen_models':fitted['models']}),text=True,capture_output=True,timeout=60,env={**os.environ,'PYTHONDONTWRITEBYTECODE':'1'})
        row={'returncode':result.returncode,'stdout':result.stdout,'stderr':result.stderr}
        if result.returncode:row['error']='resource_signal' if result.returncode in (-9,-24) else 'runtime_exit'
        if result.stdout:
            try:row['result']=json.loads(result.stdout)
            except ValueError:row['error']='invalid_json'
    except subprocess.TimeoutExpired as exc:
        row={'error':'wall_limit','stdout':str(exc.stdout),'stderr':str(exc.stderr)}
    if journal.exists():
        raw=journal.read_bytes();complete=[];trailing=None
        for number,line in enumerate(raw.splitlines()):
            try:complete.append(json.loads(line))
            except ValueError:trailing={'line_index':number,'bytes':len(line)};break
        row['observer_journal']={'path':str(journal),'sha256':sha(journal),'bytes':len(raw),'complete_events':len(complete),
                                 'incomplete_trailing_line':trailing,'trace_complete':not row.get('error') and trailing is None}
    records.append({'task_id_audit_only':fitted['task_id_audit_only'],**row})
report={'attempt_id':'attempt-008-cue-aligned-stack','freeze_sha256':args.freeze_sha,'records':records,'scoring_performed':False,
        'code_unchanged_after':all(sha(Path(p))==h for p,h in freeze['files'].items()),
        'scope':'Teacher-frozen all retained models and sanitized test inputs; fresh HDS process, 10CPU/512MiB/60wall limits; append-and-flush observer journal preserves completed direct prefixes'}
out.write_text(json.dumps(report,ensure_ascii=False,indent=2))
print(json.dumps({'tasks':len(records),'direct_answers':sum(x['candidate'] is not None for r in records for x in r.get('result',{}).get('direct',[])),
                  'HDS_answers':sum(x['answer'] is not None for r in records for x in r.get('result',{}).get('whole_solver',{}).get('results',[])),
                  'errors':[{'task':r['task_id_audit_only'],'error':r['error']} for r in records if 'error' in r],
                  'code_unchanged':report['code_unchanged_after'],'output_sha256':sha(out),'scored':False}))
