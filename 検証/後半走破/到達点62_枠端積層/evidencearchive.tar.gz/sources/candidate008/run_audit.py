"""Authorized sanitized teachers and authored controls only; writes only beside this file."""
from __future__ import annotations

from collections import Counter
from dataclasses import replace
import hashlib
import importlib
import json
from pathlib import Path
import sys

sys.dont_write_bytecode = True
HERE = Path(__file__).resolve().parent
WORKSPACE = HERE.parents[1]
sys.path.insert(0, str(HERE))
import prototype as p

TEACHER_FILE = WORKSPACE / "arc2-restored-592d2c5-audit/evaluation-teachers-only.json"
EXPECTED_SHA = "012924cb967106a6d72e9323b83534539471c27dc4f5fba5d8d4a0dbe334c8aa"
TASK = "291dc1e1"


def sha(data):
    return hashlib.sha256(data).hexdigest()


def canonical(value):
    return json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":"))


def write(name, value):
    HERE.joinpath(name).write_text(json.dumps(value, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")


class Pool:
    def __init__(self):
        self.data = {}

    def add(self, result):
        text = canonical(result)
        key = sha(text.encode())
        self.data.setdefault(key, result)
        return key


def frame(h, w, objects, horizontal=1, vertical=2, corner=0, background=8):
    out = [[background] * w for _ in range(h)]
    out[0] = [corner] + [horizontal] * (w - 1)
    for r in range(1, h):
        out[r][0] = vertical
    for r0, c0, tile in objects:
        for r, row in enumerate(tile):
            for c, value in enumerate(row):
                out[r0 + r][c0 + c] = value
    return out


def relabel(grid, mapping):
    return [[mapping[v] for v in row] for row in grid]


def inject_resource_error(exception_type, grid, retained):
    original = p.regions.mixed_region_dicts_for_grid
    def fail(*args, **kwargs):
        raise exception_type("authored_resource_propagation_control")
    p.regions.mixed_region_dicts_for_grid = fail
    try:
        p.apply_retained(retained, grid)
    except exception_type as exc:
        return {"exception": type(exc).__name__, "propagated": True,
                "category": "resource_runtime_failure", "semantic_abstention": False}
    finally:
        p.regions.mixed_region_dicts_for_grid = original
    raise AssertionError("resource_exception_swallowed")


def main():
    raw = TEACHER_FILE.read_bytes()
    if sha(raw) != EXPECTED_SHA:
        raise RuntimeError("authorized_teacher_checksum_mismatch")
    teachers = json.loads(raw)[TASK]["train"]
    inventory = json.loads((WORKSPACE / "arc2-second-half-audit/inventory-observations-60.json").read_text())
    matching = [row for row in inventory["rows"] if row["対象"] == TASK]
    if len(matching) != 1 or len(matching[0]) != 10 or len(teachers) != 4:
        raise RuntimeError("source_contract_mismatch")
    write("source-row-exact-10-fields.json", matching[0])
    write("teacher-input-output.json", {"source": str(TEACHER_FILE.relative_to(WORKSPACE)),
                                      "sha256": EXPECTED_SHA, "task": TASK, "train": teachers})
    prefit = {"declaration_sha256": sha((HERE / "PRIOR.md").read_bytes()),
              "prototype_sha256": sha((HERE / "prototype.py").read_bytes()),
              "grammar_size": len(p.all_programs()), "phase": "before_fit",
              "teacher_outputs_used_for_input_role_parsing": False}
    write("prefit-declaration.json", prefit)
    pool = Pool()
    all_fit_rows = []
    def record(number, program, results, exacts):
        all_fit_rows.append({"program_number": number, "program": program.record(),
                             "teacher_result_refs": [pool.add(result) for result in results],
                             "teacher_exacts": exacts, "retained": all(exacts)})
    retained, views = p.fit(teachers, record)
    write("teacher-input-role-inventory.json", views)
    with HERE.joinpath("all-program-teacher-results.jsonl").open("w", encoding="utf-8") as handle:
        for row in all_fit_rows:
            handle.write(canonical(row) + "\n")
    write("teacher-result-catalog.json", pool.data)
    write("retained-programs.json", [program.record() for program in retained])
    write("teacher-fit-summary.json", {"programs": len(all_fit_rows), "teachers": len(teachers),
                                       "program_teacher_returns": sum(len(row["teacher_result_refs"]) for row in all_fit_rows),
                                       "retained": len(retained), "full_unique_result_records": len(pool.data),
                                       "exhaustive": len(all_fit_rows) == 15360,
                                       "all_programs_evaluated_on_all_teachers": all(len(row["teacher_exacts"]) == 4 for row in all_fit_rows),
                                       "role_counts": [len(view["roles"]) for view in views],
                                       "component_counts": [[{conn: len(role["inventories"][conn]["objects"])
                                                               for conn in ("4", "8")} for role in view["roles"]]
                                                            for view in views]})
    print("teacher fit:", len(all_fit_rows), "programs; retained", len(retained), flush=True)

    # Direct read-only existing-family comparison; no HDS instance or solver bridge.
    sys.path.insert(0, str(p.SOURCE / "HDS/学習系統/v0.4.2"))
    serial = importlib.import_module("接続.ARC2.成分直列教材")
    groups = importlib.import_module("接続.ARC2.物体群整列")
    serial_model = serial.成分直列教材(teachers)
    existing = {"component_serial": {"model_record": serial_model.記録(), "teachers": []},
                "object_group": {"teacher_matches": []},
                "contracts": {"component_serial": "Same-color C4 contact simple path; one-column pixel serialization; foreground height <=30.",
                              "object_group": "Same-color C8 components; equal bbox dimensions; unique appearance; fixed slots; teacher-fit feature groups.",
                              "new_composition": "Boundary-only cue consumption, complete mixed-color crops, per-axis D4, cue scan, variable-width gapless center stack."}}
    for pair in teachers:
        direct, detail = serial.guarded_render(pair["input"])
        selected, selected_detail = serial_model.候補(pair["input"], None)
        existing["component_serial"]["teachers"].append({"direct_output": direct, "direct_details": detail,
                                                         "model_output": selected, "model_details": selected_detail,
                                                         "exact": selected == pair["output"]})
        existing["object_group"]["teacher_matches"].append(groups.教師を照合(pair) is not None)
    ledger_file = p.SOURCE / "学習台帳/ARC2規則台帳_v1.json"
    ledger = json.loads(ledger_file.read_text())
    existing["ledger"] = {"sha256": sha(ledger_file.read_bytes()), "count": ledger["件数"],
                          "entries": [{"index": index, "id": ledger["規則"][index]["規則ID"],
                                       "name": ledger["規則"][index]["規則名"]} for index in (30, 46)],
                          "claims": "Contract comparison only; historical performance and query observations are not evidence for this prototype."}
    write("ledger-67-contract-comparison.json", existing)

    controls = []
    def run_control(name, grid, expectation=None, programs=None):
        result = p.apply_retained(retained if programs is None else programs, grid)
        row = {"name": name, "expectation": expectation, "result": result}
        if expectation is not None:
            if expectation in ("HOLD", "OUTPUT"):
                row["passed"] = result["status"] == expectation
            else:
                row["passed"] = result["status"] == "OUTPUT" and result["output"] == expectation
        controls.append(row)
        return row
    for i, pair in enumerate(teachers):
        run_control("teacher_replay_" + str(i), pair["input"], pair["output"])

    asym = frame(8, 12, [(2, 2, [[3, 4, 5, 6], [7, 9, 1, 2]]),
                         (5, 7, [[4, 4], [4, 4]])])
    orientation = run_control("asymmetric_horizontal_orientation_counterexample", asym, "HOLD")
    diagonal = frame(9, 9, [(2, 2, [[3, 3], [3, 3]]), (4, 4, [[4, 4], [4, 4]])])
    run_control("diagonal_touch_C4_C8_counterexample", diagonal, "HOLD")
    odd = frame(8, 12, [(2, 2, [[3, 3, 3], [3, 3, 3]]), (5, 7, [[4, 4], [4, 4]])])
    run_control("odd_center_counterexample", odd, "HOLD")
    ring = frame(8, 10, [(2, 2, [[3, 4, 5], [6, 8, 7], [9, 1, 2]])])
    run_control("complete_holey_crop", ring, "HOLD")
    symmetric = frame(8, 12, [(2, 2, [[3, 3], [3, 3]]), (5, 7, [[4, 4, 4, 4], [4, 4, 4, 4]])])
    run_control("unambiguous_symmetric_payload", symmetric,
                [[8, 3, 3, 8], [8, 3, 3, 8], [4, 4, 4, 4], [4, 4, 4, 4]])
    nested = frame(10, 10, [(2, 2, [[3, 3, 3, 3, 3], [3, 8, 8, 8, 3],
                                   [3, 8, 4, 8, 3], [3, 8, 8, 8, 3], [3, 3, 3, 3, 3]])])
    run_control("foreign_foreground_inside_full_crop_negative", nested, "HOLD")
    multiple = frame(8, 8, [(3, 3, [[4]])])
    multiple[-1] = [2] * 7 + [3]
    for r in range(1, 7):
        multiple[r][-1] = 1
    multi = run_control("opposite_corner_roles_not_first_guide", multiple, "HOLD")
    if len(multi["result"]["input_view"]["roles"]) != 2:
        raise AssertionError("opposite_corner_role_control_did_not_exercise_two_roles")
    bg_tie = frame(5, 5, [(1, 1, [[8, 8, 3, 3]] * 4)])
    tie = run_control("tied_modal_background_roles", bg_tie, "HOLD")
    if len(tie["result"]["input_view"]["roles"]) != 2:
        raise AssertionError("background_control_did_not_exercise_two_roles")
    invalid_edge = [row[:] for row in symmetric]
    invalid_edge[0][3] = 7
    run_control("broken_boundary_cue_negative", invalid_edge, "HOLD")
    run_control("ragged_input_negative", [[0, 1], [2]], "HOLD")
    many = frame(30, 30, [(r, c, [[3]]) for r in range(2, 30, 2) for c in range(2, 30, 2)])
    run_control("all_196_components_retained_output_bounds", many, "HOLD")

    # D4 controls concern complete input ownership, and retain every current return.
    # The absolute vertical-output grammar does not assert whole-grid D4 equivariance.
    d4_controls = []
    for teacher_index, pair in enumerate(teachers):
        original = p.prepare_input(pair["input"])
        for transform in p.D4:
            grid = p.operations.transform_grid_by_name(pair["input"], transform)
            row = run_control("D4_teacher_%d_%s" % (teacher_index, transform), grid,
                              pair["output"] if transform == "identity" else None)
            viewed = row["result"]["input_view"]
            original_signatures = sorted((role["background"], conn,
                                          sorted((obj["size"], tuple(sorted(obj["color_counts"].items())), obj["hole_count"])
                                                 for obj in role["inventories"][conn]["objects"]))
                                         for role in original["roles"] for conn in ("4", "8"))
            new_signatures = sorted((role["background"], conn,
                                     sorted((obj["size"], tuple(sorted(obj["color_counts"].items())), obj["hole_count"])
                                            for obj in role["inventories"][conn]["objects"]))
                                    for role in viewed["roles"] for conn in ("4", "8"))
            check = {"name": row["name"], "ownership_component_signatures_preserved": original_signatures == new_signatures,
                     "retained_status": row["result"]["status"], "retained_return_count": len(row["result"]["returns"])}
            if not check["ownership_component_signatures_preserved"]:
                raise AssertionError("D4_component_ownership_changed")
            d4_controls.append(check)
    write("D4-controls-summary.json", d4_controls)
    palette_controls = []
    for shift in range(10):
        mapping = {v: (v + shift) % 10 for v in range(10)}
        mapped_programs = [replace(program, fast_color=mapping[program.fast_color]) for program in retained]
        for i, pair in enumerate(teachers):
            row = run_control("palette_shift_%d_teacher_%d" % (shift, i),
                              relabel(pair["input"], mapping), relabel(pair["output"], mapping), mapped_programs)
            palette_controls.append({"name": row["name"], "mapping": mapping, "passed": row["passed"]})
    write("palette-controls-summary.json", palette_controls)
    write("all-control-program-returns.json", controls)
    write("resource-controls.json", [inject_resource_error(exception, symmetric, retained)
                                    for exception in (MemoryError, RecursionError)])

    # Contradictory output does not affect input role parsing or retain a program.
    corrupted = [row[:] for row in teachers[0]["output"]]
    corrupted[0][0] = 5
    negative = []
    for row in all_fit_rows:
        results = [pool.data[ref] for ref in row["teacher_result_refs"]]
        exacts = [result["failure"] is None and result["output"] == (corrupted if i == 0 else teachers[i]["output"])
                  for i, result in enumerate(results)]
        negative.append({"program_number": row["program_number"], "teacher_result_refs": row["teacher_result_refs"],
                         "teacher_exacts": exacts, "retained": all(exacts)})
    with HERE.joinpath("negative-teacher-all-program-results.jsonl").open("w", encoding="utf-8") as handle:
        for row in negative:
            handle.write(canonical(row) + "\n")
    write("negative-teacher-summary.json", {"modified_teacher": 0, "modified_output": corrupted,
                                           "input_views_unchanged": True, "programs_evaluated": len(negative),
                                           "retained": sum(row["retained"] for row in negative)})
    expected_checks = [row for row in controls if "passed" in row]
    if any(not row["passed"] for row in expected_checks):
        raise AssertionError([row["name"] for row in expected_checks if not row["passed"]])
    summary = {"status": "TEACHER_ONLY_GUARDED_CANDIDATE", "reason": "All 24 retained programs must succeed and agree before output. Authored asymmetric, diagonal-contact, and odd-width inputs demonstrate useful guarded HOLD; they do not establish actual-task query failure.",
               "staging": "UNDECIDED_PENDING_INDEPENDENT_AUDIT", "actual_task_query_closure": "UNEXAMINED",
               "teacher_fit": {"programs": len(all_fit_rows), "teachers": 4, "retained": len(retained)},
               "controls": len(controls), "explicit_expected_checks_passed": len(expected_checks),
               "D4_ownership_checks_passed": len(d4_controls), "palette_checks_passed": len(palette_controls),
               "resource_exceptions_propagate": ["MemoryError", "RecursionError"],
               "counterexample": {"name": orientation["name"], "distinct_success_outputs": orientation["result"]["distinct_success_outputs"],
                                  "all_retained_return_count": len(orientation["result"]["returns"])},
               "no_program_removed_using_controls": True,
               "official_tasks_queries_scorers_solutions_git_used": False,
               "runtime_admission_performance_claim": False}
    write("audit-summary.json", summary)

    module_files = sorted({Path(module.__file__).resolve() for name, module in sys.modules.items()
                           if name.startswith("接続.ARC2") and getattr(module, "__file__", None)})
    read_only_sources = [{"path": str(path.relative_to(WORKSPACE)), "sha256": sha(path.read_bytes())}
                         for path in module_files]
    write("source-import-provenance.json", {"accepted_reference": "d2bbed (provided by parent; no Git inspection)",
                                           "direct_primitives": ["既存領域転写.mixed_region_dicts_for_grid",
                                                                 "既存格子操作.transform_grid_by_name",
                                                                 "既存凡例穴対応.component_hole_count"],
                                           "read_only_import_closure": read_only_sources,
                                           "bytecode_disabled": sys.dont_write_bytecode})
    print(json.dumps(summary, ensure_ascii=False), flush=True)


if __name__ == "__main__":
    main()
