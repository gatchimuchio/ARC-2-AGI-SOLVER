"""Independently inspect saved complete evidence; run bounded authored API controls."""
import hashlib
import json
from pathlib import Path
import sys

sys.dont_write_bytecode = True
HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
import prototype as p


def load(name):
    return json.loads(HERE.joinpath(name).read_text())


def save(name, value):
    HERE.joinpath(name).write_text(json.dumps(value, ensure_ascii=False, indent=2) + "\n")


def require(condition, message):
    if not condition:
        raise AssertionError(message)


def main():
    catalog = load("teacher-result-catalog.json")
    rows = [json.loads(line) for line in HERE.joinpath("all-program-teacher-results.jsonl").read_text().splitlines()]
    retained_records = load("retained-programs.json")
    retained = [p.Program(**record) for record in retained_records]
    teachers = load("teacher-input-output.json")["train"]
    require(len(rows) == 15360, "full_grammar_not_saved")
    require([row["program_number"] for row in rows] == list(range(15360)), "program_enumeration_gap")
    require([row["program"] for row in rows] == [program.record() for program in p.all_programs()], "grammar_records_changed")
    require([row["program"] for row in rows if row["retained"]] == retained_records, "retained_programs_changed")
    for row in rows:
        require(len(row["teacher_result_refs"]) == 4, "teacher_return_dropped")
        exacts = []
        for index, ref in enumerate(row["teacher_result_refs"]):
            result = catalog[ref]
            encoded = json.dumps(result, ensure_ascii=False, sort_keys=True, separators=(",", ":")).encode()
            require(hashlib.sha256(encoded).hexdigest() == ref, "shared_result_reference_corrupted")
            exacts.append(result["failure"] is None and result["output"] == teachers[index]["output"])
        require(exacts == row["teacher_exacts"] and all(exacts) == row["retained"], "teacher_fit_metadata_wrong")
    controls = load("all-control-program-returns.json")
    for row in controls:
        returns = row["result"]["returns"]
        require(len(returns) == len(retained), "retained_control_return_dropped")
        require(len({tuple(sorted(record["program"].items())) for record in returns}) == len(retained), "control_program_duplicated")
        result = row["result"]
        failures = [i for i, record in enumerate(returns) if record["result"]["failure"]]
        distinct = {p.grid_key(record["result"]["output"]) for record in returns if not record["result"]["failure"]}
        require(failures == result["failure_program_indices"], "failure_erased")
        require(len(distinct) == result["distinct_success_outputs"], "output_disagreement_erased")
        require(result["status"] == ("OUTPUT" if not failures and len(distinct) == 1 else "HOLD"), "consensus_aggregation_wrong")
    require(not list(HERE.rglob("*.pyc")) and not list(HERE.rglob("__pycache__")), "bytecode_created")
    prefit = load("prefit-declaration.json")
    require(prefit["prototype_sha256"] == hashlib.sha256(HERE.joinpath("prototype.py").read_bytes()).hexdigest(), "prototype_changed_after_prefit")
    require(prefit["declaration_sha256"] == hashlib.sha256(HERE.joinpath("PRIOR.md").read_bytes()).hexdigest(), "prior_changed_after_fit")

    authored = {row["name"]: row for row in controls}
    compact = []
    for name, scope in (("asymmetric_horizontal_orientation_counterexample", {"connectivity": 4, "center": "exact"}),
                        ("diagonal_touch_C4_C8_counterexample", {"horizontal_transform": "identity", "center": "exact"}),
                        ("odd_center_counterexample", {"horizontal_transform": "identity", "connectivity": 4})):
        row = authored[name]
        returns = [item for item in row["result"]["returns"] if all(item["program"][key] == value for key, value in scope.items())]
        compact.append({"name": name, "input": row["result"]["input_view"]["input"],
                        "parameter_slice_for_explanation_only": scope,
                        "all_retained_count": len(row["result"]["returns"]),
                        "full_evidence": "all-control-program-returns.json#" + name,
                        "illustrative_returns": [{"program": item["program"], "output": item["result"]["output"],
                                                   "failure": item["result"]["failure"]} for item in returns]})
    save("closure-counterexamples.json", compact)

    # Exhaustive abstract ordering helper control. The objects are deliberately
    # abstract records, not a claim of geometric reachability under the parser.
    objects = [{"id": 0, "input_cells": [(2, 2)]}, {"id": 1, "input_cells": [(2, 2)]},
               {"id": 2, "input_cells": [(4, 4)]}, {"id": 3, "input_cells": [(4, 4)]}]
    orders, keys = p.all_orders(objects, {"corner": [0, 0]}, retained[0], True)
    require(len(orders) == 4 and len(set(orders)) == 4, "tie_permutation_truncated")
    helper_check = {"kind": "abstract_order_helper_only_not_parser_input", "objects": objects,
                    "scan_keys": keys, "all_orders": orders, "expected_order_count": 4}

    # A last-retained-program failure must defeat an otherwise unanimous answer.
    input_grid = authored["unambiguous_symmetric_payload"]["result"]["input_view"]["input"]
    original = p.Evaluator.evaluate
    target = retained[-1]
    def injected(self, program):
        if program == target:
            return {"output": None, "failure": {"kind": "domain", "code": "authored_last_program_failure"}, "roles": []}
        return original(self, program)
    p.Evaluator.evaluate = injected
    try:
        late_failure = p.apply_retained(retained, input_grid)
    finally:
        p.Evaluator.evaluate = original
    require(late_failure["status"] == "HOLD" and late_failure["failure_program_indices"] == [23]
            and len(late_failure["returns"]) == 24 and late_failure["distinct_success_outputs"] == 1,
            "last_program_failure_rescued")
    save("additional-api-controls.json", {"tie_order_helper": helper_check,
                                          "last_program_failure_full_returns": late_failure})
    report = {"status": "PASS_FOR_EVIDENCE_INTEGRITY_NOT_ADOPTION", "grammar_program_records": len(rows),
              "teacher_return_records": 4 * len(rows), "retained_programs": len(retained),
              "control_inputs": len(controls), "retained_control_returns": len(controls) * len(retained),
              "teacher_output_comparisons_independently_recomputed": True,
              "shared_complete_result_hashes_verified": True,
              "every_control_consensus_recomputed": True,
              "prefit_declaration_and_prototype_hashes_unchanged": True,
              "bytecode_absent": True, "abstract_tie_permutations": len(orders),
              "last_program_failure_preserved": True,
              "candidate_verdict": "TEACHER_ONLY_GUARDED_CANDIDATE_PENDING_INDEPENDENT_AUDIT",
              "actual_task_query_closure": "UNEXAMINED"}
    save("artifact-integrity-review.json", report)
    print(json.dumps(report, ensure_ascii=False))


if __name__ == "__main__":
    main()
