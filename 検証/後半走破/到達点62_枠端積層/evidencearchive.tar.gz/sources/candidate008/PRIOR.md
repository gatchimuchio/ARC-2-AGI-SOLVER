# Candidate 008: declared grammar before fitting

This is a teacher-only, pure composition experiment. The source row for 291dc1e1 and the four sanitized teachers were inspected before this declaration. No official task, held-out input, answer, solver query, scorer, or Git operation is used. This is not a claim that the grammar was selected independently of these teachers.

## Input role grammar

On a valid 1..30 by 1..30 ARC grid, enumerate all four corner hypotheses. Each hypothesis consumes exactly its incident full boundary row and full boundary column. Away from their shared corner each edge must be constant; the two edge colors and corner color must be distinct. The residual interior must be nonempty. Every most-frequent residual color distinct from those three guide colors is an explicit background hypothesis; a frequency tie is retained in full. The role inventory is computed from the input alone, before any program fit. A program cannot discard a structurally valid role because its rendering is inconvenient.

For each role enumerate BOTH mixed-color C4 and mixed-color C8 component inventories, directly using the accepted source primitive. Every interior non-background cell must have exactly one component owner. Complete bounding-box crops are carried. If a crop contains foreground owned by another component, the hypothesis is a domain failure; it is never replaced by a masked/partial crop. Boundary cue colors inside the payload are ordinary object data. Isolated pixels, duplicate appearances, nonrectangular objects, holes, and arbitrary component counts are not pruned.

## Complete finite program grammar

The Cartesian product is 10 possible fast-edge cue colors x 2 connectivities x 2 fast-axis directions x 2 slow-axis directions x 8 D4 crop transforms for a horizontal fast edge x 8 D4 crop transforms for a vertical fast edge x 3 centering policies = 15,360 programs. Cue color is a learned nominal symbol, never its numeric rank. All color symbols 0..9 are evaluated, including absent colors. No teacher-derived candidate restriction is applied.

For each role the fast-edge color parameter must identify exactly one of its two boundary edges. Axial distances are measured from the shared corner; the other edge supplies the slow coordinate. Sort objects lexicographically by their leading slow and fast bbox coordinates, after applying the two declared direction signs. Complete-key ties enumerate every permutation; there is no horizontal preference or first component preference. Crop D4 transform depends only on whether the identified fast edge is horizontal or vertical. This intentionally retains all eight alternatives per axis: the teachers may not identify orientation on symmetric objects.

The renderer vertically concatenates all transformed full crops, with zero inter-object gap. Width is the maximum transformed crop width. The three centering policies are exact integer center (odd difference is a domain failure), floor, and ceil. Heights and widths must remain within ARC bounds; this is an explicit output domain bound, not a search or inventory cap. Each transform and placement preserves component colors, all crop pixels, and holes. Foreground counts are checked globally and per object.

## Ambiguity, fitting, and failure semantics

Every role, component inventory, program, tie permutation, placement, complete output, and domain failure is retained in evidence (shared immutable detail references are allowed). Roles are not fit with teacher outputs. For a program to reproduce a teacher, EVERY input-derived role and order alternative must render successfully and give the same complete output. A program is retained only if it exactly reproduces ALL teachers. All 15,360 programs are evaluated on all four teachers without short-circuit, pruning, candidate cap, or first-match selection.

Applying the retained program set to any authorized teacher or synthetic control records every program return, including failures and disagreements. Any unresolved role, order, or retained-program failure or disagreement yields HOLD; one successful result never rescues another failed hypothesis. MemoryError, RecursionError, KeyboardInterrupt, and other resource/runtime exceptions propagate; they are not converted to semantic abstentions. No synthetic control is used to remove a teacher-consistent program.

## Prior provenance and limit

New fixed prior: two complete perpendicular boundary cues, exceptional corner, modal residual background, complete mixed components, cue-driven two-axis scan, per-axis D4 crop orientation, gapless vertical stack, maximum-width centering. Existing primitive reuse: mixed_region_dicts_for_grid, transform_grid_by_name, component_hole_count. Custom code only composes input roles, ownership, ordering, complete crop placement, finite enumeration and evidence. No HDS learning, runtime integration, repository write, admission, adoption, or performance claim is authorized here. A surviving ambiguity or missing closure is reported as HOLD with a concrete counterexample.
