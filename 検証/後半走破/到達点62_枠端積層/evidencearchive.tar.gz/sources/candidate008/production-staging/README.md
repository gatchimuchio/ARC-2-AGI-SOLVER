# candidate008: prospective cue-C4 staging

このstageは新しい240文法だけの未接続payloadと教師限定preflightを用意する。actual repositoryへの書込・登録、query/test・公式task・solution・scorerの読取／実行、Git変更、正式採用は行っていない。既存primitiveとHDS正本は許可された教師検査のためread-onlyで使用する。性能改善・一般化・未知queryの閉鎖を示す成果ではない。

## 文法と由来

元の15,360プログラム／24保持モデルは、そのsourceと全教師・全対照証拠を元の場所に保持する。新しい240文法は元24モデルの間引きではない。10 nominal cue色 × C4/C8連結 × fast/slow各2方向 × center exact/floor/ceilからなる独立したprospective文法である。既知教師と親からの提案を受けて固定したpriorであり、教師に依存しない発見とは主張しない。

区別されたcornerからcue edgeの他端へ向かう有向ベクトルをscreen-rightに送る唯一のproper C4回転を入力から決め、同じ回転を全payloadの完全cropに適用する。reflection、学習済み水平／垂直D4表、元24モデルの所属は参照しない。

payload/接続/ARC2/枠端積層幾何.pyは元prototypeの必要な9定義をAST不変で保持し、既存mixed-component、D4、hole-count primitivesを直接importする。枠端積層候補.pyは新priorの6定義をAST不変で保持する。15360文法の列挙表や未使用の旧Evaluatorをdeployしない。枠端積層教材.pyはstrict ARC教師検証と不変・target-free adapterだけを加え、最小2個の異なる教師入力を要求する。教師出力はfit境界だけで使用し、adapter stateにはモデルtupleと件数・不足理由だけを保存する。

全保持モデル、全役割、全順序の失敗と成功格子を残し、全て成功して完全出力が一致した場合だけ返す。斜め接触のC4/C8未同定とodd-width center未同定はHOLDを維持する。geometry、guard、候補集合のpruningは行わない。

## native HDSとresource境界

source-evidenceには必要な旧primitive依存、HDS v0.4.2、authority原本bytesを固定した。native_public.pyは既存公開helperの観測へ／同値原理あり／候補機構を学習のAST不変抽出であり、実際のrepository HDS classesを使用する。live bridge全体は別候補007の登録・rollbackで変わり得るため、その全体hashの不変は主張しない。3 helper ASTの一致を検証する。

同じ4教師で一度fitした6モデルを、fresh HDS minimum3／4／5へそのまま渡す。各cycleはcurrent4、prior0、quarantine0で、3と4は同値採用、5は同値未採用。fit教師数のcutoffでnative支持を代用しない。HDS queryは実行しない。

resource例外はHOLDへ変換せずcallerへ伝播する。staging adapterのobserverは完成したmodel/teacher返値を逐次通知し、失敗stage/model/teacher・完成prefix数・未評価残数を記録する。外側runnerは各通知をJSONLへflushする。途中resource中断でも完成prefixを保存し、resource_failureとordinary_HOLDを区別する。成功したmodelだけを選び直す救済はない。

## 検査と成果物

- payload/検証/枠端積層回帰.py: 引数不要・任意cwdのportable regression。専用fixture namespaceと一意のtemporary成果物を使用
- source-extraction-manifest.json: 元9 geometry定義／6 prospective定義／3 native helperのAST一致
- dependency-source-manifest.json: 必要依存とauthorityのsource bytes
- original-artifacts-before.json / original-artifacts-after.json: stage開始時の既存50成果物の完全保護。このsnapshot以前の旧metadata全体不変は主張しない
- ../all120-teacher-preflight/summary.json: 120課題359教師×240文法=86,160返値。119普通HOLD、291dc1e1だけ6モデル保持。resource／execution failureなし
- ../all120-teacher-preflight/full-evidence-integrity.json: 全86,160返値と逐次journal、exact判定、native観測の保存済み証拠照合

full120の全fit processはfresh process、10 CPU seconds、512 MiB address space、60 wall seconds、最大3 workers。fit-positiveだけ別fresh processでnative学習を行い、同じ制限を適用する。未読queryを参照した決定は一切含まない。
