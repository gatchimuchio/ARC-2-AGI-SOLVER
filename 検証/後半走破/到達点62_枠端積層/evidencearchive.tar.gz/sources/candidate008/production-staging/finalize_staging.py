"""新stage成果物だけへ最終保護検証とmanifestを保存する。"""
import sys
sys.dont_write_bytecode=True
import ast,gzip,hashlib,json
from pathlib import Path
S=Path(__file__).resolve().parent;C=S.parent;W=C.parents[1];R=W/'arc2-second-half';H=C/'all120-teacher-preflight';P=S/'payload'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def save(p,v):
 with p.open('x',encoding='utf-8') as f:json.dump(v,f,ensure_ascii=False,indent=2);f.write('\n')
def item(p,root):return {'path':str(p.relative_to(root)),'sha256':sha(p),'bytes':p.stat().st_size}
summary_path=Path(sys.argv[1]).resolve();reg=json.loads(summary_path.read_text());assert S in summary_path.parents
assert reg['successful'] is True and type(reg['tests_run']) is int and type(reg['passed_cases']) is list and reg['tests_run']==len(reg['passed_cases'])
assert all(type(case) is str for case in reg['passed_cases'])
pre=json.loads((H/'summary.json').read_text());integrity=json.loads((H/'full-evidence-integrity.json').read_text())
assert pre['successful'] and pre['completed_returns']==86160 and integrity['successful']
original=json.loads((S/'original-artifacts-before.json').read_text());after={name:sha(C/name) for name in original};assert original==after;save(S/'original-artifacts-after.json',after)
old6=json.loads((C/'prospective-cue-rotation/original-evidence-before.json').read_text());assert all(sha(C/name)==value for name,value in old6.items())
deps=json.loads((S/'dependency-source-manifest.json').read_text());assert all(sha(Path(x['source']))==x['sha256']==sha(S/x['snapshot']) for x in deps)
asts=json.loads((S/'native-helper-ast-manifest.json').read_text())['ast']
live={n.name:ast.dump(n,include_attributes=False) for n in ast.parse((R/'接続/ARC2/HDS接続.py').read_text()).body if isinstance(n,ast.FunctionDef) and n.name in asts};assert live==asts
extractions=json.loads((S/'source-extraction-manifest.json').read_text())
for proof in extractions:
 if 'ast_unchanged' in proof:
  def nodes(p):return {n.name:ast.dump(n,include_attributes=False) for n in ast.parse(p.read_text()).body if isinstance(n,(ast.ClassDef,ast.FunctionDef))}
  a,b=nodes(Path(proof['source'])),nodes(S/proof['destination']);assert all(a[n]==b[n] for n in proof['ast_unchanged'])
for path,value in json.loads((H/'execution-source-manifest.json').read_text()).items():assert sha(Path(path))==value
checks=[]
for p in sorted((P/'接続/ARC2').glob('*.py')):
 tree=ast.parse(p.read_text());imports=[];forbidden=[]
 for n in ast.walk(tree):
  if isinstance(n,(ast.Import,ast.ImportFrom)):imports.append(ast.unparse(n))
  if isinstance(n,ast.Call) and isinstance(n.func,ast.Name) and n.func.id in ('open','eval','exec','compile','__import__'):forbidden.append(n.func.id)
 assert not forbidden
 checks.append({'path':str(p.relative_to(P)),'imports':imports,'forbidden_io_or_dynamic_eval_calls':forbidden,'target_identifier_literal_present':'291dc1e1' in p.read_text()})
 assert not checks[-1]['target_identifier_literal_present']
source_manifest={'source_extractions':extractions,'dependency_source_bytes':deps,'protected_current_candidate_artifacts':after,'original_preprospective_six':old6,'original_metadata_scope':'Current 50 existing files preserved from staging start. Historical original-six proof only; not a claim all old metadata was frozen before prospective additions.','native_helper_ast_sha256':{k:hashlib.sha256(v.encode()).hexdigest() for k,v in asts.items()},'whole_bridge_baseline_claim':False,'runtime_source_scan':checks}
save(S/'source-manifest.json',source_manifest)
payload=[item(p,P) for p in sorted(P.rglob('*')) if p.is_file()]
save(S/'payload-manifest.json',{'files':payload,'file_count':len(payload),'destination':'not installed; relative paths are reviewable future repository destinations','root_README_overwrite':False,'existing_primitives_and_HDS_not_in_payload':True})
report={
 '対象':'candidate008 / prospective cue-C4 / production staging + 全120教師preflight。actualrepo未接続・query未読・採用未実施。',
 '観測':['独立した240文法を4教師にfitし6モデル保持。cue色1、fast/slow正方向、C4/C8 × center exact/floor/ceil。全4教師完成格子が一致。',f'引数不要・任意cwd回帰は{reg["tests_run"]} checks PASS。全960教師返値と87対照×6=522返値が元prospective証拠と完全一致。','全120課題359教師×240=86,160返値をfresh processで完了・完全保存。291dc1e1のみfit-positive、119普通HOLD、resource/execution failure 0。'],
 '既存規則適用結果':['既存mixed-region/D4/hole-count primitiveを直接import。元prototype必要9定義と新prospective6定義のAST不変を検証。元15360文法のmodeltableと未使用旧Evaluatorはdeployしない。','実際のHDS v0.4.2と既存公開3 helper ASTを用いたfresh native学習。fit済み同じ6モデルを再fitせずsupport3/4/5へ渡し、current4/prior0/quarantine0を各cycleで確認。'],
 '不足':['斜め接触のC4/C8とodd-width centerは教師未同定のまま。全保持モデル失敗・不一致時HOLDを維持。','未知queryに対する閉鎖・性能差分・一般化・runtime統合の可否は未確認。'],
 '候補':['cornerからcue edge他端への有向ベクトルを右へ送る唯一のproper C4回転を入力から導き、同じ回転を全payload完全cropへ適用する固定prior。reflectionや学習済みD4表なし。','不変target-free adapterはstrict ARC int/range/shape、exact input/output fields、最小2異なる教師入力を検証する。HDS支持閾値をfit数cutoffで代用しない。','全モデル・全役割・全順序の完成格子と失敗を残し、全成功全一致だけ出力。observerは完成model/teacher prefixと失敗位置・未評価残数を外側runnerへ渡す。'],
 '反証':['16 C4教師回転・40 palette対照を含む全87対照の完全返値一致。斜め接触・odd centerを含む旧HOLDを弱めていない。','MemoryError/RecursionError/TimeoutError各3箇所、計9注入で同一例外伝播・完成prefix保存・失敗model/teacher位置・未評価残数を確認。resourceをsemantic HOLDへ変換しない。','native minimum3/4は同値採用、minimum5は同値未採用かつ同値原理0。minimum5のraw排気状態は実際には出力であり、その値は原本どおり保存。同値採用gateのHOLDとraw排気を区別する。','86,160個の比較内訳はexact24、ordinary semantic HOLD85,968、非一致完成格子168。保存結果と逐次journalを全件独立照合。'],
 '適用範囲':'writeは新しいproduction-stagingとall120-teacher-preflightのみ。sanitized教師と既存自作対照・native教師観測のみを使用。actualrepoへの書込・登録なし。query/test/officialtask/solutions/scorerは未読・未実行。Git変更・正式採用なし。既存primitiveとHDS正本は許可された教師検査のためread-onlyで使用。stage開始時50既存成果物、必要22依存/authority原本、native3 helper ASTの不変を検証。元6重要成果物はpreprospective SHAとも一致。過去metadata全体不変や変動するlive bridge全体hash不変は主張しない。',
 '未確認事項':['固定priorは既知教師と親の提案後に定めたprospective仮説であり、HDSが回転を発見したとは主張しない。HDSが学習したのは完成候補と教師出力の同値支持。','actualrepoへの登録、正式runtime wrapperのobserver配線、query closure、同条件previous/current/delta、公開採用は本stageの対象外。','resource例外注入はcompleted-model/teacher境界の9箇所。全role内部の途中状態まで復旧できるとは主張しない。hard-kill時はflush済み完全journal prefixとprocess終了を保存し、不完全行・未評価残数を別分類する。'],
 '推奨次検査':['source/payload/fullartifact manifests、native同値gate、未評価prefix契約を独立レビューする。','次段階の正式runtime接続が許可された場合も固定prior・全6モデル・全仮説合意guardを変更せず、外側runnerにobserverを配線しresource分類を保持する。query/score/adoptionは別の明示scopeに従う。'],
 '証拠参照':['source-manifest.json','payload-manifest.json','full-artifact-manifest.json','original-artifacts-before.json','original-artifacts-after.json','native-helper-ast-manifest.json',str(summary_path.relative_to(S)),'../all120-teacher-preflight/summary.json','../all120-teacher-preflight/full-evidence-integrity.json','../all120-teacher-preflight/fit-results.json','../all120-teacher-preflight/native-results.json']}
assert len(report)==10;save(S/'manifest-10-fields.json',report)
summary={'successful':True,'tests_run':reg['tests_run'],'passed_cases':reg['passed_cases'],'regression_summary':str(summary_path.relative_to(S)),'payload_file_count':len(payload),'teacher_returns':960,'control_returns':522,'full120_returns':86160,'full120_positive_tasks':['291dc1e1'],'retained_models':6,'native_admission':{'3':True,'4':True,'5':False},'support5_raw_exhaust_status':'出力','resource_injections':9,'protected_original_files':len(after),'protected_dependencies':len(deps),'protected_native_helper_asts':3,'status':'STAGING_AND_TEACHER_PREFLIGHT_PASS_PENDING_INDEPENDENT_REVIEW','actual_repository_integration':False,'query_or_score_or_adoption':False}
save(S/'summary.json',summary)
excluded={'production-staging/full-artifact-manifest.json','production-staging/final-manifest-receipt.json'}
full=[item(p,C) for root in (S,H) for p in sorted(root.rglob('*')) if p.is_file() and str(p.relative_to(C)) not in excluded]
save(S/'full-artifact-manifest.json',{'scope':['production-staging','all120-teacher-preflight'],'exclusions':sorted(excluded),'file_count':len(full),'files':full})
assert all(sha(C/x['path'])==x['sha256'] for x in full)
receipt={'verified':True,'artifact_files':len(full),'payload_files':len(payload),'manifests':{n:sha(S/n) for n in ('manifest-10-fields.json','source-manifest.json','payload-manifest.json','full-artifact-manifest.json','summary.json')},'corpus_sha256':'012924cb967106a6d72e9323b83534539471c27dc4f5fba5d8d4a0dbe334c8aa'}
save(S/'final-manifest-receipt.json',receipt);print(json.dumps(receipt,ensure_ascii=False,indent=2))
