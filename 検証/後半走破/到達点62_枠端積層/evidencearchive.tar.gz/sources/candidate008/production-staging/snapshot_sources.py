"""必要な依存ソース・HDS・authorityだけを読み取り固定する。bridge全体不変は主張しない。"""
import sys
sys.dont_write_bytecode=True
import ast, hashlib, importlib, json, types
from pathlib import Path
S=Path(__file__).resolve().parent; W=S.parents[2]; R=W/'arc2-second-half'; P=S/'payload'
sys.path[:0]=[str(R),str(R/'HDS/学習系統/v0.4.2')]
pkg=types.ModuleType('cue_source_snapshot');pkg.__path__=[str(P/'接続/ARC2'),str(R/'接続/ARC2')];sys.modules[pkg.__name__]=pkg
importlib.import_module(pkg.__name__+'.枠端積層教材')
importlib.import_module('hds学習系統')
paths={Path(m.__file__).resolve() for n,m in sys.modules.items() if getattr(m,'__file__',None) and (n.startswith(pkg.__name__+'.') or n.startswith('hds学習系統'))}
paths.update(p for p in (R/'HDS/学習系統/v0.4.2').rglob('*') if p.is_file() and '__pycache__' not in p.parts)
paths.update(R/p for p in ('AGENTS.md','制御/現在状態.json','運用/権限順序.md'))
manifest=[]
for p in sorted(paths):
 if R in p.parents:
  target=S/'source-evidence/repository'/p.relative_to(R);target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(p.read_bytes())
  manifest.append({'source':str(p),'snapshot':str(target.relative_to(S)),'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'bytes':p.stat().st_size})
(S/'dependency-source-manifest.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n')
names=('観測へ','同値原理あり','候補機構を学習')
def nodes(p):return {n.name:ast.dump(n,include_attributes=False) for n in ast.parse(p.read_text()).body if isinstance(n,ast.FunctionDef) and n.name in names}
live=nodes(R/'接続/ARC2/HDS接続.py');fixed=nodes(S/'native_public.py');assert live==fixed
(S/'native-helper-ast-manifest.json').write_text(json.dumps({'source':str(R/'接続/ARC2/HDS接続.py'),'method':'three function AST identity only; whole bridge may register or roll back unrelated candidate007','functions':{n:hashlib.sha256(v.encode()).hexdigest() for n,v in fixed.items()},'ast':fixed},ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'snapshotted_dependencies':len(manifest),'helper_ast_match':True}))
