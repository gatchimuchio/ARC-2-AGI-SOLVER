# Candidate 008: two teacher-only guarded candidates

The original finite grammar retains 24 programs that exactly reproduce all four authorized teachers. It emits an output only if every retained program and every input-derived role/order alternative succeeds and agrees on the full grid. Authored asymmetric objects, diagonal contact, and odd width differences demonstrate useful HOLD behavior. These counterexamples show non-identifiability on those synthetic inputs; they do not establish failure on an actual task query, which was never read. Multiple retained programs are not by themselves a reason to reject a candidate.

A separate prospective grammar fixes one geometric prior: rotate the directed cue edge from its corner to point right, and apply the same proper C4 rotation to all payload crops. It evaluates 240 programs independently and retains six, reproducing all four teachers. This proposal was declared after the original study, motivated by the parent's instruction and known teachers, before its own fit. It is not a filter or rewrite of the original 24 programs. Their source, prior, fit results, and full control evidence remain byte-for-byte unchanged.

The prospective rotations are rot270, identity, identity, rot180 in teacher order. The new grammar agrees on the asymmetric horizontal synthetic, on all 16 teacher C4 input rotations after normalization, and on 40 palette controls. C4/C8 diagonal contact and odd-width centering remain unidentified and correctly HOLD. Both candidates await independent audit before any staging decision. No runtime admission or performance claim is made.

## Review entry points

- manifest-10-fields.json uses exactly the ten keys of the matching inventory row and distinguishes both candidates
- prospective-cue-rotation/manifest-10-fields.json records the separate geometric grammar in the same ten fields
- Both PRIOR.md and prefit-declaration.json files state and hash their grammar before the corresponding fit
- closure-counterexamples.json contains concrete original-grammar counterexamples with full outputs
- The two audit-summary/summary.json and artifact-integrity-review.json files report fit, guard behavior, and evidence checks

## Complete evidence

all-program-teacher-results.jsonl contains all 15,360 original programs and their four teacher-result references. Every reference is the SHA256 of a full canonical JSON record in teacher-result-catalog.json. teacher-input-role-inventory.json supplies complete input-derived roles and components. No failed program, role alternative, output, or failure is truncated. retained-programs.json preserves all 24 programs.

all-control-program-returns.json contains 87 teacher/synthetic controls and all 24 retained returns for each: 2,088 complete program returns. These are not held-out solver runs. The original 32 D4 controls establish input ownership invariance only; 28 yield an agreed output and 4 HOLD, without claiming whole-output D4 equivariance. Forty cyclic palette controls include every color as each semantic symbol.

The prospective directory separately contains all 240 x 4 = 960 teacher returns and 87 x 6 = 522 control returns. Its integrity review checks that the rotation derives from the input cue and is shared by all payload crops, and that original evidence remains unchanged. The two counterexample sets are not used to prune either retained set.

additional-api-controls.json checks all four permutations of two abstract equal-key groups and preserves all 24 returns when only the last program fails. Those abstract records are helper controls, not claims of geometrically valid parser inputs. Resource controls verify exception propagation. The negative teacher audit compares all original programs against a deliberately contradicted output without changing input roles.

## Reproduce

Run from /workspace/scratch/7408259c1ab2:

    python -B arc2-second-half-audit/candidate-008-border-ordered-stack/run_audit.py
    python -B arc2-second-half-audit/candidate-008-border-ordered-stack/review_artifacts.py
    python -B arc2-second-half-audit/candidate-008-border-ordered-stack/prospective-cue-rotation/run_prospective.py
    python -B arc2-second-half-audit/candidate-008-border-ordered-stack/prospective-cue-rotation/review_prospective.py

All commands write only generated evidence in this new candidate directory and disable Python bytecode. They directly import the designated existing primitives read-only; they do not invoke a solver bridge, instantiate HDS, inspect Git, or read official task, held-out query, scorer, or solution files. The accepted-reference commit label is parent-supplied; source content hashes are recorded without Git inspection.
