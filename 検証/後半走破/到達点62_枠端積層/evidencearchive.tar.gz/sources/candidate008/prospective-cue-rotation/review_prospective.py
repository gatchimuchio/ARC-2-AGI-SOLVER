"""Saved-evidence integrity checks for the separately declared cue-vector grammar."""
import hashlib
import json
from pathlib import Path
import sys

sys.dont_write_bytecode = True
HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
import prospective as q


def read(name):
    return json.loads(HERE.joinpath(name).read_text())


def require(value, message):
    if not value:
        raise AssertionError(message)


def main():
    rows = read("all-240-program-teacher-returns.json")
    teachers = json.loads(HERE.parent.joinpath("teacher-input-output.json").read_text())["train"]
    views = read("teacher-input-role-inventory.json")
    retained = read("retained-programs.json")
    require(len(rows) == 240, "missing_programs")
    require([row["program"] for row in rows] == [program.record() for program in q.all_programs()], "program_grid_changed")
    for row in rows:
        require(len(row["teacher_returns"]) == 4, "missing_teacher_return")
        exacts = []
        for i, result in enumerate(row["teacher_returns"]):
            exacts.append(result["failure"] is None and result["output"] == teachers[i]["output"])
            for rendered in result["roles"]:
                role = views[i]["roles"][rendered["role_id"]]
                vector, transform = q.cue_rotation(role, row["program"]["fast_color"])
                require(rendered["input_derived_C4_rotation"] == transform, "rotation_not_derived_from_input_cue")
                require(rendered["directed_cue_vector"] == (None if vector is None else list(vector)), "cue_vector_record_wrong")
                for alternative in rendered["alternatives"]:
                    require(all(placement["transform"] == transform for placement in alternative["placements"]),
                            "different_rotations_applied_to_payload")
        require(exacts == row["teacher_exacts"] and all(exacts) == row["retained"], "fit_metadata_wrong")
    require([row["program"] for row in rows if row["retained"]] == retained, "retained_models_changed")
    controls = read("all-control-program-returns.json")
    for row in controls:
        result = row["result"]
        returns = result["returns"]
        require(len(returns) == 6 and len({tuple(sorted(item["program"].items())) for item in returns}) == 6,
                "control_return_dropped_or_duplicated")
        failures = [i for i, item in enumerate(returns) if item["result"]["failure"]]
        outputs = {q.base.grid_key(item["result"]["output"]) for item in returns if item["result"]["failure"] is None}
        require(failures == result["failure_program_indices"] and len(outputs) == result["distinct_success_outputs"],
                "control_failures_or_disagreements_hidden")
        require(result["status"] == ("OUTPUT" if not failures and len(outputs) == 1 else "HOLD"), "consensus_guard_wrong")
    prefit = read("prefit-declaration.json")
    require(prefit["prior_sha256"] == hashlib.sha256(HERE.joinpath("PRIOR.md").read_bytes()).hexdigest(), "prior_changed_after_fit")
    require(prefit["prototype_sha256"] == hashlib.sha256(HERE.joinpath("prospective.py").read_bytes()).hexdigest(), "code_changed_after_fit")
    for name, value in read("original-evidence-before.json").items():
        require(hashlib.sha256(HERE.parent.joinpath(name).read_bytes()).hexdigest() == value, "original_24_evidence_changed")
    require(not list(HERE.rglob("*.pyc")) and not list(HERE.rglob("__pycache__")), "bytecode_created")
    report = {"status": "PASS_FOR_EVIDENCE_INTEGRITY_NOT_ADMISSION", "program_records": 240,
              "teacher_returns": 960, "retained_models": 6, "control_inputs": len(controls),
              "control_returns": len(controls) * 6, "fit_and_consensus_recomputed": True,
              "rotation_is_input_derived_and_uniform_per_role": True,
              "original_24_models_and_evidence_unchanged": True,
              "prefit_prior_and_code_hashes_unchanged": True,
              "actual_task_query_closure": "UNEXAMINED", "staging": "UNDECIDED_PENDING_INDEPENDENT_AUDIT"}
    HERE.joinpath("artifact-integrity-review.json").write_text(json.dumps(report, indent=2) + "\n")
    print(json.dumps(report))


if __name__ == "__main__":
    main()
