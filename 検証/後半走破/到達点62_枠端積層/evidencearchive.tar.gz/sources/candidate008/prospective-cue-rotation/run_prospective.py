"""Evaluate the separately declared C4 cue-normalization grammar on authorized evidence."""
from dataclasses import replace
import hashlib
import json
from pathlib import Path
import sys

sys.dont_write_bytecode = True
HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
import prospective as q


def save(name, value):
    HERE.joinpath(name).write_text(json.dumps(value, ensure_ascii=False, indent=2) + "\n")


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main():
    original_hashes = json.loads(HERE.joinpath("original-evidence-before.json").read_text())
    for name, value in original_hashes.items():
        if digest(HERE.parent / name) != value:
            raise AssertionError("original_evidence_changed_before_prospective_fit")
    save("prefit-declaration.json", {"phase": "before_separate_fit", "programs": len(q.all_programs()),
                                   "prior_sha256": digest(HERE / "PRIOR.md"),
                                   "prototype_sha256": digest(HERE / "prospective.py"),
                                   "original_grammar_filtered": False})
    source = json.loads(HERE.parent.joinpath("teacher-input-output.json").read_text())
    corpus = HERE.parents[2] / source["source"]
    if digest(corpus) != source["sha256"]:
        raise AssertionError("authorized_corpus_digest_changed")
    teachers = json.loads(corpus.read_text())[source["task"]]["train"]
    fit_records = []
    def record(number, program, results, exacts):
        fit_records.append({"program_number": number, "program": program.record(),
                            "teacher_returns": results, "teacher_exacts": exacts, "retained": all(exacts)})
    retained, views = q.fit(teachers, record)
    save("all-240-program-teacher-returns.json", fit_records)
    save("retained-programs.json", [program.record() for program in retained])
    save("teacher-input-role-inventory.json", views)
    rotations = [{"teacher": i, "roles": [{"role_id": role["id"], "corner": role["corner"],
                                             "cue_vector_and_rotation": q.cue_rotation(role, 1)} for role in view["roles"]]}
                 for i, view in enumerate(views)]
    save("teacher-input-derived-rotations.json", rotations)
    print("prospective teacher fit:", len(fit_records), "programs; retained", len(retained), flush=True)
    if not retained:
        save("summary.json", {"status": "NO_TEACHER_CONSISTENT_PROGRAM", "teacher_rotations": rotations,
                              "all_teacher_returns_saved": True, "original_evidence_unchanged": True})
        return
    original_controls = json.loads(HERE.parent.joinpath("all-control-program-returns.json").read_text())
    controls = []
    for row in original_controls:
        grid = row["result"]["input_view"]["input"]
        programs = retained
        if row["name"].startswith("palette_shift_"):
            shift = int(row["name"].split("_")[2])
            programs = [replace(program, fast_color=(program.fast_color + shift) % 10) for program in retained]
        result = q.apply_retained(programs, grid)
        controls.append({"name": row["name"], "result": result})
    save("all-control-program-returns.json", controls)
    lookup = {row["name"]: row["result"] for row in controls}
    expected = []
    for i, pair in enumerate(teachers):
        expected.append(("teacher_replay_" + str(i), pair["output"]))
        for transform in ("identity", "rot90", "rot180", "rot270"):
            expected.append(("D4_teacher_%d_%s" % (i, transform), pair["output"]))
        for shift in range(10):
            expected.append(("palette_shift_%d_teacher_%d" % (shift, i),
                             [[(v + shift) % 10 for v in line] for line in pair["output"]]))
    checks = []
    for name, output in expected:
        result = lookup[name]
        passed = result["status"] == "OUTPUT" and result["output"] == output
        checks.append({"name": name, "expected_output": output, "passed": passed})
        if not passed:
            raise AssertionError(("declared_teacher_C4_palette_control_failed", name))
    if lookup["asymmetric_horizontal_orientation_counterexample"]["status"] != "OUTPUT":
        raise AssertionError("C4_prior_did_not_resolve_authored_orientation_only_control")
    if any(lookup[name]["status"] != "HOLD" for name in ("diagonal_touch_C4_C8_counterexample", "odd_center_counterexample")):
        raise AssertionError("remaining_connectivity_or_center_ambiguity_erased")
    save("expected-controls.json", checks)
    resource = []
    original = q.base.regions.mixed_region_dicts_for_grid
    for exception in (MemoryError, RecursionError):
        def injected(*args, **kwargs):
            raise exception("prospective_authored_resource_control")
        q.base.regions.mixed_region_dicts_for_grid = injected
        try:
            q.apply_retained(retained, teachers[0]["input"])
        except exception:
            resource.append({"exception": exception.__name__, "propagated": True,
                             "semantic_abstention": False})
        else:
            raise AssertionError("prospective_resource_error_swallowed")
        finally:
            q.base.regions.mixed_region_dicts_for_grid = original
    save("resource-controls.json", resource)
    for name, value in original_hashes.items():
        if digest(HERE.parent / name) != value:
            raise AssertionError("original_evidence_changed_after_prospective_fit")
    summary = {"status": "TEACHER_ONLY_GUARDED_PROSPECTIVE_CANDIDATE", "staging": "UNDECIDED_PENDING_INDEPENDENT_AUDIT",
               "programs_evaluated": len(fit_records), "teacher_returns": 4 * len(fit_records),
               "retained": len(retained), "teacher_rotations": rotations,
               "controls": len(controls), "retained_control_returns": len(controls) * len(retained),
               "teacher_replays": 4, "C4_normalized_output_checks": 16, "palette_checks": 40,
               "all_expected_checks_passed": all(row["passed"] for row in checks),
               "asymmetric_horizontal_synthetic_status": lookup["asymmetric_horizontal_orientation_counterexample"]["status"],
               "remaining_guarded_HOLD": ["C4_C8_diagonal_contact", "nonintegral_and_left_right_centering"],
               "original_24_models_and_complete_evidence_unchanged": True,
               "new_prior_is_not_original_model_filter": True,
               "actual_task_query_closure": "UNEXAMINED", "performance_or_admission_claim": False}
    save("summary.json", summary)
    print(json.dumps(summary, ensure_ascii=False), flush=True)


if __name__ == "__main__":
    main()
