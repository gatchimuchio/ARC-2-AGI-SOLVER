"""全120のsanitized教師だけを別processで評価する。照会・score・採用は行わない。"""
from __future__ import annotations
import sys
sys.dont_write_bytecode=True
import argparse, ast, collections, concurrent.futures, copy, dataclasses, enum, gzip
import hashlib, importlib, importlib.util, json, os, resource, signal, subprocess, time, traceback, types
from pathlib import Path
HERE=Path(__file__).resolve().parent; C=HERE.parent; W=C.parents[1]
S=C/'production-staging'; P=S/'payload'; R=W/'arc2-second-half'
CORPUS=W/'arc2-restored-592d2c5-audit/evaluation-teachers-only.json'
CORPUS_SHA='012924cb967106a6d72e9323b83534539471c27dc4f5fba5d8d4a0dbe334c8aa'
LIMITS={'cpu_seconds':10,'address_space_bytes':512*1024*1024,'wall_seconds':60}

def serial(v):
    if dataclasses.is_dataclass(v):return serial(dataclasses.asdict(v))
    if isinstance(v,enum.Enum):return serial(v.value)
    if isinstance(v,dict):return {str(k):serial(x) for k,x in v.items()}
    if isinstance(v,(list,tuple)):return [serial(x) for x in v]
    if isinstance(v,(set,frozenset)):return [serial(x) for x in sorted(v)]
    if v is None or isinstance(v,(str,int,float,bool)):return v
    raise TypeError(type(v).__name__)

def encoded(v):return json.dumps(serial(v),ensure_ascii=False,sort_keys=True,separators=(',',':')).encode()
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def save(p,v):
    with p.open('x',encoding='utf-8') as f:json.dump(serial(v),f,ensure_ascii=False,indent=2);f.write('\n')
def savegz(p,v):
    data=encoded(v)
    with p.open('xb') as f:
        with gzip.GzipFile(filename='',mode='wb',fileobj=f,mtime=0,compresslevel=1) as g:g.write(data)
    return {'path':str(p.relative_to(HERE)),'sha256':sha(p),'uncompressed_sha256':hashlib.sha256(data).hexdigest(),'uncompressed_bytes':len(data)}

class CPUExceeded(TimeoutError):pass

class Journal:
    def __init__(self,p):self.f=p.open('x',encoding='utf-8');self.counts=collections.Counter();self.sequence=0
    def __call__(self,event):
        self.f.write(json.dumps(serial(dict(sequence=self.sequence,**event)),ensure_ascii=False,separators=(',',':'))+'\n');self.f.flush()
        self.sequence+=1;self.counts[event['kind']]+=1
    def close(self):self.f.close()

def load_modules():
    sys.path[:0]=[str(R),str(R/'HDS/学習系統/v0.4.2')]
    pkg=types.ModuleType('cue_preflight_local');pkg.__path__=[str(P/'接続/ARC2'),str(R/'接続/ARC2')];sys.modules[pkg.__name__]=pkg
    family=importlib.import_module(pkg.__name__+'.枠端積層教材')
    spec=importlib.util.spec_from_file_location('cue_native_public',S/'native_public.py');native=importlib.util.module_from_spec(spec);spec.loader.exec_module(native)
    imports=[]
    for name,m in sorted(sys.modules.items()):
        path=getattr(m,'__file__',None)
        if path and (name.startswith(pkg.__name__+'.') or name.startswith('hds学習系統')):
            p=Path(path).resolve();imports.append({'module':name,'path':str(p),'sha256':sha(p)})
    imports.append({'module':'cue_native_public','path':str(S/'native_public.py'),'sha256':sha(S/'native_public.py')})
    return family,native,imports

def child(args):
    resource.setrlimit(resource.RLIMIT_CPU,(10,11));resource.setrlimit(resource.RLIMIT_AS,(512*1024*1024,512*1024*1024))
    def cpu(*unused):raise CPUExceeded('SIGXCPU: enforced 10 second CPU limit')
    signal.signal(signal.SIGXCPU,cpu)
    req=json.load(sys.stdin);teachers=req['teachers'];original=copy.deepcopy(teachers)
    dest=Path(args.output).resolve();assert HERE in dest.parents;dest.mkdir(exist_ok=False)
    journal=Journal(dest/'events.jsonl');started=time.monotonic();started_cpu=time.process_time()
    row={'task_id':req['task_id'],'mode':args.mode,'limits':LIMITS,'teacher_count':len(teachers),'status':'pending'}
    guard={'active':False,'violations':[]}
    def io_guard(event,argv):
        if event!='open' or not guard['active']:return
        path,mode,flags=argv
        if isinstance(path,int):return
        p=Path(os.fsdecode(path)).resolve()
        if dest in p.parents:return
        guard['violations'].append({'path':str(p),'mode':mode,'flags':flags})
        raise PermissionError('Candidate runtime I/O outside per-task evidence directory prohibited')
    sys.addaudithook(io_guard)
    try:
        family,native,imports=load_modules();save(dest/'imported-source-manifest.json',imports)
        journal({'kind':'start','task_id':req['task_id'],'teachers':teachers,'limits':LIMITS,'cpu_rlimit':resource.getrlimit(resource.RLIMIT_CPU),'address_rlimit':resource.getrlimit(resource.RLIMIT_AS)})
        guard['active']=True
        audit={};adapter=family.枠端積層教材(teachers,監査=audit,観測=journal)
        assert audit['enumerated_model_count']==240
        records=audit['all_program_teacher_returns'];assert len(records)==240
        assert sum(len(x['teacher_returns']) for x in records)==240*len(teachers)
        retained=[x['program'] for x in records if x['retained']]
        assert retained==adapter.展開モデル()==audit['eligible_models']
        counts=collections.Counter()
        for i,item in enumerate(records):
            assert item['program_number']==i
            for j,result in enumerate(item['teacher_returns']):
                exact=result['failure'] is None and result['output']==teachers[j]['output']
                assert exact==item['teacher_exacts'][j]
                counts['exact' if exact else 'HOLD' if result['output'] is None else 'wrong_teacher_grid']+=1
            assert item['retained']==all(item['teacher_exacts'])
        row.update(fit_positive=bool(retained),retained_models=retained,program_teacher_returns=240*len(teachers),outcome_counts=dict(counts))
        row['full_fit']=savegz(dest/'full-fit.json.gz',audit)
        shared=adapter.モデル群;frozen=dataclasses.asdict(adapter)
        if args.mode=='native':
            assert retained==req['expected_models'] and row['full_fit']['uncompressed_sha256']==req['expected_fit_digest']
            def no_refit(*a,**k):raise AssertionError('Native support cycle must reuse the same teacher-fitted models')
            family.fit=no_refit
            class ObservedMachine(native.HDS学習実行系):
                def __init__(self,**kw):super().__init__(**kw);self.saved=[]
                def 実行(self,observation):
                    result=super().実行(observation);self.saved.append(result)
                    journal({'kind':'native_observation','observation':observation,'result':result});return result
                def 照会(self,*a,**k):raise AssertionError('HDS query prohibited')
            cycles=[];supports=sorted({2 if len(teachers)==2 else 3,len(teachers),len(teachers)+1})
            for minimum in supports:
                machine=ObservedMachine(最小支持数=minimum);assert machine.台帳.件数('観測台帳')==0
                calls=[]
                def observed(grid,policy):
                    output,detail=adapter.候補(grid,policy,観測=journal)
                    calls.append({'input':copy.deepcopy(grid),'output':output,'record':detail});return output,detail
                result=native.候補機構を学習(machine,{'train':teachers},(),'ARC枠端積層',observed)
                admitted=len(teachers)>=minimum
                assert result['採用可'] and result['同値採用']==admitted and result['事前観測数']==0 and result['現在観測数']==len(teachers) and result['隔離数']==0
                obs=machine.台帳.取得('観測台帳');assert len(obs)==len(teachers)==len(calls)==len(machine.saved)
                for observation,t,called in zip(obs,teachers,calls):
                    assert observation.原入力=={'候補':t['output'],'出力':t['output']} and called['input']==t['input'] and called['output']==t['output']
                last=machine.saved[-1]
                eq=[p for p in last.有効原理群 if p.対象系境界=='ARC枠端積層' and p.関係型=='同値関係' and p.条件経路群==(('候補',),) and p.結果経路==('出力',)]
                assert bool(eq)==admitted
                refs={o.経験識別子 for o in obs};assert all(set(p.根拠参照群)==refs for p in eq)
                full={'minimum_support':minimum,'teacher_fit_minimum':2,'learning_return':result,'candidate_calls':calls,'native_results':machine.saved,'ledger':machine.台帳.JSON相当(),'equality':eq,'exhaust':native.最小排気系().排出する(last),'same_fitted_models':retained}
                artifact=savegz(dest/('native-support-'+str(minimum)+'.json.gz'),full)
                cycles.append({'minimum_support':minimum,'admitted':admitted,'learning_return':result,'observation_count':len(obs),'evidence':artifact})
                assert adapter.モデル群 is shared
            row.update(native_cycles=cycles,native_fit_calls=1)
        assert teachers==original and dataclasses.asdict(adapter)==frozen and not guard['violations']
        row.update(status='fit_positive' if retained else 'ordinary_HOLD',teachers_preserved=True,adapter_preserved=True)
    except BaseException as exc:
        resource_failure=isinstance(exc,(MemoryError,RecursionError,TimeoutError))
        row.update(status='resource_failure' if resource_failure else 'execution_error',exception=type(exc).__name__,error=str(exc),traceback=traceback.format_exc(),semantic_HOLD=False)
        try:journal({'kind':'process_exception','exception':type(exc).__name__,'message':str(exc),'resource_failure':resource_failure,'semantic_HOLD':False})
        except BaseException:pass
    finally:
        guard['active']=False
        row.update(cpu_seconds=time.process_time()-started_cpu,wall_seconds=time.monotonic()-started,maxrss_kib=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,runtime_io_guard=guard,journal_counts=dict(journal.counts))
        journal.close();save(dest/'summary.json',row)
        print(json.dumps(serial(row),ensure_ascii=False),flush=True)
    return 0 if row['status'] in ('fit_positive','ordinary_HOLD') else 2

def prefix(dest,planned):
    path=dest/'events.jsonl';counts=collections.Counter();last=None;complete=0;bad=False
    if path.exists():
        for line in path.open(encoding='utf-8'):
            try:event=json.loads(line)
            except json.JSONDecodeError:bad=True;break
            counts[event['kind']]+=1
            if event['kind']=='model_teacher_return':complete+=1;last={'model_index':event['model_index'],'teacher_index':event['teacher_index']}
    return {'events':dict(counts),'completed_model_teacher_returns':complete,'last_completed':last,'planned_returns':planned,'unevaluated_returns':planned-complete,'truncated_last_record':bad,'complete_prefix_retained':True}

def run_one(mode,task_id,teachers,expected=None):
    dest=HERE/mode/task_id
    req={'task_id':task_id,'teachers':teachers}
    if expected:req.update(expected_models=expected['retained_models'],expected_fit_digest=expected['full_fit']['uncompressed_sha256'])
    p=subprocess.Popen([sys.executable,'-B',str(Path(__file__).resolve()),'--child','--mode',mode,'--output',str(dest)],stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True,cwd='/tmp',env=dict(os.environ,PYTHONDONTWRITEBYTECODE='1'))
    timed_out=False
    try:out,err=p.communicate(json.dumps(req),timeout=60)
    except subprocess.TimeoutExpired:
        timed_out=True;p.kill();out,err=p.communicate()
    if not dest.exists():dest.mkdir(parents=True)
    (dest/'stdout.txt').write_text(out);(dest/'stderr.txt').write_text(err)
    if (dest/'summary.json').exists():row=json.loads((dest/'summary.json').read_text())
    else:row={'task_id':task_id,'teacher_count':len(teachers),'mode':mode,'status':'resource_failure' if timed_out or p.returncode<0 else 'execution_error','semantic_HOLD':False,'error':'wall_timeout' if timed_out else 'process_exit_without_summary'}
    row.update(process_exit=p.returncode,wall_timeout=timed_out,process_status='complete' if p.returncode==0 and not timed_out else 'resource_failure' if timed_out or p.returncode<0 or row['status']=='resource_failure' else 'execution_error',prefix=prefix(dest,240*len(teachers)))
    save(dest/'process-result.json',row);return row

def protected_check():
    original=json.loads((S/'original-artifacts-before.json').read_text())
    assert all(sha(C/p)==v for p,v in original.items())
    deps=json.loads((S/'dependency-source-manifest.json').read_text())
    assert all(sha(Path(x['source']))==x['sha256'] for x in deps)
    expected=json.loads((S/'native-helper-ast-manifest.json').read_text())['ast']
    actual={n.name:ast.dump(n,include_attributes=False) for n in ast.parse((R/'接続/ARC2/HDS接続.py').read_text()).body if isinstance(n,ast.FunctionDef) and n.name in expected}
    assert actual==expected
    return {'original_candidate_files_unchanged':len(original),'dependency_files_unchanged':len(deps),'native_helper_asts_unchanged':len(expected),'whole_bridge_baseline_claim':False}

def main():
    assert sha(CORPUS)==CORPUS_SHA;corpus=json.loads(CORPUS.read_text())
    assert len(corpus)==120 and sum(len(t['train']) for t in corpus.values())==359
    assert all(set(t)=={'train'} and all(set(p)=={'input','output'} for p in t['train']) for t in corpus.values())
    save(HERE/'before-protection.json',protected_check())
    codepaths=[p for p in P.rglob('*.py') if p.parent.name=='ARC2']+[S/'native_public.py',Path(__file__).resolve()]
    codehash={str(p):sha(p) for p in codepaths}
    save(HERE/'execution-source-manifest.json',codehash)
    save(HERE/'prefit-contract.json',{'corpus':str(CORPUS),'sha256':CORPUS_SHA,'tasks':120,'teachers':359,'grammar_size':240,'planned_model_teacher_returns':86160,'limits':LIMITS,'maximum_workers':3,'phases':['full_fit_with_incremental_journal','fresh_native_for_fit_positives'],'native_threshold_rule':'same fitted models; fresh supports {default2or3,n,n+1}; 291dc1e1 uses 3/4/5','excluded':['officialtask','query','scorer','solutions','Git','actual_repository_writes']})
    def batch(mode,ids,lookup=None):
        (HERE/mode).mkdir(exist_ok=False);rows=[]
        with concurrent.futures.ThreadPoolExecutor(max_workers=3) as pool:
            fs={pool.submit(run_one,mode,k,corpus[k]['train'],lookup[k] if lookup else None):k for k in ids}
            for f in concurrent.futures.as_completed(fs):
                row=f.result();rows.append(row)
                if row.get('fit_positive') or row['process_status']!='complete':print(json.dumps({'task':row['task_id'],'mode':mode,'status':row['status'],'models':len(row.get('retained_models',[]))}),flush=True)
        rows.sort(key=lambda x:x['task_id']);save(HERE/(mode+'-results.json'),rows);return rows
    rows=batch('fit',sorted(corpus));positives={r['task_id']:r for r in rows if r['process_status']=='complete' and r.get('fit_positive')}
    native=batch('native',sorted(positives),positives)
    after=protected_check();assert all(sha(Path(p))==v for p,v in codehash.items())
    save(HERE/'after-protection.json',after)
    summary={'successful':all(r['process_status']=='complete' for r in rows+native),'tasks':120,'teachers':359,'grammar_size':240,'planned_returns':86160,'completed_returns':sum(r['prefix']['completed_model_teacher_returns'] for r in rows),'fit_positive_tasks':sorted(positives),'fit_positive_models':{k:r['retained_models'] for k,r in positives.items()},'ordinary_HOLD_tasks':sum(r['status']=='ordinary_HOLD' for r in rows),'resource_failures':[r['task_id'] for r in rows+native if r['process_status']=='resource_failure'],'execution_failures':[r['task_id'] for r in rows+native if r['process_status']=='execution_error'],'native_positive_tasks':len(native),'limits':LIMITS,'source_protection':after,'query_or_score_or_adoption':False}
    save(HERE/'summary.json',summary);print(json.dumps(summary,ensure_ascii=False),flush=True)

if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('--child',action='store_true');parser.add_argument('--mode',choices=['fit','native']);parser.add_argument('--output');args=parser.parse_args()
    if args.child:raise SystemExit(child(args))
    main()
