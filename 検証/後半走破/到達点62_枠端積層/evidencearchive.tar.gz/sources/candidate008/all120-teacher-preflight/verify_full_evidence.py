"""保存済み全返値・journal・native観測を独立に照合する。候補の再評価は行わない。"""
from pathlib import Path
from itertools import product
import gzip,hashlib,json,collections
H=Path(__file__).resolve().parent;W=H.parents[2];C=H.parent
CORPUS=W/'arc2-restored-592d2c5-audit/evaluation-teachers-only.json'
corpus=json.loads(CORPUS.read_text());assert hashlib.sha256(CORPUS.read_bytes()).hexdigest()=='012924cb967106a6d72e9323b83534539471c27dc4f5fba5d8d4a0dbe334c8aa'
models=[dict(zip(('fast_color','connectivity','fast_sign','slow_sign','center'),p)) for p in product(range(10),(4,8),(1,-1),(1,-1),('exact','floor','ceil'))]
passed=[];outcomes=collections.Counter();total=0;positives=[]
for result in json.loads((H/'fit-results.json').read_text()):
 task=result['task_id'];teachers=corpus[task]['train'];D=H/'fit'/task
 assert result['process_status']=='complete' and result['process_exit']==0 and not result['runtime_io_guard']['violations']
 audit=json.loads(gzip.decompress((D/'full-fit.json.gz').read_bytes()))
 raw=gzip.decompress((D/'full-fit.json.gz').read_bytes());assert hashlib.sha256(raw).hexdigest()==result['full_fit']['uncompressed_sha256']
 records=audit['all_program_teacher_returns'];assert len(records)==240
 events=[json.loads(line) for line in (D/'events.jsonl').read_text().splitlines()]
 returns=[e for e in events if e['kind']=='model_teacher_return'];completed=[e for e in events if e['kind']=='model_completed']
 assert len(returns)==240*len(teachers) and len(completed)==240
 retained=[]
 for i,(model,record) in enumerate(zip(models,records)):
  assert record['program_number']==i and record['program']==model
  assert len(record['teacher_returns'])==len(teachers)
  exacts=[]
  for j,(teacher,value) in enumerate(zip(teachers,record['teacher_returns'])):
   event=returns[i*len(teachers)+j]
   exact=value['failure'] is None and value['output']==teacher['output'];exacts.append(exact)
   assert event['model_index']==i and event['teacher_index']==j and event['program']==model and event['result']==value and event['exact']==exact
   assert event['completed_returns']==i*len(teachers)+j+1
   outcomes['exact' if exact else 'HOLD' if value['output'] is None else 'wrong_teacher_grid']+=1;total+=1
  assert record['teacher_exacts']==exacts and record['retained']==all(exacts)
  assert completed[i]['record']==record
  if all(exacts):retained.append(model)
 assert audit['eligible_models']==retained==result['retained_models']
 if retained:positives.append(task)
 assert result['prefix']['completed_model_teacher_returns']==240*len(teachers) and result['prefix']['unevaluated_returns']==0
passed.append('all_120_full_fit_and_journal_returns_match_86160_exact_comparisons')
assert total==86160 and positives==['291dc1e1']
assert outcomes=={'HOLD':85968,'exact':24,'wrong_teacher_grid':168}
passed.append('one_positive_six_models_119_ordinary_HOLD_no_resource_failures')
for native in json.loads((H/'native-results.json').read_text()):
 task=native['task_id'];assert task in positives
 assert native['process_status']=='complete' and native['native_fit_calls']==1
 assert [c['minimum_support'] for c in native['native_cycles']]==[3,4,5]
 for cycle in native['native_cycles']:
  data=json.loads(gzip.decompress((H/cycle['evidence']['path']).read_bytes()))
  raw=gzip.decompress((H/cycle['evidence']['path']).read_bytes());assert hashlib.sha256(raw).hexdigest()==cycle['evidence']['uncompressed_sha256']
  record=data['learning_return'];assert record['現在観測数']==4 and record['事前観測数']==0 and record['隔離数']==0 and record['採用可']
  assert record['同値採用']==(cycle['minimum_support'] in (3,4))
  assert len(data['candidate_calls'])==len(data['native_results'])==4
  assert data['same_fitted_models']==native['retained_models']
  for t,called in zip(corpus[task]['train'],data['candidate_calls']):
   assert t['input']==called['input'] and t['output']==called['output']
   assert len(called['record']['returns'])==6
passed.append('native_actual_HDS_same_six_models_support_3_4_admit_5_hold_all_four_observations')
summary={'successful':True,'tests_run':len(passed),'passed_cases':passed,'all_model_teacher_returns':total,'outcomes':dict(outcomes),'fit_positive_tasks':positives,'method':'stored full evidence recheck; no candidate rerun, query, score or adoption'}
assert type(summary['successful']) is bool and type(summary['tests_run']) is int and type(summary['passed_cases']) is list
with (H/'full-evidence-integrity.json').open('x') as f:json.dump(summary,f,ensure_ascii=False,indent=2);f.write('\n')
print(json.dumps(summary,ensure_ascii=False))
