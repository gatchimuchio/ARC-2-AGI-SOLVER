"""Build only candidate008's conditional, append-only local evidence package.

No solver execution, source edit, Git write, target read, or publication occurs.
All writes are below this script's admission-staging directory.
"""
from __future__ import annotations
import ast
from collections import Counter
from copy import deepcopy
import gzip
import hashlib
import io
import json
from pathlib import Path
import shutil
import subprocess
import tarfile

S = Path(__file__).resolve().parent
C = S.parent
A = C.parent
W = A.parent
R = W / 'arc2-second-half'
BASE = 'd2bbed2ac72d30cb7024de0f7839d656ae770689'
ROOT = '検証/後半走破/到達点62_枠端積層'
OLDROOT = '検証/後半走破/到達点61_距離回収'
RULE = 'arc2-comparison-069'
ATTEMPT = 'attempt-008-cue-aligned-stack'

def sha(b): return hashlib.sha256(b).hexdigest()
def blob(b): return hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()
def dump(p, d):
    p = S / p
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_text(json.dumps(d, ensure_ascii=False, indent=2)+'\n')
def read(p): return json.loads(Path(p).read_text())
def cpath(p): return 'sources/candidate008/'+p
def apath(p): return 'sources/audit/'+p
def rpath(p): return 'sources/repository/'+p

# Capture every original candidate file before reading/generating any package data.
candidate_files = sorted(p for p in C.rglob('*') if p.is_file() and S not in p.parents)
assert not any(p.is_symlink() for p in candidate_files)
source_specs = {}
def capture(p, virtual):
    p = Path(p)
    b = p.read_bytes()
    if virtual in source_specs:
        assert source_specs[virtual]['sha256'] == sha(b)
        return
    dst = S / virtual
    dst.parent.mkdir(parents=True, exist_ok=True)
    dst.write_bytes(b)
    source_specs[virtual] = {'path': virtual, 'source_path': str(p), 'bytes': len(b), 'sha256': sha(b)}
for p in candidate_files: capture(p, cpath(str(p.relative_to(C))))
freeze = read(C/'production-freeze.json')
assert sha((C/'production-freeze.json').read_bytes()) == 'ff537f954aab18b0333ead9d3d37c1274d6d8ecb516b628a885b7fcd11afde24'
freeze_checks = []
for p, expected in freeze['files'].items():
    p = Path(p)
    assert sha(p.read_bytes()) == expected, ('freeze changed', str(p))
    if p.is_relative_to(C): virtual = cpath(str(p.relative_to(C)))
    elif p.is_relative_to(R): virtual = rpath(str(p.relative_to(R)))
    else: raise AssertionError(('unscoped frozen source', str(p)))
    capture(p, virtual)
    freeze_checks.append({'original_path': str(p), 'archive_path': virtual, 'sha256': expected})
assert len(freeze_checks) == 232
reviewers = sorted(A.glob('reviewer-candidate008-*.json'))
assert len(reviewers) == 8
for p in reviewers: capture(p, apath(p.name))
for name in ['replay_candidate_observations_v3.py', 'index_replay_failures_v2.py',
             'run_all_regressions.py', 'compare_saved_evaluations.py',
             'checkpoint60-original-public.json', 'baseline-fresh.json',
             'baseline-fresh-regressions.json']:
    capture(A/name, apath(name))
# Only the accepted prior score is needed from candidate002; no other candidate
# payload is imported or rewritten. Its published ledger resolves through Git pins.
capture(A/'candidate-002-distance-collection/optimized-official.json',
        'sources/accepted061/optimized-official.json')

old_ledger_path = R/OLDROOT/'学習台帳/ARC2規則台帳_delta_068_v1.json'
old_ledger = read(old_ledger_path)
template = old_ledger['規則'][0]
old_experience = json.loads((R/OLDROOT/'学習台帳/ARC2規則経験_delta_068_v1.jsonl').read_text())
fields = list(template['項目'])
origins = list(template['由来五分類'])
assert len(fields) == 21 and len(origins) == 5

# Byte-pinned immutable published base, including all candidate002 evidence needed
# to resolve its old, unchanged row and its pre-publication null metadata.
pin_paths = sorted([str(p.relative_to(R)) for p in (R/'学習台帳').iterdir() if p.is_file()]
                   +[str(p.relative_to(R)) for p in (R/OLDROOT).rglob('*') if p.is_file()])
pins = []
for rp in pin_paths:
    b = subprocess.check_output(['git', '-C', str(R), 'show', BASE+':'+rp])
    assert b == (R/rp).read_bytes(), ('published base changed', rp)
    pins.append({'repository_path': rp, 'commit': BASE, 'git_blob_sha': blob(b),
                 'sha256': sha(b), 'bytes': len(b), 'storage': 'external_pinned_repository',
                 'byte_identity_verified': True})
dump('external-references.json', {'schema':'arc2-lossless-pinned-external-references-v1',
     'pinned_commit':BASE, 'members':pins, 'member_count':len(pins),
     'semantics':'Resolve each exact Git commit/path/blob and verify byte length and SHA256. These existing repository bytes are not republished or modified. Old candidate002 publication metadata remains historical; the outer d2bbed2 pin identifies its actual published bytes.'})

official = read(C/'current-official.json')
comparison = read(C/'current-comparison.json')
metrics = read(C/'checkpoint-metrics.json')
primitive = read(C/'primitive-accounting-proposal.json')
preflight = read(C/'all120-teacher-preflight/summary.json')
native = read(C/'all120-teacher-preflight/native/291dc1e1/summary.json')
teacher_review = read(A/'reviewer-candidate008-teacher-evidence.json')
source_review = read(A/'reviewer-candidate008-source.json')
score_review = read(A/'reviewer-candidate008-score.json')
replay_review = read(A/'reviewer-candidate008-replay.json')
metrics_review = read(A/'reviewer-candidate008-metrics.json')
assert [official['summary'][k] for k in ['correct_tasks','correct_examples','unanswered']] == [62,87,80]
assert comparison['old_correct_grid_count'] == 86
assert primitive['new_semantic_primitive_count'] == metrics_review['new_semantic_helpers'] == 5

ftext = {
'対象':'相異なるcorner・horizontal-edge・vertical-edgeの一様境界記号と、残余領域の背景仮説・全foreground混色成分・完全crop。4隅を全列挙し、全foregroundの所有を検証する。',
'役割':'guideとpayloadを入力のみから分離する。背景は残余領域の全最頻色候補を保持しguide記号と区別する。cue色は10色を文法に含め、教師fitで1を保持した。色番号自体を幾何priorとしない。',
'観測事実':'同条件の公開120課題167例はaccepted61/86からcandidate62/87へ。新正解は291dc1e1の1例、旧86正解格子は同一、partial7、HOLD80、wrong grid0、resource0。69回帰script1983checkが成功した。',
'関係':'cornerからcue辺他端への有向vectorを右へ送る一意のproper C4回転を毎入力で導出する。同じ回転をそのroleの全完全cropへ適用し、cue軸・他軸の距離順で積層する。',
'条件':'全240 programを全教師上で実行し、全role・全順序の成功と完全教師格子一致で残る全6モデルを保持する。照会も全6モデル・全role・全順序の成功と完全格子合意を要し、native同値採用、隔離、排気gateを通る。',
'作用':'cue導出proper C4回転後の全cropを、最大crop幅のgapless縦stackへexact/floor/ceil規約で中央配置する。余白はその入力roleの背景色。guideのみ消費し、全payloadを保持する。',
'保存条件':'全foreground所有と完全crop内の他成分混入を検査し、crop全色count・foreground色count・穴数・全体foregroundを保存する。入力、教師、immutable保持6モデルは不変。旧67台帳と068既公開bytesは不変。',
'反証条件':'教師格子の非一致・role失敗・順序失敗・成分不完全所有・crop他成分混入・ARC範囲外・非整数中央・返値競合は成功根拠にならない。MemoryError/RecursionError/TimeoutError等の資源例外は再送出し、semantic HOLDへ変換しない。',
'競合条件':'複数role、完全key同点順序、4/8 connectivity、中央規約、保持model、採用済みfamilyのいずれかが異なる完全格子を出す場合は全体HOLD。成功した一部モデルだけを選ばない。',
'HOLD条件':'保持modelなし、任意の保持model/role/order失敗、完全格子競合、同値未採用、隔離または既存排気保留。C4/C8 diagonal-contactとodd-center対照はHOLDのまま。資源失敗は別状態。',
'支持経験':'公開全120課題359教師の240 program全86160返値を保存。唯一291dc1e1で6モデル保持、24 exact teacher-return、168非一致teacher-grid、85968 semantic HOLD。nativeは4教師実観測、prior0、quarantine0、support3/4同値採用、support5同値不採用。',
'反例経験':'元15360/24文法の全返値・negative教師・全対照、別prospective240/6の全返値・87対照522保持model返値・native支持5不採用・資源注入9scenarioを全保存。全120の候補返値失敗8218と最終HOLD80は原rawへ戻れる索引を持つ。',
'適用範囲':'宣言済み境界roleと完全混色crop、proper C4 cue正規化、教師でfitする固定240文法に限定する。公開evaluationでの改善であり、未見・hidden・一般汎化の証明ではない。新規文章経験の長寿命HDS再投入は未実施。',
'教師fitで選択':'10 cue色×2 connectivity×2 fast符号×2 slow符号×3中央規約の240全programから、全4教師の完全一致でcue1・両符号+1の6モデルを保持。connectivity4/8と中央exact/floor/ceilは未識別のまま全部残す。',
'入力から毎回導出':'4隅・一様辺・背景全最頻候補・guide/payload全所有・混色成分・完全crop・有向cue vector・proper C4回転・距離key・全同点順序・寸法と保存検査を照会入力だけから再導出する。',
'固定prior':'既知教師を見た元15360/24研究の後、別fit前に宣言したprospective規約。cue辺有向vectorを右へ送るproper C4を同roleの全payloadへ共通適用する。独立発見・教師非依存prior・元24モデルのpruningとは呼ばない。',
'旧資産由来':'accepted mainのmixed_region_dicts_for_grid、transform_grid_by_name、component_hole_countの3関数を直接再利用。HDS v0.4.2と既存同値/隔離/排気を維持。22 dependency sourceは22 semantic helperではない。旧trial AST再用はmain既存資産再用と別に記録する。',
'新規固定文法':'全240 Cartesian program、境界全role、全同点順序、cue由来共通proper C4、完全crop積層と全成功全合意guard。元15360/24文法を別の完全な履歴として保存する。HDSが文法を発見したとはしない。',
'新規実装':'同じ計数定義で新semantic helperはcomponent_inventory、prepare_input、all_orders、render_role、cue_rotationの5。utility、列挙、consensus、fit、serialization、HDS adapterを除く。002の4と合わせbaseline60から累計9。family増分は1、累計2でありHDS独立学習原理数ではない。',
'HDSが実際に学習した要素':'同一6保持モデルによる候補出力と教師出力の同値を、既存HDS実行と4個の実観測参照で学習した。support3/4で同値原理が採用されsupport5では不採用。raw排気状態は全て出力かつprediction空をそのまま保存し、状態だけから採用や答えを推定しない。C4意味・文法・役割発見をHDSの学習とはしない。',
'関連する他規則':'旧比較031成分直列と047物体群整列には契約差があり、既存規則だけで新2課題を閉じた件数は0/2。旧primitiveを含む新familyで閉じた件数は2/2（068距離回収と069枠端積層）。旧契約の同一性や未確認一般化は主張しない。'
}
assert list(ftext) == fields
otext = {
origins[0]: ftext['HDSが実際に学習した要素'],
origins[1]: ftext['教師fitで選択'],
origins[2]: ftext['固定prior'],
origins[3]: ftext['旧資産由来'],
origins[4]: ftext['新規固定文法']+' '+ftext['新規実装']
}
limits = [
 '公開evaluationの61→62完全課題/86→87例であり、未見またはhidden汎化の証明ではない。',
 '既知教師研究後の別prospective固定prior。元15360/24からのpruningでもHDS発見でもない。',
 'prospective以前の不変証明は重要6原成果物のみ。root metadataは後から生成・更新され、旧metadata全体不変の主張はしない。',
 '最初の817成功regressionには実行script単体freezeがない。最終821と現行69/1983はsource hash付き。初期失敗があったという証拠はない。',
 '直接fit/query observerは完了teacher/model境界のprefixを保存する。未完了role/order内部prefixを完全に記録する保証はなく、whole native solverはfinal結果のみ。',
 '資源合成注入はMemoryError/RecursionError/TimeoutError×3境界=9scenario。実CPU/AS枯渇、wall hard kill、切れたjournalの実証ではない。Python open auditはOS隔離ではない。',
 '現在全replay8751callの返却診断を記録した別観測。原歴史実行そのものではなく、未公開内部仮説まで網羅するclaimではない。',
 'support5は同値不採用・予測空である一方raw排気は出力。この原記録を改変せず、排気文字列単独を採用根拠にしない。',
 '過去別trialのcandidate007 wrong1、candidate004 resource3等は別履歴に残る。accepted scoreのwrong0/resource0で消し去らない。他候補payloadは本採用へ含めない。',
 '新069文章経験は既存67/068長寿命HDSへ再投入しない。HDS core v0.4.2は不変。vNext未実装。',
 '親の正確package監査・ADMIT・publicationは未実施。公開commitとその親commitは未確定でありnull。'
]
comp = {'スキーマ版':'arc2-candidate008-admission-comparison-v1','attempt_id':ATTEMPT,
 '規則ID':RULE,'状態':'local_conditional_package_parent_exact_audit_and_ADMIT_pending',
 'publication_commit':None,'publication_parent_commit':None,
 'accepted_solver_baseline':BASE,'source_resolution_root':ROOT,
 '規則21項目':ftext,'由来五分類':otext,
 'same_conditions':{k:official['summary'][k] for k in ['tasks','test_examples','challenge_sha256','solutions_sha256','cpu_seconds_per_task','address_space_mib','wall_seconds_per_task','workers']},
 'previous':score_review['previous'],'current':score_review['current'],'delta':score_review['delta'],
 'baseline60':metrics['baseline60'],'delta_from60':metrics['delta_from60'],
 'gate_evidence':{'score':apath('reviewer-candidate008-score.json'), 'teacher':apath('reviewer-candidate008-teacher-evidence.json'), 'replay':apath('reviewer-candidate008-replay.json'), 'metrics':apath('reviewer-candidate008-metrics.json')},
 'limitations':limits,
 'source_paths':{'original_pending_checkpoint':cpath('checkpoint-metrics.json'),'current_official':cpath('current-official.json'),'full_comparison':cpath('current-comparison.json'),'all_teacher_returns':cpath('all120-teacher-preflight/'),'direct_query_journal':cpath('input-only-journals/run-000.jsonl'),'current_all_return_raw':cpath('current-full-replay/raw.jsonl.gz'),'negative_index':cpath('current-full-replay/failure-events-v2.jsonl.gz')},
 'classification_author':'外部監査による出典分類。Learning Machine自身の出力ではない。'}
dump('比較.json', comp)

def getptr(value, pointer):
    for part in pointer.split('/')[1:]:
        part = part.replace('~1','/').replace('~0','~')
        value = value[int(part)] if isinstance(value,list) else value[part]
    return value
def jev(path, pointer, kind='prepublication_saved_artifact'):
    b = (S/path).read_bytes()
    obj = json.loads(gzip.decompress(b) if path.endswith('.gz') else b)
    v = getptr(obj,pointer)
    q = v if isinstance(v,str) else json.dumps(v,ensure_ascii=False,separators=(',',':'))
    return {'source_path':path,'content_sha256':sha(b),'pointer':pointer,'quote':q,
     'codepoint_span':[0,len(q)],'source_value_type':type(v).__name__,
     'quote_mode':'leaf' if isinstance(v,str) else 'typed_value','ref':None,'source_kind':kind}
def lines_ev(path,start,end,kind='prepublication_frozen_code'):
    b=(S/path).read_bytes();ls=b.decode().splitlines();q='\n'.join(ls[start-1:end])
    return {'source_path':path,'content_sha256':sha(b),'blob_sha':blob(b),'ref':None,
     'source_kind':kind,'line_start':start,'line_end':end,'quote':q,
     'evidence_kind':'凍結原文。新規宣言・実装とnative学習を混同しない'}
def func(path,name):
    tree=ast.parse((S/path).read_text())
    node=next(n for n in tree.body if isinstance(n,(ast.FunctionDef,ast.ClassDef)) and n.name==name)
    return lines_ev(path,min([node.lineno]+[x.lineno for x in getattr(node,'decorator_list',[])]),node.end_lineno)
geom=rpath('接続/ARC2/枠端積層幾何.py')
core=rpath('接続/ARC2/枠端積層候補.py')
adapter=rpath('接続/ARC2/枠端積層教材.py')
bridge=rpath('接続/ARC2/HDS接続.py')
prior=cpath('prospective-cue-rotation/PRIOR.md')
prior_ev=lines_ev(prior,3,len((S/prior).read_text().splitlines()),'prospective_fixed_prior_declaration')
prior_contract_ev=lines_ev(prior,5,7,'prospective_fixed_prior_declaration')
g={k:func(geom,k) for k in ['component_inventory','prepare_input','all_orders','render_role','collapse']}
k={n:func(core,n) for n in ['all_programs','cue_rotation','Evaluator','fit','apply_retained']}
a={'全枠端モデルを照会':func(adapter,'predict'),'枠端積層教材':func(adapter,'枠端積層教材')}
b={n:func(bridge,n) for n in ['出力格子','候補機構を学習','課題を解く']}
natural = {
'対象':[g['prepare_input'],g['component_inventory']], '役割':[g['prepare_input'],k['all_programs']],
'観測事実':[jev(apath('reviewer-candidate008-score.json'),'/current'),jev(cpath('current-comparison.json'),'/delta'),jev(apath('reviewer-candidate008-integration.json'),'/regression_checks')],
'関係':[k['cue_rotation'],g['all_orders'],prior_contract_ev],
'条件':[k['fit'],k['apply_retained'],a['全枠端モデルを照会'],b['出力格子'],b['候補機構を学習']],
'作用':[k['Evaluator'],g['render_role']], '保存条件':[g['component_inventory'],g['render_role'],a['枠端積層教材']],
'反証条件':[g['component_inventory'],g['render_role'],a['全枠端モデルを照会']],
'競合条件':[g['collapse'],k['apply_retained'],b['課題を解く']],
'HOLD条件':[g['collapse'],a['全枠端モデルを照会'],b['出力格子'],jev(cpath('prospective-cue-rotation/summary.json'),'/remaining_guarded_HOLD')],
'支持経験':[jev(cpath('all120-teacher-preflight/summary.json'),'/fit_positive_models'),jev(cpath('all120-teacher-preflight/native/291dc1e1/summary.json'),'/native_cycles'),jev(apath('reviewer-candidate008-teacher-evidence.json'),'/観測/full120/outcomes')],
'反例経験':[jev(cpath('negative-teacher-summary.json'),'/retained'),jev(cpath('prospective-cue-rotation/summary.json'),'/remaining_guarded_HOLD'),jev(apath('reviewer-candidate008-teacher-evidence.json'),'/反証'),jev(cpath('current-full-replay/failure-index-summary-v2.json'),'/counts')],
'適用範囲':[prior_ev,g['prepare_input'],jev(apath('reviewer-candidate008-replay.json'),'/scope')],
'教師fitで選択':[k['all_programs'],k['fit'],jev(cpath('all120-teacher-preflight/summary.json'),'/fit_positive_models')],
'入力から毎回導出':[g['prepare_input'],g['component_inventory'],k['cue_rotation'],g['all_orders']],
'固定prior':[prior_ev,jev(cpath('metadata-v2/preservation-scope-addendum.json'),'/preservation_scope_ja')],
'旧資産由来':[jev(cpath('primitive-accounting-proposal.json'),'/existing_main_code_reuse'),jev(apath('reviewer-candidate008-source.json'),'/AST_definitions_independently_equal')],
'新規固定文法':[prior_ev,k['all_programs'],g['collapse'],k['apply_retained']],
'新規実装':[jev(cpath('primitive-accounting-proposal.json'),'/definition'),jev(cpath('primitive-accounting-proposal.json'),'/new_semantic_primitive_count'),jev(apath('reviewer-candidate008-metrics.json'),'/cumulative_from60')]+[func(rpath(x['repository_path']),x['name']) for x in primitive['new_functions']],
'HDSが実際に学習した要素':[jev(cpath('all120-teacher-preflight/native/291dc1e1/summary.json'),'/native_cycles'),jev(apath('reviewer-candidate008-teacher-evidence.json'),'/既存規則適用結果/native_HDS'),jev(apath('reviewer-candidate008-teacher-evidence.json'),'/既存規則適用結果/raw_native_exhaust'),b['候補機構を学習']],
'関連する他規則':[jev(cpath('ledger-67-contract-comparison.json'),'/component_serial'),jev(cpath('ledger-67-contract-comparison.json'),'/object_group'),jev(cpath('ledger-67-contract-comparison.json'),'/ledger'),jev(apath('reviewer-candidate008-metrics.json'),'/strict_no_new_rule_reuse_since60')]
}
natural['条件'] += [func(adapter,'validate_teachers'),func(adapter,'fit')]
natural['反証条件'] += [func(adapter,'fit')]
natural['旧資産由来'] += [func(rpath('接続/ARC2/'+x['module']+'.py'),x['function']) for x in primitive['existing_main_code_reuse']]
raw3=cpath('all120-teacher-preflight/native/291dc1e1/native-support-3.json.gz')
raw5=cpath('all120-teacher-preflight/native/291dc1e1/native-support-5.json.gz')
natural['HDSが実際に学習した要素'] += [jev(raw3,'/ledger/観測台帳'),jev(raw3,'/equality'),jev(raw5,'/equality'),jev(raw5,'/exhaust'),jev(raw5,'/native_results/3/予測群')]
natural['支持経験'] += [jev(raw3,'/learning_return')]
items={f:{'status':'出典明記','evidence':[jev('比較.json','/規則21項目/'+f)]+natural[f]} for f in fields}
omap={origins[0]:'HDSが実際に学習した要素',origins[1]:'教師fitで選択',origins[2]:'固定prior',origins[3]:'旧資産由来',origins[4]:'新規固定文法'}
origin_items={o:{'status':'出典明記','evidence':[jev('比較.json','/由来五分類/'+o)]+natural[f]} for o,f in omap.items()}
source_text_paths=sorted({ev['source_path'] for es in natural.values() for ev in es if 'line_start' in ev})
source_texts={p:{'source_path':p,'ref':None,'blob_sha':blob((S/p).read_bytes()),'content_sha256':sha((S/p).read_bytes()),'text':(S/p).read_text()} for p in source_text_paths}
cmpbytes=(S/'比較.json').read_bytes()
row={'規則ID':RULE,'規則名':'枠端積層','登録単位':template['登録単位'],'項目':items,'由来五分類':origin_items,
 '出典比較記録':'比較.json','出典commit':None,'参照commit':BASE,'blob_SHA':blob(cmpbytes),
 '原文UTF8_byte_length':len(cmpbytes),'原文':cmpbytes.decode(),'比較原文未記録項目':[],
 '関連現行code':[{'path':p,'参照commit':None,'現在blob_SHA':blob((S/p).read_bytes()),'比較時SHA256':sha((S/p).read_bytes()),'注意':'publication commit pending; content-addressed frozen source'} for p in source_text_paths if p.endswith('.py')],
 '現行コード補足':[],
 '基底runtime補足':{'境界':'ARC枠端積層','task_records':120,'採用可_true_count':1,'同値採用_true_count':1,'positive_records':[{'task_id':'291dc1e1','source':{'path':cpath('all120-teacher-preflight/native/291dc1e1/summary.json'),'sha256':sha((C/'all120-teacher-preflight/native/291dc1e1/summary.json').read_bytes()),'pointer':'/native_cycles/0/learning_return'},'record':native['native_cycles'][0]['learning_return']}]},
 '未記録項目':[], '備考':['全fieldは外部読解による出典分類でありLearning Machine出力ではない','出典commit nullは公開前未確定。blob_SHAは原文bytesから計算したGit blob内容hashでありcommitを表さない']+limits,
 '形式的規則意味論':template['形式的規則意味論'],'分類作成主体':template['分類作成主体']}
assert list(row)==list(template), (list(row),list(template))
ledger={'スキーマ版':old_ledger['スキーマ版'],'baseline':BASE,'件数':1,
 '正規化範囲':'immutable v1 67件と公開済068へのappend-only069 delta。正確package監査と親ADMIT待ち。',
 '欠損定義':old_ledger['欠損定義'],'追加出典原文':source_texts,
 '基底runtime出典':{'path':cpath('all120-teacher-preflight/native/291dc1e1/summary.json'),'sha256':sha((C/'all120-teacher-preflight/native/291dc1e1/summary.json').read_bytes())},'規則':[row]}
dump('学習台帳/ARC2規則台帳_delta_069_v1.json',ledger)

# Preserve the published experience schema and derive content only from verbatim
# natural source declarations / frozen implementations. Never inject this record.
content={x:[] for x in ['観測対象','観測された関係','成立条件','作用']}
projection=[]; metadata=[]
group_fields={'観測対象':['対象','役割'],'観測された関係':['関係'],
 '成立条件':['条件','保存条件','反証条件','競合条件','HOLD条件'],'作用':['作用']}
for group, fs in group_fields.items():
    seen=set()
    for f in fs:
        for ev in items[f]['evidence']:
            if ev['source_kind'] not in ['prepublication_frozen_code','prospective_fixed_prior_declaration']:
                metadata.append({'field':f,'pointer':ev.get('pointer'),'source_path':ev['source_path'],'理由':'出典/評価/実測/由来メタデータ。内容には投影しない'})
                continue
            q=ev['quote']
            duplicate = q in seen
            idx=content[group].index(q) if duplicate else len(content[group])
            if not duplicate: content[group].append(q);seen.add(q)
            projection.append({'内容経路':[group,idx],'元field':f,'pointer':ev.get('pointer'),'source_path':ev['source_path'],'line_start':ev.get('line_start'),'line_end':ev.get('line_end'),'原文全leaf':True,'natural_source_duplicate_of':[group,idx] if duplicate else None})
full={'規則台帳レコード':row,'内容投影対応':projection,'メタデータのみ保持':metadata,
      '注記':'由来/ID/出典/欠損ラベル/監査仮説/採点は内容に入れない。新経験のnative再観測は未実施。'}
exp={'スキーマ版':old_experience['スキーマ版'],'規則ID':RULE,
 '観測対象':{k:items[k] for k in ['対象','役割']},'観測された関係':items['関係'],
 '成立条件':{k:items[k] for k in ['条件','保存条件','反証条件','競合条件','HOLD条件']},
 '作用':items['作用'],'支持':items['支持経験'],'反例':items['反例経験'],'適用範囲':items['適用範囲'],
 '由来':origin_items,'原文・出典・完全記録':full,
 '既存interface入力':{'内容':content,'対象系境界':'既存規則経験再観測','主体':'既存比較記録',
 '対象':json.dumps(full,ensure_ascii=False,separators=(',',':')),'目的':'現行HDSの規則経験再観測','文脈':{}},
 '生成時runtime状態':'未実施。標準interfaceへの記録のみ。旧67/068経験長寿命HDSへ再投入なし。task-native4教師board同値学習は別出典。'}
assert list(exp)==list(old_experience)
(S/'学習台帳/ARC2規則経験_delta_069_v1.jsonl').write_text(json.dumps(exp,ensure_ascii=False,separators=(',',':'))+'\n')

prior_assets=[x for x in pins if x['repository_path'].startswith('学習台帳/') or '/学習台帳/' in x['repository_path']]
delta_paths=['学習台帳/ARC2規則台帳_delta_069_v1.json','学習台帳/ARC2規則経験_delta_069_v1.jsonl']
idx={'スキーマ版':'arc2-rule-composed-index-v1','baseline':BASE,'状態':'conditional; exact package audit and parent ADMIT pending',
 '登録単位':'比較系統。HDS独立原理数ではない','base_count':68,'delta_count':1,'composed_count':69,
 'base_unchanged':prior_assets,'delta':[{'path':p,'sha256':sha((S/p).read_bytes())} for p in delta_paths],
 '規則':[{'規則ID':RULE,'規則名':'枠端積層','台帳path':delta_paths[0],'台帳pointer':'/規則/0','出典比較記録':'比較.json','出典commit':None,'blob_SHA':blob(cmpbytes),'未記録項目':[]}],
 'registry_mapping':{RULE:{'family':'ARC枠端積層','module':'接続/ARC2/枠端積層教材.py','class':'枠端積層教材','accepted_family_count_on_admission':69,'new_family_count':1}},
 'new_experience_runtime':'not_run; no reinjection into existing67/068 long-lived HDS','source_content_sha256':sha(cmpbytes),
 'composition':[{'kind':'immutable_base','count':67,'repository_path':'学習台帳/ARC2規則台帳_v1.json','commit':BASE},
 {'kind':'immutable_published_delta','count':1,'repository_path':OLDROOT+'/学習台帳/ARC2規則台帳_delta_068_v1.json','commit':BASE},
 {'kind':'conditional_new_delta','count':1,'path':delta_paths[0],'publication_commit':None}],
 'source_resolution_root':ROOT}
dump('学習台帳/ARC2規則索引_composed_069_v1.json',idx)

checkpoint=deepcopy(metrics)
checkpoint['schema']='arc2-candidate008-checkpoint069-final-metrics-v1'
checkpoint['admission_status']='conditional local package; parent exact package audit and ADMIT pending'
checkpoint['primitive_counts']={'definition':primitive['definition'],'new_semantic_helpers':5,
 'names':[x['name'] for x in primitive['new_functions']],'prior_accepted002':4,'cumulative_from60_if_admitted':9,
 'existing_main_functions_directly_reused':3,'existing_main_function_names':[x['function'] for x in primitive['existing_main_code_reuse']],
 'source_dependencies':22,'source_dependencies_are_semantic_helpers':False,
 'prior_trial_AST_reuse_counts_as_existing_main_reuse':False,
 'strict_no_new_rule_reuse_since60':{'solved_tasks':0,'newly_closed_tasks':2},
 'existing_primitive_composition_in_new_families':{'solved_tasks':2,'newly_closed_tasks':2},
 'independent_HDS_learned_principle_count':'not inferred from helper/family count',
 'review':apath('reviewer-candidate008-metrics.json')}
checkpoint['original_pending_checkpoint']={'path':cpath('checkpoint-metrics.json'),'sha256':sha((C/'checkpoint-metrics.json').read_bytes()),'preserved_unchanged':True}
checkpoint['publication_commit']=None
checkpoint['source']['path']=cpath('current-official.json')
checkpoint['limitations']=limits
dump('checkpoint069.json',checkpoint)

# Complete official results and replay remain archived. The sample/event index
# gives exact pointers, never substitutes counts for full grids or raw records.
samples=[]
for ti,task in enumerate(official['execution']):
    samples.append({'task_id_audit_only':task['task_id'],'official_pointer':'/execution/'+str(ti),
     'official_source':cpath('current-official.json'),'official_sha256':sha((C/'current-official.json').read_bytes()),
     'teacher_evidence_root':cpath('all120-teacher-preflight/fit/'+task['task_id']),
     'tests':[{'query_index_audit_only':qi,'answered':result.get('answer') is not None,
               'source_pointer':f'/execution/{ti}/results/{qi}','full_result':result} for qi,result in enumerate(task['results'])]})
dump('全標本索引.json',{'schema':'arc2-complete-sample-index-v1','tasks':120,'examples':167,'records':samples,
 'current_replay':{'path':cpath('current-full-replay/raw.jsonl.gz'),'sha256':sha((C/'current-full-replay/raw.jsonl.gz').read_bytes()),'decompressed_sha256':replay_review['raw_sha256'],'calls':8751,'grid_returns':533,'None_returns':8218},
 'failure_index':{'path':cpath('current-full-replay/failure-events-v2.jsonl.gz'),'sha256':sha((C/'current-full-replay/failure-events-v2.jsonl.gz').read_bytes()),'events':8298,'candidate_generation_failure':8218,'query_HOLD':80,
 'pointer_root':cpath('current-full-replay/'),'scope':'Every event resolves to full raw returned diagnostics. No inference about unexposed internal hypotheses or original historical observation.'}})

dump('ADMISSION.json',{'schema':'arc2-candidate-admission-v1','candidate':ATTEMPT,'採否':'条件付き採用案・未ADMIT',
 '適用開始条件':'親による正確package監査と明示ADMIT、許可されたpublicationの全blob hash/size確認後に限り有効。現在はローカル案であり採用/公開済ではない。',
 'previous_main':None,'solver_baseline':BASE,'publication_commit':None,'publication_parent_commit':None,
 'purpose':'固定proper C4 cue priorを持つ全6教師適合モデルの完全合意候補を既存HDS同値gateへ接続する。',
 'previous':score_review['previous'],'current':score_review['current'],'delta':score_review['delta'],
 'precision_gate':{'all_previous86_grids_identical':True,'wrong_grids':0,'resource_failures':0,'full_regression_scripts':69,'full_regression_checks':1983,'full120_replay_exact':True,'core_unchanged':'v0.4.2'},
 'runtime_family_count_if_admitted':69,'new_family_count':1,'new_semantic_helpers':[x['name'] for x in primitive['new_functions']],
 'cumulative_new_semantic_helpers_from60_if_admitted':9,'source_resolution_root':ROOT,
 'evidence_resolution':'PUBLICATION.md describes explicit roots, complete archive, byte-identical deduplication and immutable published Git pins. publication-files.json is a LOCAL exact transport manifest, not an authorization to publish.',
 'limitations':limits})

dump('source-preservation.json',{'schema':'arc2-candidate008-complete-preservation-v1',
 'candidate_original_file_count':len(candidate_files),'candidate_original_bytes':sum(p.stat().st_size for p in candidate_files),
 'candidate_subtree_exclusion':'Only its new admission-staging subtree, including archive/build outputs, is excluded recursively.',
 'complete_candidate_artifacts_preserved':True,'frozen_file_count':len(freeze_checks),'frozen_files':freeze_checks,
 'reviewer_files':[{'path':apath(p.name),'sha256':sha(p.read_bytes())} for p in reviewers],
 'original_before_scope':read(C/'metadata-v2/preservation-scope-addendum.json'),
 'new_pending_checkpoint_original_unchanged':True,
 'other_candidate_payloads_included':False,
 'old_accepted_ledger_assets':prior_assets,
 'native_exhaust_and_negative_controls_preserved':True,
 'notes':['All candidate008 raw data, original and prospective controls, native records, journals, staging artifacts and source snapshots are exact bytes in the archive.','No candidate005 path was read or added as a dependency.','Historical path strings are provenance, not authority or an instruction to load mutable filesystem paths.']})

report={'対象':'candidate008 枠端積層の条件付き069採用package。ローカルのみ、親の正確監査/ADMIT待ち。',
 '観測':'62/120完全課題、87/167正解例、HOLD80、partial7、wrong0/resource0。旧86格子一致、69script1983check、全120replay一致。',
 '既存規則適用結果':'旧67+公開068はbytes不変。HDS v0.4.2同値を4実観測で学習。既存main3関数を再利用し、新5helper、60から累計9。',
 '不足':'正式ADMIT・publication commit未確定。未知/hidden汎化、hard-kill実証、文章経験再投入、vNextは未実施。',
 '候補':'ARC枠端積層を069としてappend-only登録する完全package。240全program→保持6、native4支持、proper C4固定priorを明記。',
 '反証':'元15360/24全履歴、negative教師、HOLD対照、全120教師86160返値、資源9scenario、support5不採用、現在失敗8298イベントを保持。',
 '適用範囲':'宣言済境界role・完全crop・cue proper C4・全保持model成功合意。公開evaluation上の前進に限定。',
 '未確認事項':limits,
 '推奨次検査':'親がpublication-files.jsonの全repository_path/bytes/hash、source引用、lossless archive、旧台帳pinsを独立監査し、別途ADMITを判断する。',
 '証拠参照':['比較.json','checkpoint069.json','ADMISSION.json','学習台帳/ARC2規則台帳_delta_069_v1.json','学習台帳/ARC2規則経験_delta_069_v1.jsonl','学習台帳/ARC2規則索引_composed_069_v1.json','全標本索引.json','source-preservation.json','lossless-manifest.json','evidencearchive.tar.gz','external-references.json','publication-files.json']}
dump('報告十項目.json',report)

publication_text='''# Candidate008 conditional admission package

This is a local conditional package, not an ADMIT or publication record. The accepted solver baseline is d2bbed2ac72d30cb7024de0f7839d656ae770689 (61 complete tasks / 86 correct examples). The candidate is 62 / 87, wrong grids 0, resource failures 0; all previous 86 correct grids are identical. HDS core v0.4.2 is unchanged.

## Explicit roots and exact bytes

The publication resolution root is 検証/後半走破/到達点62_枠端積層. Paths in the new 069 ledger, comparison, checkpoint and index resolve from that directory. Extract evidencearchive.tar.gz beneath that same directory. Its members are sources/candidate008/... (the entire original candidate subtree), sources/repository/... (every repository member of the frozen 232-file input), sources/audit/... (the eight candidate008 reviews and the specific runners/baseline evidence), and sources/accepted061/optimized-official.json (the exact accepted previous evaluation). lossless-manifest.json supplies every member's byte length and SHA256. Tar hard links deduplicate identical bytes only; the full bytes are recoverable at every logical member name. The archive never contains its own admission-staging subtree.

Original absolute paths under arc2-second-half-audit/candidate-008-border-ordered-stack map to sources/candidate008; paths under arc2-second-half map to sources/repository. Local source-path fields record historical provenance and are not a command to load a mutable absolute path. Relative paths in a captured artifact retain that artifact's original directory convention; for example current-full-replay/failure-events-v2.jsonl.gz references raw.jsonl.gz in its own current-full-replay directory. The original candidate002 score path resolves to sources/accepted061/optimized-official.json. Specific audit runner basenames resolve to sources/audit. Old source-extraction provenance naming a previous trial's bridge is retained; the actual extracted native_public.py and its AST proof are fully archived, without importing another trial's payload.

external-references.json pins the immutable published 67 ledger and complete published 068 package to exact d2bbed2 commit/path/blob/SHA256/length. Resolve the old 068 package within its own root 検証/後半走破/到達点61_距離回収 according to its original PUBLICATION.md and external-references-v2.json; never reinterpret its old relative paths beneath the new 062 root. Its stored prepublication nulls are historical metadata; this package's outer Git pins establish actual published bytes. Nothing rewrites 67 or 068.

## Admission boundary

publication-files.json is a local transport manifest listing exactly thirteen runtime/regression files and the new package files with their intended repository paths. It is not itself a publication payload, not a Git command, and not authorization to commit or publish. The future parent commit may advance through separate evidence publication; it is intentionally null, while the accepted solver baseline remains pinned. A parent must independently audit this exact package and issue ADMIT before any publication. Publication is separate from runtime quality gates.

## Interpretation and retained limitations

A: native HDS learned candidate-output/teacher-output equality from four actual supports, prior zero and quarantine zero. Supports three/four admit equality; five does not. All raw exhaust states are 出力 with empty predictions, faithfully retained, and not an independent answer claim. B: the complete 240-program fit retains all six models. C/E: the cue-to-right proper C4 applied uniformly to all payload crops is a prospective fixed prior written after the known teacher study. It is neither HDS discovery nor pruning of the original 15,360/24 study. D: three existing-main functions are directly reused. Twenty-two dependencies do not mean twenty-two semantic helpers; original trial AST reuse is distinct from accepted-main reuse.

The five new semantic helpers are component_inventory, prepare_input, all_orders, render_role and cue_rotation, using the accepted candidate002 counting definition. The cumulative count from 60 is nine (four plus five); utility, enumeration, consensus, fit, serialization and HDS adapter machinery are excluded. Family count is 67→68→69. Strict closure without a new rule is zero of two newly closed tasks; composition using existing primitives within new families is two of two. These are declared implementation counts, not independent HDS-learned semantic principles.

All original candidate artifacts, controls, negative teacher records, staging/raw/source snapshots, metadata corrections and relevant reviewer records are preserved. The before-prospective proof covers only six substantive originals; old root metadata changed. Initial 817-check regression has no individual script freeze; final 821/current 1,983 checks do. Direct observers retain complete model/teacher prefixes, not partially evaluated role/order internals. Native whole-solver runs retain final outputs, not new internal-prefix events. Nine synthetic resource scenarios do not establish real CPU/AS exhaustion or hard-kill recovery. Current replay is a later observation of returned diagnostics, not a complete trace of all hidden hypotheses or the original historical run.

The new experience file is a verbatim-source projection compatible with the existing schema; it has not been reinjected into the old long-lived HDS. No vNext implementation is included. The reported accuracy is on public evaluation, not unseen generalization. Other trials' failures remain separate history and are not erased by this accepted-candidate zero-wrong/zero-resource result.
'''
(S/'PUBLICATION.md').write_text(publication_text)
(S/'README.md').write_text('# 到達点62 枠端積層（条件付き・未採用）\n\n比較.json、checkpoint069.json、報告十項目.jsonを入口とする。解決root・lossless原証拠・不変67/068と公開条件はPUBLICATION.mdに定義した。旧pending checkpointはsources/candidate008/checkpoint-metrics.jsonとしてbyte保存する。新経験は未再投入。\n')

# A deterministic gzip/tar archive with byte-identical hardlink deduplication.
archive=S/'evidencearchive.tar.gz'
first={};members=[]
with archive.open('wb') as raw:
    with gzip.GzipFile(filename='',mode='wb',fileobj=raw,mtime=0,compresslevel=6) as gz:
        with tarfile.open(fileobj=gz,mode='w',format=tarfile.PAX_FORMAT) as tf:
            for p, spec in sorted(source_specs.items()):
                data=(S/p).read_bytes(); assert sha(data)==spec['sha256']
                ti=tarfile.TarInfo(p); ti.mode=0o644;ti.mtime=0;ti.uid=ti.gid=0;ti.uname=ti.gname=''
                dedup=first.get(spec['sha256'])
                item={**spec,'storage':'archive_hardlink' if dedup else 'archive_bytes'}
                if dedup:
                    assert (S/dedup).read_bytes()==data
                    ti.type=tarfile.LNKTYPE;ti.linkname=dedup;ti.size=0
                    item['identical_to']=dedup;tf.addfile(ti)
                else:
                    first[spec['sha256']]=p;ti.size=len(data);tf.addfile(ti,io.BytesIO(data))
                members.append(item)
manifest={'schema':'arc2-lossless-candidate008-archive-v1','archive':'evidencearchive.tar.gz',
 'archive_sha256':sha(archive.read_bytes()),'archive_bytes':archive.stat().st_size,
 'member_count':len(members),'unique_byte_payloads':len(first),'logical_bytes':sum(x['bytes'] for x in members),
 'deduplication':'Only exact-byte identical tar hard links; no content omissions or semantic compression.',
 'recursive_exclusion':str(S),'candidate_original_member_count':len(candidate_files),'members':members}
dump('lossless-manifest.json',manifest)

# Connector request-body ceiling is 16 MiB including base64. Keep any published
# binary at most 8 MiB. Preserve the exact original archive even when splitting.
transport_archives=['evidencearchive.tar.gz']
if archive.stat().st_size > 8*1024*1024:
    fullbytes=archive.read_bytes();parts=[];transport_archives=[]
    for number,offset in enumerate(range(0,len(fullbytes),8*1024*1024)):
        name=f'evidencearchive.tar.gz.part-{number:03d}'
        payload=fullbytes[offset:offset+8*1024*1024]
        (S/name).write_bytes(payload);transport_archives.append(name)
        parts.append({'path':name,'offset':offset,'bytes':len(payload),'sha256':sha(payload)})
    assert b''.join((S/x['path']).read_bytes() for x in parts)==fullbytes
    dump('archive-parts.json',{'schema':'arc2-lossless-byte-parts-v1','original_archive':'evidencearchive.tar.gz',
        'bytes':len(fullbytes),'sha256':sha(fullbytes),'parts':parts,
        'reassembly':'Concatenate parts by ascending offset without decompression or transformation, verify full SHA256, then extract the original tar.gz.'})
    transport_archives.append('archive-parts.json')
    with (S/'PUBLICATION.md').open('a') as handle:
        handle.write('\n## Transport parts\n\nThe original local archive is preserved but only its contiguous byte parts are published. Concatenate archive-parts.json parts in ascending offset order, verify the complete original length and SHA256, and then extract. This is a reversible transport split; neither the gzip stream nor its evidence content was changed.\n')

# Read back all archive members and every citation, without rerunning the solver.
archive_seen={}
with tarfile.open(archive,'r|gz') as tf:
    for member in tf:
        entry=source_specs[member.name]
        if member.islnk():
            size,digest=archive_seen[member.linkname]
        else:
            actual=tf.extractfile(member).read();size,digest=len(actual),sha(actual)
        assert size==entry['bytes'] and digest==entry['sha256'],entry['path']
        archive_seen[member.name]=(size,digest)
assert sorted(archive_seen)==sorted(source_specs)
quote_count=0
for wrapper in list(items.values())+list(origin_items.values()):
    for ev in wrapper['evidence']:
        p=S/ev['source_path'];raw=p.read_bytes();assert sha(raw)==ev['content_sha256']
        if 'pointer' in ev:
            val=getptr(json.loads(gzip.decompress(raw) if p.suffix=='.gz' else raw),ev['pointer'])
            q=val if isinstance(val,str) else json.dumps(val,ensure_ascii=False,separators=(',',':'))
        else:q='\n'.join(raw.decode().splitlines()[ev['line_start']-1:ev['line_end']])
        assert q==ev['quote'],ev
        quote_count+=1
assert exp['原文・出典・完全記録']['規則台帳レコード']==row
for mapping in projection:
    group, num=mapping['内容経路'];p=S/mapping['source_path']
    assert content[group][num]=='\n'.join(p.read_text().splitlines()[mapping['line_start']-1:mapping['line_end']])
for p in candidate_files:assert sha(p.read_bytes())==source_specs[cpath(str(p.relative_to(C)))]['sha256']
for p,h in freeze['files'].items(): assert sha(Path(p).read_bytes())==h
assert len(samples)==120 and sum(len(x['tests']) for x in samples)==167
assert sum(x['answered'] for row_ in samples for x in row_['tests'])==87
failraw=gzip.decompress((C/'current-full-replay/failure-events-v2.jsonl.gz').read_bytes())
events=[json.loads(x) for x in failraw.splitlines()]
rawreplay=gzip.decompress((C/'current-full-replay/raw.jsonl.gz').read_bytes())
rawrows=[json.loads(x) for x in rawreplay.splitlines()]
assert len(events)==8298 and len(rawrows)==120
for event in events:
    ep=event['evidence'];assert ep['decompressed_sha256']==sha(rawreplay)
    getptr(rawrows[ep['jsonl_line_zero_based']],ep['pointer'])
assert Counter(x['type'] for x in events)=={'candidate_generation_failure':8218,'query_HOLD':80}
assert json.loads((S/'sources/candidate008/checkpoint-metrics.json').read_text())['primitive_counts'].startswith('Pending')
assert checkpoint['primitive_counts']['cumulative_from60_if_admitted']==9
dump('package-validation.json',{'schema':'arc2-candidate008-local-package-validation-v1',
 'decision':'LOCAL_PACKAGE_COMPLETE_FOR_INDEPENDENT_PARENT_AUDIT_NOT_ADMIT',
 'candidate_files_preserved':len(candidate_files),'source_members_verified':len(members),
 'archive_hardlinks_resolved':sum(x['storage']=='archive_hardlink' for x in members),
 'frozen_files_unchanged':len(freeze_checks),'runtime_files':13,'reviewer_files':len(reviewers),
 'ledger_fields_exact_to_published_schema':len(fields),'origins_exact_to_published_schema':len(origins),
 'row_schema_exact_to_published068':True,'experience_schema_exact_to_published068':True,
 'verbatim_citations_hash_pointer_or_lines_verified':quote_count,'experience_projection_mappings_verified':len(projection),
 'published_pins_verified':len(pins),'old67_and068_bytes_unchanged':True,
 'new_semantic_helpers':5,'cumulative_from60_if_admitted':9,
 'official_tasks':120,'official_examples':167,'full_results_in_index':167,'failure_event_pointers_resolved':8298,
 'original_pending_checkpoint_preserved':True,'runtime_executed_in_package_build':False,
 'new_experience_reinjected':False,'git_written':False,'published':False,
 'production_freeze_sha256':sha((C/'production-freeze.json').read_bytes()),
 'archive_sha256':sha(archive.read_bytes()),'limitations':limits})

runtime=read(C/'production-source-capture/manifest.json')['files']
assert len(runtime)==13
publish=[]
for x in runtime:
    local=S/rpath(x['repository_path'])
    assert sha(local.read_bytes())==x['sha256'] and local.stat().st_size==x['bytes']
    publish.append({'kind':'runtime_or_targeted_regression','local_path':str(local),
                    'repository_path':x['repository_path'],'bytes':x['bytes'],'sha256':x['sha256']})
package_names=['比較.json','checkpoint069.json','ADMISSION.json','報告十項目.json','全標本索引.json',
 'source-preservation.json','lossless-manifest.json','external-references.json',
 'README.md','PUBLICATION.md','package-validation.json']+delta_paths+['学習台帳/ARC2規則索引_composed_069_v1.json']
package_names+=transport_archives
for p in package_names:
    b=(S/p).read_bytes()
    publish.append({'kind':'current_evidence_or_ledger','local_path':str(S/p),'repository_path':ROOT+'/'+p,
                    'bytes':len(b),'sha256':sha(b)})
assert len({x['repository_path'] for x in publish})==len(publish)
assert all(not x['repository_path'].startswith('学習台帳/') and not x['repository_path'].startswith(OLDROOT+'/') for x in publish)
dump('publication-files.json',{'schema':'arc2-exact-publication-files-v1','solver_baseline_commit':BASE,
 'base_remote_commit':None,'publication_commit':None,'state':'LOCAL_ONLY_CONDITIONAL_PARENT_EXACT_AUDIT_AND_ADMIT_PENDING',
 'resolution_root':ROOT,'files':publish,'file_count':len(publish),'runtime_file_count':13,
 'new_package_file_count':len(package_names),'new_payload_bytes':sum(x['bytes'] for x in publish),
 'manifest_usage':'Local transport manifest only; this manifest and build script are not themselves publication payloads. No publication is authorized by its existence.',
 'previous_67_and068_paths_overwritten':False,'recursive_archive_excluded':str(S)})
print(json.dumps({'state':'ready_for_parent_audit','directory':str(S),'candidate_files':len(candidate_files),
 'source_members':len(members),'archive_bytes':archive.stat().st_size,'archive_sha256':sha(archive.read_bytes()),
 'publication_files':len(publish),'publication_manifest_sha256':sha((S/'publication-files.json').read_bytes()),
 'quotes_verified':quote_count,'projection_mappings':len(projection)},ensure_ascii=False,indent=2))
