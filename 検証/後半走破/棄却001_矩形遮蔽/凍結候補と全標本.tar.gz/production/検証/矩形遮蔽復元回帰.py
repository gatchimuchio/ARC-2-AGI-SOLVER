"""矩形役割の一意性・可逆view・raw軸先決・全盤面保存の回帰。"""
from pathlib import Path
from copy import deepcopy
import random
import sys
import unittest
from unittest.mock import patch
根 = Path(__file__).resolve().parents[1]
sys.path[:0] = [str(根), str(根/'HDS/学習系統/v0.4.2')]
from 接続.ARC2 import 矩形遮蔽復元教材 as g
from 接続.ARC2.HDS接続 import HDS学習実行系, 候補機構を学習


def example(seed=1, height=12, width=14, box=(1, 1, 4, 5), mask=9):
    rng = random.Random(seed)
    palette = [x for x in range(10) if x != mask]
    output = [[None]*width for _ in range(height)]
    for r in range(height):
        for c in range(width):
            if output[r][c] is not None:
                continue
            value = rng.choice(palette)
            for a, b in {(r, c), (height-1-r, c), (r, width-1-c), (height-1-r, width-1-c)}:
                output[a][b] = value
    grid = deepcopy(output)
    r0, c0, r1, c1 = box
    for r in range(r0, r1):
        for c in range(c0, c1):
            grid[r][c] = mask
    return {'input': grid, 'output': [row[c0:c1] for row in output[r0:r1]]}


class Controls(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.train = [example(seed=s, box=box) for s, box in
                     [(1, (5, 1, 7, 5)), (2, (1, 6, 4, 8)), (3, (1, 1, 4, 5))]]
        cls.model, cls.record = g.遮蔽教師をfit(cls.train)

    def test_shared_axes_and_exhaustive_raw_counts(self):
        self.assertEqual(self.model, {'axes': [11, 13]})
        self.assertTrue(self.record['raw_selection_precedes_whole_canvas_certificate'])
        for row in self.record['raw_axis_records']:
            self.assertEqual(row['exhaustive_axis_count'], 23*27)
            self.assertEqual(len(row['all_axis_outcomes']), 23*27)
            self.assertEqual(sum(row['outcome_counts'].values()), 23*27)
            self.assertEqual(len({tuple(x[:2]) for x in row['all_axis_outcomes']}), 23*27)

    def test_exact_teachers(self):
        self.assertTrue(all(x['exact'] for x in self.record['teacher_records']))

    def test_arbitrary_colors_and_original_zero(self):
        pair=example(seed=4); view, record=g.矩形遮蔽view(pair['input'])
        self.assertIn([0, 1], record['known_color_encoding'])
        self.assertEqual(len(view['decode']), 9)
        output, proof=g.遮蔽矩形を復元(pair['input'], (11, 13))
        self.assertEqual(output, pair['output'])
        self.assertEqual(proof['proof']['filled_zero_count'], 12)

    def test_all_ten_mask_choices_color_equivariance(self):
        pair=example(seed=4)
        for offset in range(10):
            perm=lambda grid:[[(v+offset)%10 for v in row] for row in grid]
            out,_=g.遮蔽矩形を復元(perm(pair['input']), (11,13))
            self.assertEqual(out,perm(pair['output']))

    def test_input_unchanged_and_whole_canvas_observed_coverage(self):
        pair=example(seed=4);before=deepcopy(pair['input'])
        _,record=g.遮蔽矩形を復元(pair['input'],(11,13))
        self.assertEqual(pair['input'],before)
        self.assertEqual(record['proof']['observed_cells_preserved'],12*14-12)
        self.assertEqual(sum(len(o['cells']) for o in record['proof']['orbits']),12*14)

    def test_other_dimensions_positions_and_axis_parities(self):
        for h,w,box in [(11,15,(0,1,3,4)),(8,12,(1,2,3,5)),(13,10,(0,0,4,2)),(6,9,(0,1,2,3))]:
            pair=example(seed=11,height=h,width=w,box=box)
            self.assertEqual(g.遮蔽矩形を復元(pair['input'],(h-1,w-1))[0],pair['output'])

    def test_ambiguous_roles_never_target_filtered(self):
        with patch.object(g,'render_zero_mask_bidirectional_reflection_fill',side_effect=AssertionError('raw_called')):
            model,record=g.遮蔽教師をfit([{'input':[[1,1],[2,2]],'output':[[0,0]]}, {'input':[[3,3],[4,4]],'output':[[0,0]]}])
        self.assertIsNone(model);self.assertEqual(record['failure'],'teacher_mask_role_unresolved')
        self.assertEqual(len(record['teacher_view_records'][0]['raw_mask_roles']),2)

    def test_zero_roles(self):
        self.assertEqual(g.矩形遮蔽view([[1,2],[2,1]])[1]['failure'],'solid_color_rectangle_role_not_unique')

    def test_rectangle_must_own_all_cells_of_mask_color(self):
        pair=example();pair['input'][8][9]=9
        self.assertIsNone(g.矩形遮蔽view(pair['input'])[0])

    def test_no_known_cells(self):
        self.assertEqual(g.矩形遮蔽view([[3]*4 for _ in range(3)])[1]['failure'],'no_known_cells')

    def test_shape_mismatch_precedes_axis_enumeration(self):
        train=deepcopy(self.train);train[0]['output']=[[1]]
        with patch.object(g,'render_zero_mask_bidirectional_reflection_fill',side_effect=AssertionError('raw_called')):
            model,record=g.遮蔽教師をfit(train)
        self.assertIsNone(model);self.assertEqual(record['failure'],'teacher_output_not_mask_shape')

    def test_raw_ambiguity_precedes_guard(self):
        train=[]
        for r,c in [(0,0),(1,1)]:
            grid=[[1]*5 for _ in range(5)];grid[r][c]=9
            train.append({'input':grid,'output':[[1]]})
        with patch.object(g,'guarded_render',side_effect=AssertionError('guard_called')):
            model,record=g.遮蔽教師をfit(train)
        self.assertIsNone(model);self.assertEqual(record['failure'],'raw_common_axes_not_unique')
        self.assertGreater(len(record['raw_common_axes']),1)

    def test_same_mask_locations_do_not_identify_both_axes(self):
        train=[example(seed=s) for s in (1,2,3)]
        with patch.object(g,'guarded_render',side_effect=AssertionError('guard_called')):
            model,record=g.遮蔽教師をfit(train)
        self.assertIsNone(model)
        self.assertEqual(record['failure'],'raw_common_axes_not_unique')
        self.assertEqual(len(record['raw_common_axes']),20)

    def test_no_axis_rescue_after_shared_raw_selection(self):
        with patch.object(g,'guarded_render',return_value=(None,{'failure':'synthetic_certificate_failure'})):
            model,record=g.遮蔽教師をfit(self.train)
        self.assertIsNone(model);self.assertEqual(record['raw_common_axes'],[[11,13]])
        self.assertEqual(record['failure'],'selected_axis_teacher_certificate_failed')

    def test_conflict_outside_crop_still_holds(self):
        pair=example(seed=4);pair['input'][0][0]=(pair['input'][0][0]+1)%9
        view,_=g.矩形遮蔽view(pair['input'])
        raw,_=g.render_zero_mask_bidirectional_reflection_fill(view['grid'],11,13)
        self.assertEqual(g.矩形を復号抽出(raw,view),pair['output'])
        out,record=g.遮蔽矩形を復元(pair['input'],(11,13))
        self.assertIsNone(out);self.assertEqual(record['proof']['failure'],'known_orbit_conflict')

    def test_missing_entire_original_orbit(self):
        pair=example(seed=4,box=(5,6,7,8))
        out,record=g.遮蔽矩形を復元(pair['input'],(11,13))
        self.assertIsNone(out);self.assertEqual(record['proof']['failure'],'orbit_without_original_witness')

    def test_outside_axes_rejected(self):
        for axes in [(-1,13),(24,13),(11,-1),(11,28)]:
            out,record=g.遮蔽矩形を復元(example()['input'],axes)
            self.assertIsNone(out);self.assertEqual(record['proof']['failure'],'axis_centres_outside_canvas')

    def test_invalid_grids_and_teachers(self):
        for grid in [[],[[]],[[True]],[[10]],[[1],[2,3]],[[1]*31]]:
            self.assertEqual(g.矩形遮蔽view(grid)[1]['failure'],'invalid_grid')
        self.assertEqual(g.遮蔽教師をfit([example()])[1]['failure'],'too_few_teachers')
        self.assertEqual(g.遮蔽教師をfit([example(),{}])[1]['failure'],'invalid_teachers')
        self.assertEqual(g.遮蔽教師をfit([example(),example()])[1]['failure'],'duplicate_teacher_inputs')

    def test_minimum_support_counts_teacher_boards_not_axes(self):
        material=g.矩形遮蔽復元教材(self.train)
        self.assertEqual(vars(material),{'軸':(11,13)})
        for minimum,admitted in [(3,True),(4,False)]:
            machine=HDS学習実行系(最小支持数=minimum)
            record=候補機構を学習(machine,{'train':self.train,'test':[]},(), 'ARC矩形遮蔽復元',material.候補)
            self.assertEqual(record['現在観測数'],3);self.assertEqual(record['事前観測数'],0)
            self.assertEqual(record['同値採用'],admitted);self.assertEqual(record['隔離数'],0)

    def test_material_does_not_keep_teacher_outputs(self):
        train=deepcopy(self.train);material=g.矩形遮蔽復元教材(train)
        train[0]['output'][0][0]=9
        self.assertEqual(material.候補(example(seed=4)['input'],None)[0],example(seed=4)['output'])
        self.assertEqual(vars(material),{'軸':(11,13)})

    def test_unsupported_material_holds(self):
        material=g.矩形遮蔽復元教材([])
        self.assertIsNone(material.候補(example()['input'],None)[0])

if __name__=='__main__':unittest.main()
