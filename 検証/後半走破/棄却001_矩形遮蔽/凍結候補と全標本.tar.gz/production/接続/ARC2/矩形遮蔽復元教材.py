"""一意な単色矩形を欠損viewへ写し、既存二軸補完後に同じ矩形を抽出する。"""
from __future__ import annotations
from collections import Counter
from .二軸補完教材 import valid_grid, guarded_render
from .既存二軸補完 import render_zero_mask_bidirectional_reflection_fill


def 矩形遮蔽view(格子):
    if not valid_grid(格子):
        return None, {'failure': 'invalid_grid'}
    色位置 = {}
    for r, 行 in enumerate(格子):
        for c, 色 in enumerate(行):
            色位置.setdefault(色, []).append((r, c))
    役割候補 = []
    for 色, 位置 in sorted(色位置.items()):
        r0, r1 = min(r for r, c in 位置), max(r for r, c in 位置)
        c0, c1 = min(c for r, c in 位置), max(c for r, c in 位置)
        if len(位置) == (r1-r0+1)*(c1-c0+1):
            役割候補.append({'mask_color': 色, 'bbox': [r0, c0, r1+1, c1+1],
                         'cells': len(位置)})
    記録 = {'input_shape': [len(格子), len(格子[0])],
          'raw_mask_roles': 役割候補, 'role_resolved_before_output_or_completion': True}
    if len(役割候補) != 1:
        return None, {**記録, 'failure': 'solid_color_rectangle_role_not_unique'}
    役割 = 役割候補[0]
    既知色 = sorted(set(色位置)-{役割['mask_color']})
    if not 既知色:
        return None, {**記録, 'failure': 'no_known_cells'}
    # 遮蔽色以外は最大9色。元の0も欠損扱いせず、全既知色を可逆に1..9へ写す。
    符号化 = {色: index+1 for index, 色 in enumerate(既知色)}
    復号 = {番号: 色 for 色, 番号 in 符号化.items()}
    view = [[0 if 色 == 役割['mask_color'] else 符号化[色] for 色 in 行] for 行 in 格子]
    return {'grid': view, 'decode': 復号, 'bbox': 役割['bbox']}, {
        **記録, 'known_color_encoding': [[色, 符号化[色]] for 色 in 既知色]}


def 矩形を復号抽出(格子, view):
    r0, c0, r1, c1 = view['bbox']
    return [[view['decode'][格子[r][c]] for c in range(c0, c1)] for r in range(r0, r1)]


def 遮蔽矩形を復元(格子, 軸):
    view, 役割記録 = 矩形遮蔽view(格子)
    if view is None:
        return None, {'view': 役割記録, 'failure': 'mask_view_unresolved'}
    完成, 証明 = guarded_render(view['grid'], 軸)
    if 完成 is None:
        return None, {'view': 役割記録, 'proof': 証明, 'failure': 'whole_canvas_orbit_certificate_failed'}
    return 矩形を復号抽出(完成, view), {'view': 役割記録, 'proof': 証明,
                                  'crop_bbox': view['bbox'], 'axes': list(軸)}


def 遮蔽教師をfit(教師群):
    if not isinstance(教師群, list) or len(教師群) < 2:
        return None, {'failure': 'too_few_teachers'}
    if any(not isinstance(対, dict) or not valid_grid(対.get('input'))
           or not valid_grid(対.get('output')) for 対 in 教師群):
        return None, {'failure': 'invalid_teachers'}
    入力群 = [tuple(map(tuple, 対['input'])) for 対 in 教師群]
    if len(set(入力群)) != len(入力群):
        return None, {'failure': 'duplicate_teacher_inputs'}
    view群, 役割記録群 = [], []
    for index, 対 in enumerate(教師群):
        view, 記録 = 矩形遮蔽view(対['input'])
        役割記録群.append(記録)
        if view is None:
            return None, {'failure': 'teacher_mask_role_unresolved', 'teacher_index': index,
                          'teacher_view_records': 役割記録群}
        view群.append(view)
    for index, (対, view) in enumerate(zip(教師群, view群)):
        r0, c0, r1, c1 = view['bbox']
        if [len(対['output']), len(対['output'][0])] != [r1-r0, c1-c0]:
            return None, {'failure': 'teacher_output_not_mask_shape', 'teacher_index': index,
                          'teacher_view_records': 役割記録群}
    軸集合群, 全raw記録 = [], []
    for 対, view in zip(教師群, view群):
        h, w = len(view['grid']), len(view['grid'][0])
        軸集合, 検査結果, 件数 = set(), [], Counter()
        最初の失敗 = {}
        for R in range(2*h-1):
            for C in range(2*w-1):
                完成, 詳細 = render_zero_mask_bidirectional_reflection_fill(view['grid'], R, C)
                if 完成 is None:
                    状態 = 詳細.get('failure', 'raw_renderer_failed')
                    最初の失敗.setdefault(状態, {'axes': [R, C], 'detail': 詳細})
                elif 矩形を復号抽出(完成, view) != 対['output']:
                    状態 = 'raw_crop_teacher_mismatch'
                else:
                    状態 = 'raw_crop_exact'
                    軸集合.add((R, C))
                件数[状態] += 1
                検査結果.append([R, C, 状態])
        軸集合群.append(軸集合)
        全raw記録.append({'exhaustive_axis_count': (2*h-1)*(2*w-1),
                       'outcome_counts': dict(件数), 'all_axis_outcomes': 検査結果,
                       'first_raw_failure_each_type': 最初の失敗,
                       'raw_crop_exact_axes': [list(x) for x in sorted(軸集合)]})
    共通軸 = sorted(set.intersection(*軸集合群))
    基底 = {'teacher_view_records': 役割記録群, 'raw_axis_records': 全raw記録,
          'raw_common_axes': [list(x) for x in 共通軸],
          'raw_selection_precedes_whole_canvas_certificate': True}
    if len(共通軸) != 1:
        return None, {**基底, 'failure': 'raw_common_axes_not_unique'}
    軸 = 共通軸[0]
    教師記録 = []
    for index, 対 in enumerate(教師群):
        出力, 記録 = 遮蔽矩形を復元(対['input'], 軸)
        教師記録.append({'teacher_index': index, 'exact': 出力 == 対['output'], 'record': 記録})
    if not all(x['exact'] for x in 教師記録):
        return None, {**基底, 'teacher_records': 教師記録,
                      'failure': 'selected_axis_teacher_certificate_failed'}
    return {'axes': list(軸)}, {**基底, 'teacher_records': 教師記録}


class 矩形遮蔽復元教材:
    def __init__(self, 教師群):
        model, _ = 遮蔽教師をfit(教師群)
        self.軸 = tuple(model['axes']) if model is not None else None

    def 候補(self, 格子, _policy):
        if self.軸 is None:
            return None, {'failure': '全教師を再現する遮蔽矩形共有二軸なし'}
        return 遮蔽矩形を復元(格子, self.軸)

    def 記録(self):
        return {'共有反射和': list(self.軸) if self.軸 is not None else None,
                '入力view': '一意な全色支持矩形を欠損へ可逆符号化し同矩形を抽出'}
