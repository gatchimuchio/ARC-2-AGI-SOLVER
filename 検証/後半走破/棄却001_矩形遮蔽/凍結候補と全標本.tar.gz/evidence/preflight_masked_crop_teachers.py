"""All120/359 teacher-only input-view preflight; no query or solutions reads."""
import gzip
from copy import deepcopy
from dataclasses import asdict
import hashlib
import json
from pathlib import Path
import sys
import time
ROOT=Path(__file__).resolve().parents[1]/'arc2-second-half'
A=Path(__file__).resolve().parent
SOURCE=A.parent/'arc2-restored-592d2c5-audit/evaluation-teachers-only.json'
if hashlib.sha256(SOURCE.read_bytes()).hexdigest()!='012924cb967106a6d72e9323b83534539471c27dc4f5fba5d8d4a0dbe334c8aa':
    raise ValueError('teacher source changed')
tasks=json.loads(SOURCE.read_text())
if len(tasks)!=120 or any(set(x)!={'train'} for x in tasks.values()):
    raise ValueError('teacher-only120 contract')
sys.path[:0]=[str(ROOT),str(ROOT/'HDS/学習系統/v0.4.2')]
from 接続.ARC2 import 矩形遮蔽復元教材 as g
from 接続.ARC2.HDS接続 import HDS学習実行系, 候補機構を学習
started=time.monotonic();records=[];raw_calls=[];active_task=[None]
original_raw=g.render_zero_mask_bidirectional_reflection_fill
def observe_raw(grid,R,C):
    result=original_raw(grid,R,C)
    raw_calls.append({'task_id_audit_only':active_task[0], 'axes':[R,C],
                      'input_sha256':hashlib.sha256(json.dumps(grid,separators=(',',':')).encode()).hexdigest(),
                      'candidate':deepcopy(result[0]),'detail':deepcopy(result[1])})
    return result
g.render_zero_mask_bidirectional_reflection_fill=observe_raw
for task_id,task in sorted(tasks.items()):
    start=time.monotonic();active_task[0]=task_id;model,record=g.遮蔽教師をfit(task['train'])
    records.append({'task_id_audit_only':task_id,'teachers':len(task['train']),
                    'model':model,'record':record,'seconds':time.monotonic()-start})
g.render_zero_mask_bidirectional_reflection_fill=original_raw
native=[]
for item in records:
    if not item['model']:continue
    task=tasks[item['task_id_audit_only']];material=g.矩形遮蔽復元教材(task['train'])
    machine=HDS学習実行系()
    record=候補機構を学習(machine,{'train':task['train'],'test':[]},(),'ARC矩形遮蔽復元',material.候補)
    native.append({'task_id_audit_only':item['task_id_audit_only'],'record':record,
                   'active_principles':[asdict(x) for x in machine._有効原理群()],
                   'experience_count':len(machine._経験群()),'model_state':vars(material)})
raw=json.dumps({'source_sha256':hashlib.sha256(SOURCE.read_bytes()).hexdigest(),
                'code_sha256':hashlib.sha256((ROOT/'接続/ARC2/矩形遮蔽復元教材.py').read_bytes()).hexdigest(),
                'tasks':records,'native':native},ensure_ascii=False,indent=2,default=str).encode()
out=A/'masked-crop-teacher-preflight-v2.json.gz';out.write_bytes(gzip.compress(raw,mtime=0))
raw_observation=''.join(json.dumps(x,ensure_ascii=False)+'\n' for x in raw_calls).encode()
raw_out=A/'masked-crop-raw-teacher-calls.jsonl.gz';raw_out.write_bytes(gzip.compress(raw_observation,mtime=0))
summary={'tasks':len(records),'teachers':sum(x['teachers']for x in records),
         'fits':[{'task_id':x['task_id_audit_only'],'model':x['model'],'raw_axis_counts':[len(r['raw_crop_exact_axes']) for r in x['record']['raw_axis_records']]} for x in records if x['model']],
         'raw_sha256':hashlib.sha256(raw).hexdigest(),'gzip_sha256':hashlib.sha256(out.read_bytes()).hexdigest(),
         'raw_calls':len(raw_calls),'raw_calls_decompressed_sha256':hashlib.sha256(raw_observation).hexdigest(),
         'raw_calls_gzip_sha256':hashlib.sha256(raw_out.read_bytes()).hexdigest(),
         'native':[{k:v for k,v in x.items() if k!='active_principles'} for x in native],
         'seconds':time.monotonic()-started,'query_or_scorer_run':False}
(A/'masked-crop-teacher-summary-v2.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2))
print(json.dumps(summary,ensure_ascii=False))
