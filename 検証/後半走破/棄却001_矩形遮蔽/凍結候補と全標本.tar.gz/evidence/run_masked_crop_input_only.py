"""Frozen teacher-parameter query check; explicitly no evaluation targets."""
import argparse
import gzip
import hashlib
import json
import os
from pathlib import Path
import resource
import sys

p=argparse.ArgumentParser();p.add_argument('--freeze-sha',required=True);a=p.parse_args()
A=Path(__file__).resolve().parent;ROOT=A.parent/'arc2-second-half'
freeze_path=A/'masked-crop-freeze.json'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
if sha(freeze_path)!=a.freeze_sha:raise ValueError('freeze changed')
freeze=json.loads(freeze_path.read_text())
for path,expected in freeze['files'].items():
    if sha(Path(path))!=expected:raise ValueError(('frozen file changed',path))
opened=[]
def audit(event,args):
    if event!='open' or not isinstance(args[0],(str,bytes,os.PathLike)):return
    path=str(Path(os.fsdecode(args[0])).resolve())
    if '/data/evaluation/' in path or 'solutions' in Path(path).name:
        raise PermissionError('Python audited evaluation/solution reads forbidden')
    if path.endswith(('.json','.jsonl','.gz')):opened.append(path)
sys.addaudithook(audit)
resource.setrlimit(resource.RLIMIT_CPU,(10,11));resource.setrlimit(resource.RLIMIT_AS,(512*1024**2,512*1024**2))
sys.path[:0]=[str(ROOT),str(ROOT/'HDS/学習系統/v0.4.2')]
from 接続.ARC2.矩形遮蔽復元教材 import 遮蔽矩形を復元
from 接続.ARC2.HDS接続 import 課題を解く,事前教材を読む
challenge=A.parent/'arc2-restored-592d2c5-audit/data/arc-agi_evaluation_challenges.json'
if sha(challenge)!='bd9a3bdd8d176764412108eb3a1a6cb8b792a9c6fe2567532c186b2e3e4bd3bb':raise ValueError('challenge mismatch')
tasks=json.loads(challenge.read_text())
if any(set(t)!={'train','test'} or any(set(q)!={'input'} for q in t['test']) for t in tasks.values()):raise ValueError('input-only contract failed')
preflight=json.loads(gzip.decompress((A/'masked-crop-teacher-preflight-v2.json.gz').read_bytes()))
records=[]
for row in preflight['tasks']:
    if row['model'] is None:continue
    task=tasks[row['task_id_audit_only']];axes=tuple(row['model']['axes'])
    direct=[]
    for i,pair in enumerate(task['test']):
        out,detail=遮蔽矩形を復元(pair['input'],axes)
        direct.append({'query_index':i,'input':pair['input'],'frozen_axes':list(axes),'candidate':out,'detail':detail})
    result=課題を解く(task,事前教材を読む())
    records.append({'task_id_audit_only':row['task_id_audit_only'],'direct':direct,'whole_solver':result})
report={'attempt_id':'attempt-001-masked-rectangle','freeze_sha256':a.freeze_sha,
        'records':records,'python_audited_data_opens':sorted(set(opened)),
        'information_separation':'Sanitized train/test-input corpus; fitted axes frozen before query; no solution reads or query refit. Python open audit, not OS isolation.',
        'scoring_performed':False,'code_unchanged_after':all(sha(Path(p))==h for p,h in freeze['files'].items())}
out=A/'masked-crop-input-only.json';out.write_text(json.dumps(report,ensure_ascii=False,indent=2))
print(json.dumps({'tasks':len(records),'direct_answers':sum(x['candidate'] is not None for r in records for x in r['direct']),
                  'HDS_answers':sum(x['answer'] is not None for r in records for x in r['whole_solver']['results']),
                  'code_unchanged':report['code_unchanged_after'],'output_sha256':sha(out),'scored':False}))
