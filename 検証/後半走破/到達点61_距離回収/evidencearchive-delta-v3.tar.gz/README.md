# 到達点61・距離回収の採用証拠案

保存済み検証出力だけから作成した、比較・068追加台帳・経験・全標本索引です。runtime実行、再採点、test target読取、Git書込は行っていません。最終採否はintegratorと独立gate待ちです。

- 比較.json: 21項目、五由来、previous/current/delta、全回帰、4新規意味helperと制御実装の分離
- 学習台帳/: 旧67v1を再生成しないappend-only 068台帳・経験・合成索引。publication commitはnull/pending
- checkpoint61.json: 完全61/120、正解86/167、partial7、HOLD59課題/81例、wrong0、resource0
- 全標本索引.json と 全成功失敗HOLDイベント索引.jsonl.gz: 全教師候補戻値30720件、全120native family記録、全167最終例、39代替教師検査、全構造棄却を索引
- sample-event-contexts.json: イベント共通の凍結code・出典・stage・検査範囲。eventとcontextを合成して読む
- sources/: 原文の変更なし複写。旧retention FAIL、保存exit137、意味Level3未知、棄却001と開始点60全標本を保持

全path/source_path/archive_pathはこのpackage root相対です。JSON Pointerはdecoded JSON、codepoint_spanはUnicode code point、line_start/endは1-based inclusiveです。gzip原標本のbyte offsetは展開後UTF-8に対するものです。旧v1の参照は合成索引のrepository_pathとSHAで検証します。

source_distancesは新規adapterであり、旧BFS再利用やHDSによる距離学習ではありません。既存関数再利用はopen_components/clone_gridとNEIGHBORS_4/8定数。厳密な「新規規則なし」再利用閉鎖は0課題、既存helper＋新規合成は1課題です。

068文章経験の標準interfaceは記録のみでnativeへ未投入です。HDS実学習は3教師boardの候補→出力同値のみ。seed/target全域の起点2モデルを残し、どちらも成功し完全格子一致した場合だけ回答します。
