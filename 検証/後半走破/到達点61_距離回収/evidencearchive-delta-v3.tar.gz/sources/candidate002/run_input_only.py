"""Frozen optimized/unmemoized input-only replay; no test target reads."""
import argparse
import gzip
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import resource
import subprocess
import sys

HERE=Path(__file__).resolve().parent
ROOT=HERE.parents[1]/'arc2-second-half'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
p=argparse.ArgumentParser();p.add_argument('--freeze-sha',required=True);p.add_argument('--runtime',choices=('optimized','unmemoized'));args=p.parse_args()
freeze_path=HERE/'production-freeze.json'
if sha(freeze_path)!=args.freeze_sha:raise ValueError('freeze changed')
freeze=json.loads(freeze_path.read_text())
for path,expected in freeze['files'].items():
    if sha(Path(path))!=expected:raise ValueError(('frozen file changed',path))

if args.runtime:
    resource.setrlimit(resource.RLIMIT_CPU,(10,11));resource.setrlimit(resource.RLIMIT_AS,(512*1024**2,512*1024**2))
    payload=json.load(sys.stdin);task=payload['task'];models=payload['frozen_models']
    if set(payload)!={'task','frozen_models'} or set(task)!={'train','test'} or any(set(x)!={'input'} for x in task['test']):raise ValueError('invalid input-only contract')
    opens=[]
    def audit(event,arguments):
        if event!='open' or not isinstance(arguments[0],(str,bytes,os.PathLike)):return
        path=str(Path(os.fsdecode(arguments[0])).resolve())
        if '/data/evaluation/' in path or 'solutions' in Path(path).name:raise PermissionError('Python audited original evaluation/solution reads forbidden')
        if path.endswith(('.json','.jsonl','.gz')):opens.append(path)
    sys.addaudithook(audit)
    sys.path[:0]=[str(ROOT),str(ROOT/'HDS/学習系統/v0.4.2')]
    from 接続.ARC2 import 距離回収候補 as core,距離回収教材 as wrapper
    if args.runtime=='unmemoized':
        spec=importlib.util.spec_from_file_location('frozen_unmemoized',HERE/'prototype_unmemoized.py')
        old=importlib.util.module_from_spec(spec);spec.loader.exec_module(old)
        for name in ('fit','render','consensus'):setattr(core,name,getattr(old,name))
    from 接続.ARC2.HDS接続 import 課題を解く,事前教材を読む
    direct=[]
    for pair in task['test']:
        grid,record=wrapper.全距離モデルを照会(pair['input'],models)
        direct.append({'input':pair['input'],'candidate':grid,'record':record})
    result=課題を解く(task,事前教材を読む())
    print(json.dumps({'direct':direct,'whole_solver':result,'audited_data_opens':sorted(set(opens)),
                      'contract':{'task_id_received':False,'test_fields':[sorted(x) for x in task['test']],
                                  'frozen_models':models,'python_open_audit_not_os_isolation':True}},ensure_ascii=False))
    raise SystemExit(0)

challenge=ROOT.parent/'arc2-restored-592d2c5-audit/data/arc-agi_evaluation_challenges.json'
if sha(challenge)!='bd9a3bdd8d176764412108eb3a1a6cb8b792a9c6fe2567532c186b2e3e4bd3bb':raise ValueError('challenge changed')
tasks=json.loads(challenge.read_text())
if any(set(t)!={'train','test'} or any(set(q)!={'input'} for q in t['test']) for t in tasks.values()):raise ValueError('challenge fields invalid')
teachers=json.loads(gzip.decompress((HERE/'production-preflight/full-preflight.json.gz').read_bytes()))
records=[]
for fitted in teachers['records']:
    if not fitted['models']:continue
    task=tasks[fitted['task_id_audit_only']];variant_results={}
    for variant in ('optimized','unmemoized'):
        try:
            result=subprocess.run([sys.executable,__file__,'--freeze-sha',args.freeze_sha,'--runtime',variant],input=json.dumps({'task':task,'frozen_models':fitted['models']}),text=True,capture_output=True,timeout=60,env={**os.environ,'PYTHONDONTWRITEBYTECODE':'1'})
            if result.returncode:
                variant_results[variant]={'error':'runtime_exit','returncode':result.returncode,'stdout':result.stdout,'stderr':result.stderr}
            else:variant_results[variant]=json.loads(result.stdout)
        except subprocess.TimeoutExpired as exc:
            variant_results[variant]={'error':'wall_limit','stdout':str(exc.stdout),'stderr':str(exc.stderr)}
    records.append({'task_id_audit_only':fitted['task_id_audit_only'],'variants':variant_results,
                    'exact_optimized_unmemoized':variant_results['optimized']==variant_results['unmemoized']})
report={'attempt_id':'attempt-002-distance-collection','freeze_sha256':args.freeze_sha,
        'records':records,'scoring_performed':False,
        'code_unchanged_after':all(sha(Path(p))==h for p,h in freeze['files'].items()),
        'scope':'Teacher-frozen models and sanitized test inputs only; optimized/unmemoized independent fresh HDS processes, same10CPU/512MiB/60wall limits'}
out=HERE/'input-only.json';out.write_text(json.dumps(report,ensure_ascii=False,indent=2))
print(json.dumps({'tasks':len(records),'all_variant_results_exact':all(x['exact_optimized_unmemoized'] for x in records),
                  'optimized_direct_answers':sum(x['candidate'] is not None for r in records for x in r['variants']['optimized'].get('direct',[])),
                  'optimized_HDS_answers':sum(x['answer'] is not None for r in records for x in r['variants']['optimized'].get('whole_solver',{}).get('results',[])),
                  'errors':[{'task':r['task_id_audit_only'],'variant':v,'error':d['error']} for r in records for v,d in r['variants'].items() if 'error' in d],
                  'code_unchanged':report['code_unchanged_after'],'output_sha256':sha(out),'scored':False}))
