"""許可済み当taskのteacher-only input/outputだけを読み、audit結果を作る。"""
import hashlib, json, sys
from pathlib import Path
HERE = Path(__file__).resolve().parent
ROOT = HERE.parent.parent / 'arc2-second-half'
sys.dont_write_bytecode = True
sys.path.insert(0, str(ROOT))
from prototype import fit, render, consensus


def load_teachers():
    all_tasks = json.loads((HERE.parent/'observation-shard-1/teacher-only-tasks.json').read_text())
    teachers = all_tasks['dd6b8c4b']['train']
    del all_tasks
    return teachers


def save(name, obj):
    (HERE/name).write_text(json.dumps(obj,ensure_ascii=False,indent=2)+'\n')


def main():
    contract_hash = hashlib.sha256((HERE/'00-contract-before-fit.json').read_bytes()).hexdigest()
    teachers = load_teachers()
    models, diagnostics = fit(teachers)
    save('fit-exhaustive-evidence.json', {'contract_sha256':contract_hash, 'diagnostics':diagnostics, 'models':models})
    per_example = []
    for i,pair in enumerate(teachers):
        out,record = consensus(pair['input'],models)
        per_example.append({'teacher_index':i,'exact':out==pair['output'],'record':record})
    save('teacher-exact-evidence.json',per_example)
    print(json.dumps({'contract_sha256':contract_hash, 'survivors':len(models),
                      'full_candidates':diagnostics['conceptual_candidates'],
                      'fully_evaluated':diagnostics['fully_evaluated_candidates'],
                      'teacher_exact':[e['exact'] for e in per_example],
                      'models':models}, ensure_ascii=False,indent=2))

if __name__ == '__main__': main()
