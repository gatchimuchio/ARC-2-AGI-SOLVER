"""67登録の契約比較と近傍familyの当task教師fit再観測。"""
import hashlib, importlib, json
from verify import HERE, ROOT, load_teachers, save
fields=['対象','役割','関係','作用','保存条件','HOLD条件','教師fitで選択','入力から毎回導出','固定prior']
ledger=json.loads((ROOT/'学習台帳/ARC2規則台帳_v1.json').read_text())
# 差分は既存familyの名前を言い換えて同じfamilyと呼ばないための比較軸。
differences={
 1:'piece全体を穴へ詰める対応。source各画素の距離prefix回収ではない',
 2:'sectorの色多数決と中心面積票。sourceを消去せずtargetへ票を転写する',
 3:'二値原型への対応と再構成。障害物つき距離順位で物量を運ぶ契約なし',
 4:'二軸の補完。source全距離と容量prefix消費の組合せなし',
 5:'倍率に従う置換。単一画素を消費して固定slot数へ収めるものではない',
 6:'側の周期関係。source到達距離順位を扱わない',
 7:'入れ子の合成。seedから到達sourceを個数保存して回収する契約なし',
 8:'凡例の展開対応。距離の順位でsourceを選ばない',
 9:'凡例の旋回対応。距離の順位でsourceを選ばない',
 10:'凡例と矩形の対応。距離prefix消費を決めない',
 11:'穴数と凡例の対応。source各画素の物量回収ではない',
 12:'凡例と経路の色対応。容量cutoffによる画素消費なし',
 13:'凡例の集合対応。source距離順位とtargetslotの連結契約なし',
 14:'制御による複写。今回のsource消去/物量保存とは異なる',
 15:'包含による正規化。距離回収ではない',
 16:'区切りと投射。sourceを近い順に容量まで移す契約なし',
 17:'十字/曲線の対応。seed-到達距離prefixと異なる',
 18:'十字着色。seed-到達距離prefixと異なる',
 19:'行の反復。到達sourceを物量保存して移すものではない',
 20:'帯の周期。到達sourceを物量保存して移すものではない',
 21:'周期の組修復。元sourceの距離順位消費なし',
 22:'四欄の反復。元sourceの距離順位消費なし',
 23:'基点に基づく複製。容量までsource原位置を消費しない',
 24:'対称の剪定。seedから障害物越しの距離による選択ではない',
 25:'対角線の橋。C4 source距離回収ではない',
 26:'対角領域の選択/着色。C4 source距離回収ではない',
 27:'帯と図形の関係。C4距離・容量prefix・消費の組合せなし',
 28:'帯輪郭の関係。C4距離・容量prefix・消費の組合せなし',
 29:'形状と色の転写。近いsource画素の回収なし',
 30:'同色C4成分をnode、8近接をedgeとする最短component path。今回のgrid C4距離とはmetricも作用も異なる',
 31:'成分の直列化。個別source画素の到達距離順位とは異なる',
 32:'接触配置。source距離prefix容量制限とは異なる',
 33:'支持構造。source距離prefix容量制限とは異なる',
 34:'放射組立。source距離prefix容量制限とは異なる',
 35:'枠列を整列する対象/保存量。source個数をtargetへrow-major充填しない',
 36:'frame色ごとの物理component数を既定slotへ符号化。今回の画素数保存・距離選択・容量で余剰保持とは異なる',
 37:'格子の自己マスク。距離回収ではない',
 38:'標点に基づく組立。source距離容量prefixではない',
 39:'標識移動。移動先関係はC4距離順位の容量prefixではない',
 40:'標識組立。source距離容量prefixではない',
 41:'標識の計数。障害物つきsource距離で消費集合を選択しない',
 42:'櫛配置。source距離容量prefixではない',
 43:'正方形格子。source距離容量prefixではない',
 44:'方向つき流路の到達/塗り。距離順位source選択と物量保存のtarget充填ではない',
 45:'object/marker/空slotの対応とcorridor投射。今回のsingle-pixel距離順位回収ではない',
 46:'物体端の投射。source全距離と容量消費なし',
 47:'物体群の整列。個別source pixelの到達距離選択なし',
 48:'疎点転写。今回のsource消去とC4順位容量制限は別の複合契約',
 49:'単色背景のC4floodはclosureのみ。barrier保存/除去・境界塗りであり、今回の距離ラベルと回収作用は提供しない',
 50:'穴形の拡大。source距離prefix回収なし',
 51:'穴輪郭。source距離prefix回収なし',
 52:'空白への移動。source距離と容量の画素単位回収とは異なる',
 53:'色群の充填。seedからの距離cutoffに基づく元source消費なし',
 54:'行周期。source距離prefix回収なし',
 55:'記号命令。今回のrole・C4距離・容量prefixは別契約',
 56:'象限配色。距離順位回収とは対象/作用が違う',
 57:'separator除外C4領域は再利用可。boundary_layers_8は境界seed/C8距離であり、単一seedのC4距離には流用不可',
 58:'軸反射。source距離容量prefixではない',
 59:'軸投射。source距離容量prefixではない',
 60:'辺対応抽出。source距離容量prefixではない',
 61:'遮蔽区画の対応。source距離容量prefixではない',
 62:'部分見本の対応。source距離容量prefixではない',
 63:'配置展開。source距離容量prefixではない',
 64:'重畳組立。source距離容量prefixではない',
 65:'開口壁とrail/plateau等の関係。source距離順位でtargetへ物量移送しない',
 66:'header高さでverticalrun ordinalを指定。BFS距離順のpixel容量prefixではない',
 67:'領域転写。source距離選択/元位置消費/slot容量の組合せなし'
}
rows=[]
for i,rule in enumerate(ledger['規則'],1):
 row={'規則ID':rule['規則ID'],'規則名':rule['規則名'],'今回との差分':differences[i], '既存契約':{}}
 for field in fields:
  item=rule['項目'].get(field,{})
  claims=[];refs=[]
  for ev in item.get('evidence',[]):
   if 'claim_ja' in ev and ev['claim_ja'] not in claims:claims.append(ev['claim_ja'])
   if 'source_path' in ev:
    ref={'path':ev['source_path'],'line_start':ev.get('line_start'),'line_end':ev.get('line_end')}
    if ref not in refs:refs.append(ref)
  row['既存契約'][field]={'status':item.get('status','missing'),'claims':claims,'source_references':refs,
                        'missing_claim_note':None if claims else '台帳の当欄にclaim_jaなし。未記録を推測で補完しない'}
 rows.append(row)
save('ledger-67-contract-comparison.json',{'registered_count':len(rows),'candidate_contract':'00-contract-before-fit.json','comparisons':rows,'boundary':'ledger/source契約比較。全67runtime再採点ではない'})
train=load_teachers();near=[]
for module_name, cls in [('中心配色教材','中心配色教材'),('枠計数教材','枠計数教材'),('種境界教材','種境界教材'),('距離層教材','距離層教材'),('順位着色教材','順位着色教材'),('物体slot教材','物体slot教材'),('流路教材','流路教材'),('開口壁教材','開口壁教材')]:
 module=importlib.import_module('接続.ARC2.'+module_name); obj=getattr(module,cls)(train)
 r={'module':module_name,'fit_record':obj.記録(),'teacher_predictions':[]}
 for i,pair in enumerate(train):
  out,rec=obj.候補(pair['input'],{})
  r['teacher_predictions'].append({'teacher_index':i,'exact':out==pair['output'],'record':rec})
 if hasattr(module,'guarded_render') and module_name in ('中心配色教材','枠計数教材','距離層教材','順位着色教材'):
  r['raw_guard_records']=[{'teacher_index':i,'exact':(v:=module.guarded_render(pair['input']))[0]==pair['output'],'record':v[1]} for i,pair in enumerate(train)]
 near.append(r)
mod=importlib.import_module('接続.ARC2.既存成分最短経路')
near.append({'module':'既存成分最短経路','teacher_input_roles':[{'teacher_index':i,'policy':(v:=mod.terminal_square_path_policy(pair['input']))[0],'record':v[1]} for i,pair in enumerate(train)]})
save('existing-neighbor-teacher-fit.json',near)
reuse=[
 {'path':'接続/ARC2/既存種境界.py','symbol':'NEIGHBORS_4 / NEIGHBORS_8','lines':[16,23],'use':'実import。C4/C8比較候補に使用'},
 {'path':'接続/ARC2/既存距離層.py','symbol':'open_components','lines':[70,96],'use':'実import。C4かつsource_transit=true時の全到達領域coverageを独立検証'},
 {'path':'接続/ARC2/既存凡例穴対応.py','symbol':'clone_grid','lines':[21,22],'use':'実import。同時proposal前の入力複写'},
 {'path':'接続/ARC2/既存距離層.py','symbol':'boundary_layers_8','lines':[98,132],'use':'非再利用。境界seed/C8距離で本候補と異なる'},
 {'path':'接続/ARC2/既存種境界.py','symbol':'flood_same_color','lines':[91,111],'use':'非再利用。単色closureで距離ラベルを返さない'},
 {'path':'接続/ARC2/既存成分最短経路.py','symbol':'unique_shortest_component_path','lines':[66,116],'use':'非再利用。component graphのedge数と唯一pathの契約はgrid距離と異なる'},
 {'path':'接続/ARC2/枠計数教材.py','symbol':'guarded_render','lines':[64,82],'use':'設計参照のみ。source component countと右側slotで本候補とは異なる'},
 {'path':'接続/ARC2/順位着色教材.py','symbol':'guarded_render','lines':[40,66],'use':'設計参照のみ。ordinal選択と同時proposalを参考。関数流用なし'},
 {'path':'prototype.py','symbol':'source_distances / render_prepared / fit / consensus','use':'新規距離adapter/複合candidate契約。HDS学習primitive追加や既存family採用とは主張しない'}
]
for x in reuse:
 p=ROOT/x['path'] if x['path'].startswith('接続/') else HERE/x['path']
 x['sha256']=hashlib.sha256(p.read_bytes()).hexdigest()
save('primitive-reuse-and-distinction.json',reuse)
print(json.dumps({'ledger_contracts':len(rows),'nearby_families_checked':len(near),'all_nearby_nonmatching':all(not x['exact'] for r in near for x in r.get('teacher_predictions',[]))},ensure_ascii=False))
