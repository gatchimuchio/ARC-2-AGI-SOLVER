import json, resource, sys, time
from verify import load_teachers, save
from prototype import fit
train=load_teachers()
w=time.monotonic();cpu=time.process_time()
models,diagnostics=fit(train)
out={'wall_seconds':time.monotonic()-w,'cpu_seconds':time.process_time()-cpu,'max_rss_kib':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,'conceptual_candidates':diagnostics['conceptual_candidates'],'full_axis_evaluations':diagnostics['fully_evaluated_candidates'],'survivor_count':len(models),'scope':'candidate fit only; all-family task budget not measured here'}
save(sys.argv[1] if len(sys.argv)>1 else 'fit-resources.json',out)
print(json.dumps(out,ensure_ascii=False))
