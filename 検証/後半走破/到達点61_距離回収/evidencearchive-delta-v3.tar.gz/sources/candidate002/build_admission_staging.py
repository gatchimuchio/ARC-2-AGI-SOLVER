"""Saved-artifact-only append ledger package. No solver imports, queries, scoring or repository writes."""
from pathlib import Path
import json, hashlib, gzip, ast, shutil, collections
R=Path('/workspace/scratch/7408259c1ab2/arc2-second-half')
C=R.parent/'arc2-second-half-audit/candidate-002-distance-collection'
A=C.parent
S=C/'admission-staging'
S.mkdir(exist_ok=True)
BASE='cc668e34d7ca014daf9f8944767476d56c56fafc'
ATT='attempt-002-distance-collection'
RID='arc2-comparison-068'
PUB='検証/後半走破/到達点61_距離回収'
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def blob(p):
 b=Path(p).read_bytes();return hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()
def read(p):
 return json.loads(gzip.decompress(Path(p).read_bytes())) if str(p).endswith('.gz') else json.loads(Path(p).read_text())
def write(name,d):
 p=S/name;p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(d,ensure_ascii=False,indent=2)+'\n');return p
def sp(p):
 p=Path(p)
 if p.is_relative_to(S):return p.relative_to(S).as_posix()
 if p.is_relative_to(C):return 'sources/candidate002/'+p.relative_to(C).as_posix()
 if p.is_relative_to(R):return 'sources/repository/'+p.relative_to(R).as_posix()
 return 'sources/audit/'+p.relative_to(A).as_posix()
def preserve(p):
 q=S/sp(p);q.parent.mkdir(parents=True,exist_ok=True)
 if q.resolve()!=Path(p).resolve():shutil.copyfile(p,q)
 return q
cache={}
def value(p,ptr):
 p=Path(p);d=cache.setdefault(str(p),read(p))
 for k in ptr.split('/')[1:]:
  k=k.replace('~1','/').replace('~0','~');d=d[int(k)] if isinstance(d,list) else d[k]
 return d
def qjson(p,ptr):
 p=Path(p);v=value(p,ptr);q=v if isinstance(v,str) else json.dumps(v,ensure_ascii=False,separators=(',',':'))
 d={'source_path':sp(p),'content_sha256':sha(p),'pointer':ptr,'quote':q,'codepoint_span':[0,len(q)],'source_value_type':type(v).__name__,'quote_mode':'leaf' if isinstance(v,str) else 'typed_value','ref':None,'source_kind':'prepublication_saved_artifact'}
 if str(p).endswith('.gz'):d['decoded_content_sha256']=hashlib.sha256(gzip.decompress(p.read_bytes())).hexdigest()
 return d
def qcode(p,lo,hi):
 p=Path(p);q='\n'.join(p.read_text().splitlines()[lo-1:hi]);return {'source_path':sp(p),'content_sha256':sha(p),'blob_sha':blob(p),'ref':None,'source_kind':'prepublication_frozen_code','line_start':lo,'line_end':hi,'quote':q,'evidence_kind':'凍結コード契約。native学習との同一視なし'}
def ref(p,ptr=None):
 d={'path':sp(p),'sha256':sha(p)}
 if ptr is not None:d['pointer']=ptr
 return d
freeze=read(C/'production-freeze.json')
assert sha(C/'production-freeze.json')=='bd0924ffc0398022fa5e4eab00e34d906c3133d7dafb6f2c5d8a40884903897d'
assert sha(C/'input-only.json')=='708ca1b4548f49c8130ede7177b655b93ad03467bb9d8add2cebe10c590c9933'
oldfiles=list((R/'学習台帳').glob('*_v1.*')); oldhash={str(p.relative_to(R)):sha(p) for p in oldfiles}
ledger=read(R/'学習台帳/ARC2規則台帳_v1.json'); template=ledger['規則'][-1]
oldexp=json.loads((R/'学習台帳/ARC2規則経験_v1.jsonl').read_text().splitlines()[0])
contract=read(C/'00-contract-before-fit.json'); fit=read(C/'fit-exhaustive-evidence.json')
prepath=C/'production-preflight/full-preflight.json.gz';pre=read(prepath)
score=read(C/'score-comparison.json');cur=read(C/'optimized-official.json');prev=read(A/'baseline-fresh.json')
reg=read(C/'production-regressions.json');parity=read(A/'reviewer-candidate002-full120-parity.json')
code=C/'production/接続/ARC2/距離回収候補.py'; wrapper=C/'production/接続/ARC2/距離回収教材.py';bridge=R/'接続/ARC2/HDS接続.py'
assert sha(bridge)==freeze['files'][str(bridge)]
# Preserve cited immutable source bytes before another candidate may modify the main checkout.
required=[C/'00-contract-before-fit.json',C/'fit-exhaustive-evidence.json',C/'teacher-exact-evidence.json',C/'negative-alternative-evidence.json',C/'existing-neighbor-teacher-fit.json',C/'primitive-reuse-and-distinction.json',C/'ledger-67-contract-comparison.json',prepath,C/'production-preflight/summary.json',C/'input-only.json',C/'production-freeze.json',C/'score-comparison.json',C/'optimized-official.json',C/'unmemoized-official.json',C/'production-regressions.json',C/'unmemoized-production-regressions.json',C/'memoization-equivalence.json',code,wrapper,bridge,R/'接続/ARC2/既存種境界.py',R/'接続/ARC2/既存距離層.py',R/'接続/ARC2/既存凡例穴対応.py',R/'検証/学習規則再観測比較.json',R/'検証/同一学習機械保持/summary.json',R/'検証/後半走破/開始点60/独立監査/reviewer-gate-contract-v1.json',A/'baseline-fresh.json',*oldfiles,*A.glob('reviewer-candidate002*.json')]
for p in required:preserve(p)
fields={
'対象':'5色roleで所有される背景・単一中心seed・奇数正方形target・target外source全画素・wall。盤面全画素を役割で覆う。',
'役割':'background/seed/target/source/wallは相異なる5役割。教師fitは7/2/3/9/6を保持した。wallのみ各盤面で欠落を許す。色番号は固定priorではない。',
'観測事実':'保存済み全120課題/167例の同条件評価は60完全課題/84正解例から61/86へ。dd6b8c4bの2例だけ新回答、既存84正解格子一致、wrong grid 0、resource failure 0。',
'関係':'C4到達距離によるsource順位とtarget容量prefixを対応づける。seed起点とtarget全域起点は教師上未識別で両方保持する。',
'条件':'全教師の完全格子一致で残った全モデルを保存。照会で全モデルが成功し完全格子一致すること、既存HDS候補→出力同値採用と排気gateを全て要する。',
'作用':'到達sourceを距離の近い順に容量まで選び、元位置を背景化しtargetのrow-major prefixをsource色に同時更新する。容量prefixは課題作用であり仮説探索のtop-k削減ではない。',
'保存条件':'wall、非選択source、proposal外の全画素を保存し、source色総画素数を保存する。中心seedはprefixに含まれる場合のみ上書きし、それ以外は保存する。',
'反証条件':'教師完全格子不一致、構造条件違反、容量超過禁止、容量cutoff距離同率、全モデル不一致又はいずれかのモデル失敗を反証/HOLDとして残す。',
'競合条件':'全教師適合モデル間の完全格子不一致でHOLD。成功モデルだけ選ばない。共有gateで採用済み他familyとの完全格子予測が競合する場合もHOLD。',
'HOLD条件':'不正格子、5役割不成立、未知色、必須role欠落、seed非singleton、奇数正方形/中心/所有条件違反、教師target寸法外、source-target重なり、容量cutoff同率、モデルなし・失敗・不一致、共有HDS排気保留を保持する。',
'支持経験':'dd6b8c4bの全3教師が両モデルで完全再現。回収数2/9/4、source総数12/15/4を保存。task-native HDSは3教師観測、同値採用true、隔離数0。',
'反例経験':'13代替仮説×3教師の全差分/HOLD、全30720仮説教師戻値格子・詳細、全120課題教師fit拒否を保存する。C8、直接距離、壁通過、source通過不可、遠い順、seed永久保存、全到達必須、複写、別slot順を区別する。',
'適用範囲':'今回残ったモデルは教師と同じ3×3target、中央singleton seed、教師fitした5色role、ARC1〜30盤面。3×3外・複数target・偏心seed等はHOLD。公開評価上の開発結果でhidden一般化は未確認。',
'教師fitで選択':'5役割色、target寸法、全9axisを全教師一致で選択。残存2モデルはoriginのみseed/target_all_cellsが異なる。fit後boolだけではなく具体parameter集合を保持する。',
'入力から毎回導出':'seed位置、target全域、source/wall全画素、全source距離と到達不能、容量cutoff、選択source・充填slot・proposal外保存集合を現在入力から導出する。',
'固定prior':'相異なる5role、中心singletonを含む奇数正方形target、画素単位回収、有限axis集合。5!×5120=614400概念仮説。構造不可能604160を論理否定、残る10240を全3教師で評価し、近似枝刈りなし。',
'旧資産由来':'実関数再利用はopen_componentsとclone_grid、定数はNEIGHBORS_4/NEIGHBORS_8。source_distancesは新規距離adapterであり、旧BFS関数再利用又はHDSによるBFS学習と呼ばない。',
'新規固定文法':'parse/source_distances/ordered_slots/render_preparedの4意味helperで、役割形態view→距離→容量順序→同時消去/充填を新規に合成した1family。baseline全体のprimitive総数は未調査で捏造しない。',
'新規実装':'fit列挙、consensus、pure中間値cache、render/wrapper、格子/所有/保存/全モデル合意guard、HDS接続登録は制御・補助実装として別記する。4意味helperやHDS学習要素に水増ししない。',
'HDSが実際に学習した要素':'task-native HDSの3教師board候補→出力の同値関係のみ。role/BFS/容量合成の発見ではない。068文章経験は標準interfaceへ記録しただけで、旧67経験の長寿命HDSへ再投入していない。',
'関連する他規則':'旧67比較の対象/役割/関係/作用/保存/HOLD/fit/priorを確認し、近傍9familyは当課題全3教師で成立しなかった。距離層の境界seed/C8、種境界の単色closure、成分最短経路のcomponent graphとは契約が異なる。'}
assert list(fields)==list(template['項目'])
f=C/'00-contract-before-fit.json';fitp=C/'fit-exhaustive-evidence.json'
E={
'対象':[qjson(f,'/固定prior/対象所有'),qcode(code,24,57)],
'役割':[qjson(f,'/固定prior/role'),qjson(fitp,'/models/0/roles')],
'観測事実':[qjson(C/'score-comparison.json','/delta'),qjson(A/'reviewer-candidate002-optimized-score.json','/counts')],
'関係':[qcode(code,60,99),qjson(fitp,'/models')],
'条件':[qcode(wrapper,22,37),qjson(C/'production-preflight/summary.json','/native/0/record')],
'作用':[qcode(code,110,132)],'保存条件':[qcode(code,133,148)],
'反証条件':[qcode(code,118,129),qjson(C/'negative-alternative-evidence.json','/0')],
'競合条件':[qcode(wrapper,22,37)],
'HOLD条件':[qcode(code,24,56),qcode(code,118,129),qcode(wrapper,22,35)],
'支持経験':[qjson(C/'teacher-exact-evidence.json','/0/exact'),qjson(C/'teacher-exact-evidence.json','/1/exact'),qjson(C/'teacher-exact-evidence.json','/2/exact'),qjson(C/'production-preflight/summary.json','/native/0/record')],
'反例経験':[qjson(C/'negative-alternative-evidence.json','/5'),qjson(C/'negative-alternative-evidence.json','/6'),qjson(C/'production-preflight/summary.json','/fully_evaluated_hypothesis_teacher_pairs')],
'適用範囲':[qcode(code,24,57),qjson(fitp,'/models/0/shape')],
'教師fitで選択':[qjson(fitp,'/models'),qcode(wrapper,40,57)],
'入力から毎回導出':[qjson(f,'/入力から導出'),qcode(code,110,148)],
'固定prior':[qjson(f,'/全axis'),qjson(f,'/固定prior'),qjson(fitp,'/diagnostics/conceptual_candidates'),qjson(fitp,'/diagnostics/logically_rejected_candidates'),qjson(fitp,'/diagnostics/fully_evaluated_candidates')],
'旧資産由来':[qcode(code,4,6),qcode(R/'接続/ARC2/既存距離層.py',70,96),qcode(R/'接続/ARC2/既存凡例穴対応.py',21,22),qcode(R/'接続/ARC2/既存種境界.py',16,23)],
'新規固定文法':[qcode(code,24,57),qcode(code,60,99),qcode(code,110,148)],
'新規実装':[qcode(code,151,214),qcode(wrapper,7,57)],
'HDSが実際に学習した要素':[qjson(prepath,'/native/0/native_ledgers/原理台帳/0/関係型'),qjson(prepath,'/native/0/native_ledgers/原理台帳/0/条件経路群'),qjson(prepath,'/native/0/native_ledgers/原理台帳/0/結果経路'),qjson(prepath,'/native/0/native_ledgers/原理台帳/0/根拠参照群'),qjson(prepath,'/native/0/native_ledgers/原理台帳/0/採用状態')],
'関連する他規則':[qjson(C/'ledger-67-contract-comparison.json','/registered_count'),qjson(C/'ledger-67-contract-comparison.json','/boundary'),qjson(C/'primitive-reuse-and-distinction.json','/3/use'),qjson(C/'primitive-reuse-and-distinction.json','/4/use'),qjson(C/'primitive-reuse-and-distinction.json','/5/use')]}
# Shared existing gate code line citations are selected by AST block, not guessed line numbers.
bridge_tree=ast.parse(bridge.read_text())
for node in bridge_tree.body:
 if isinstance(node,ast.FunctionDef) and node.name in ['出力格子','候補機構を学習']:
  E['条件'].append(qcode(bridge,node.lineno,node.end_lineno))
 if isinstance(node,ast.FunctionDef) and node.name=='課題を解く':
  for key in ['条件','競合条件','HOLD条件']:
   E[key].append(qcode(bridge,327,357))
  E['新規実装'].append(qcode(bridge,325,328))
primitives=[]
for node in ast.parse(code.read_text()).body:
 if isinstance(node,ast.FunctionDef) and node.name in ['parse','source_distances','ordered_slots','render_prepared']:
  primitives.append({'name':node.name,'classification':'new_semantic_view_distance_order_action_helper','source':qcode(code,node.lineno,node.end_lineno)})
comparison={'スキーマ版':'arc2-candidate002-admission-comparison-v1','attempt_id':ATT,'規則ID':RID,'状態':'staged_evidence_complete_final_admission_pending','publication_commit':None,'publication_commit_status':'pending; no fabricated Git identity','previous_commit':BASE,'目的':'全120課題の閉鎖を進め、成功・失敗・HOLDの全標本を残す。HDS固定。','原因':fields['関連する他規則'],'変更':fields['新規固定文法'],'previous':score['previous'],'current':score['current'],'delta':score['delta'],'回帰':{'prior_correct_grids':84,'all_identical':all(x['exact_equal'] for x in score['old_correct_grid_checks']),'wrong_grids':0,'resource_failures':0,'optimized':{'scripts':reg['files'],'tests':reg['tests'],'success':reg['success']},'unmemoized':{'scripts':68,'tests':1162,'success':read(C/'unmemoized-production-regressions.json')['success']},'full120_execution_and_scorer_parity':parity,'sources':[ref(C/'production-regressions.json'),ref(C/'unmemoized-production-regressions.json'),ref(C/'score-comparison.json')]},'規則21項目':fields,'項目別出典':E,'新規primitive台帳':{'count':4,'definition':'Named semantic view/distance/order/action helpers in this candidate only','items':primitives,'excluded_control':['fit','consensus','render','pure distance/slot caches','距離回収をfit','全距離モデルを照会','距離回収教材','guards and HDS registration'],'baseline_global_primitive_count':None,'baseline_global_primitive_census':'not performed'},'再利用計数':{'denominator':'今回増分で完全解決した1課題。全120課題を副分母として併記','no_new_rule_solved_tasks':0,'no_new_rule_solved_task_ids':[],'strict_reuse_rate_of_newly_closed':0.0,'strict_reuse_rate_of_all120':0.0,'existing_helpers_plus_new_composition_solved_tasks':1,'existing_helpers_plus_new_composition_solved_task_ids':['dd6b8c4b'],'comparison_families_after_admission':68,'new_family_count':1,'independent_HDS_learned_principle_count':'not inferred from family count'},'全有限仮説':{'axes':contract['全axis'],'conceptual_per_eligible_five_color_task':614400,'dd6_fully_evaluated':10240,'dd6_logically_rejected':604160,'hypothesis_teacher_results':30720,'survivors':fit['models'],'all_models_required':True,'top_k_or_heuristic_pruning':False,'capacity_prefix_is_task_action':True,'memoization':'同一pure中間結果のみ。全model/格子/診断/理由を保持','source':ref(C/'production-preflight/summary.json')},'HDSと再観測境界':{'native_task_learning':'3 teacher boards; candidate→output equality','new_ledger_experience_reobserved':False,'long_lived_67_HDS_reinjected':False,'retention_FAIL_unchanged':True,'native_save_exit137_trials_unchanged':2,'semantic_Level3':'unknown','sources':[ref(R/'検証/同一学習機械保持/summary.json'),ref(R/'検証/学習規則再観測比較.json','/結果分類')]},'制限':['未完了59課題/81未回答例が残る。120閉鎖とは主張しない','公開評価の開発結果でhidden/generalization未測定','既存runnerの入力/採点分離はdata-flow契約。OS filesystem sandboxの証明ではない','旧資産露出の留保、同一学習機械retention FAIL、2回exit137、Level3未知は不変','memo版19.365秒と非memo版21.211秒の1回ずつの同条件実測。統計的高速化保証ではない','067までの文章経験payloadを変更/再生成せず、068の標準interface記録もnativeへ再投入していない','採否と公開はintegratorおよび独立gateの最終判断待ち'],'凍結と境界証拠':[ref(C/'production-freeze.json'),ref(C/'input-only.json'),ref(A/'reviewer-candidate002-query-release.json'),ref(A/'reviewer-candidate002-score-release.json')]}
comp=write('比較.json',comparison)
items={k:{'status':'出典明記','evidence':[qjson(comp,'/規則21項目/'+k),*E[k]]} for k in fields}
origmap={'A_HDS実学習':'HDSが実際に学習した要素','B_教師fit選択':'教師fitで選択','C_固定prior':'固定prior','D_旧資産継承':'旧資産由来','E_新規固定文法':'新規固定文法'}
origins={k:items[v] for k,v in origmap.items()}
row={'規則ID':RID,'規則名':'距離回収','登録単位':'追加比較記録の一系統。学習済み独立原理数を表さない','項目':items,'由来五分類':origins,'出典比較記録':sp(comp),'出典commit':None,'参照commit':BASE,'blob_SHA':blob(comp),'原文UTF8_byte_length':comp.stat().st_size,'原文':comp.read_text(),'比較原文未記録項目':[],'関連現行code':[{'path':sp(p),'参照commit':None,'現在blob_SHA':blob(p),'比較時SHA256':sha(p),'注意':'publication commit pending; content-addressed frozen source'} for p in [code,wrapper,bridge]],'現行コード補足':[],'基底runtime補足':{'境界':'ARC距離順位回収','task_records':120,'採用可_true_count':1,'同値採用_true_count':1,'positive_records':[{'task_id':'dd6b8c4b','source':ref(prepath,'/native/0'),'record':pre['native'][0]['record']}]},'未記録項目':[],'備考':['全fieldは外部読解による出典分類でありLearning Machine出力ではない','出典commit nullは公開前未確定。blob_SHAは原文bytesから計算したGit blob内容hashでありcommitを表さない','旧v1全67件はbyte不変。新規実装guard/wrapperはE/Aと別分類','外部標準interfaceを記録しただけで、文章規則経験再観測は未実施'],'形式的規則意味論':'未記録。引用された叙述を新たな実行可能predicateへ変換したとは主張しない','分類作成主体':'外部監査（人間/LLM）。Learning Machine自身の出力ではない'}
assert set(row)==set(template)
ledgerp=write('学習台帳/ARC2規則台帳_delta_068_v1.json',{'スキーマ版':'arc2-rule-ledger-v1','baseline':BASE,'件数':1,'正規化範囲':'immutable v1 67件へのappend-only delta。最終採用待ち','欠損定義':ledger['欠損定義'],'追加出典原文':{sp(p):{'source_path':sp(p),'ref':None,'blob_sha':blob(p),'content_sha256':sha(p),'text':p.read_text()} for p in [code,wrapper,bridge]},'基底runtime出典':ref(prepath),'規則':[row]})
# Exact source text projection, excluding LLM claim text/evaluation/IDs/metadata; deduplicate source span once.
content={};mapping=[];excluded=[];seen=set()
groups={'観測対象':['対象','役割'],'観測された関係':['関係'],'成立条件':['条件','保存条件','反証条件','競合条件','HOLD条件'],'作用':['作用'],'支持':['支持経験'],'反例':['反例経験'],'適用範囲':['適用範囲']}
for group,keys in groups.items():
 for key in keys:
  for e in E[key]:
   ident=(e['source_path'],e.get('pointer'),e.get('line_start'),e.get('line_end'))
   # Only exact frozen rule/guard contract or code text, never outcome/score prose.
   if e['source_kind']!='prepublication_frozen_code' and e['source_path']!=sp(f):
    excluded.append({'field':key,'pointer':e.get('pointer'),'source_path':e['source_path'],'理由':'出典/評価/実測/由来メタデータ。内容には投影しない'});continue
   if ident in seen:continue
   seen.add(ident);a=content.setdefault(group,[]);a.append(e['quote']);mapping.append({'内容経路':[group,len(a)-1],'元field':key,'pointer':e.get('pointer'),'source_path':e['source_path'],'line_start':e.get('line_start'),'line_end':e.get('line_end'),'原文全leaf':True,'natural_source_duplicate_of':None})
archive={'規則台帳レコード':row,'内容投影対応':mapping,'メタデータのみ保持':excluded,'注記':'由来/ID/出典/欠損ラベル/監査仮説/採点は内容に入れない。新経験のnative再観測は未実施。'}
exp={'スキーマ版':'arc2-rule-experience-v1','規則ID':RID,'観測対象':{k:items[k] for k in ['対象','役割']},'観測された関係':items['関係'],'成立条件':{k:items[k] for k in ['条件','保存条件','反証条件','競合条件','HOLD条件']},'作用':items['作用'],'支持':items['支持経験'],'反例':items['反例経験'],'適用範囲':items['適用範囲'],'由来':origins,'原文・出典・完全記録':archive,'既存interface入力':{'内容':content,'対象系境界':'既存規則経験再観測','主体':'既存比較記録','対象':json.dumps(archive,ensure_ascii=False,separators=(',',':')),'目的':'現行HDSの規則経験再観測','文脈':{}},'生成時runtime状態':'未実施。標準interfaceへの記録のみ。旧67経験長寿命HDSへ再投入なし。task-native3教師board同値学習は別出典。'}
assert set(exp)==set(oldexp)
expp=S/'学習台帳/ARC2規則経験_delta_068_v1.jsonl';expp.write_text(json.dumps(exp,ensure_ascii=False,separators=(',',':'))+'\n')
index=write('学習台帳/ARC2規則索引_composed_068_v1.json',{'スキーマ版':'arc2-rule-composed-index-v1','baseline':BASE,'状態':'staged; admission pending','登録単位':'比較系統。HDS独立原理数ではない','base_count':67,'delta_count':1,'composed_count':68,'base_unchanged':[{'repository_path':k,'sha256':v,'archive_path':'sources/repository/'+k} for k,v in oldhash.items()],'delta':[ref(ledgerp),ref(expp)],'規則':[{'規則ID':RID,'規則名':'距離回収','台帳path':sp(ledgerp),'台帳pointer':'/規則/0','出典比較記録':sp(comp),'出典commit':None,'blob_SHA':blob(comp),'未記録項目':[]}],'registry_mapping':{'arc2-comparison-068':{'family':'ARC距離順位回収','module':'接続/ARC2/距離回収教材.py','class':'距離回収教材','accepted_family_count_on_admission':68,'new_family_count':1}},'new_experience_runtime':'not_run; no reinjection into existing67 long-lived HDS','source_content_sha256':sha(comp)})
answered=[];holds=[];taskrows=[];reasoncounts=collections.Counter()
for ti,x in enumerate(cur['execution']):
 tid=x['task_id']; ans=sum(r.get('answer') is not None for r in x['results']);assert ans==x['correct_examples']
 taskrows.append({'task_id_audit_only':tid,'test_count':x['test_count'],'correct_examples':x['correct_examples'],'answered_examples':ans,'complete':x['correct_examples']==x['test_count'],'partial':0<x['correct_examples']<x['test_count'],'hold_examples':x['test_count']-ans,'source_pointer':f'/execution/{ti}'})
 for j,r in enumerate(x['results']):
  ent={'task_id_audit_only':tid,'test_index':j,'status':r.get('status'),'reasons':r.get('reasons',[]),'source_pointer':f'/execution/{ti}/results/{j}'}
  if r.get('answer') is not None:answered.append(ent)
  else:holds.append(ent);reasoncounts.update(r.get('reasons',[]))
metrics=write('checkpoint61.json',{'schema':'arc2-checkpoint61-saved-artifact-index-v1','attempt_id':ATT,'publication_status':'pending_final_admission','previous_checkpoint':{'complete_tasks':60,'correct_examples':84},'current':{'complete_tasks':61,'total_tasks':120,'correct_examples':86,'total_examples':167,'answered_examples':len(answered),'unanswered_examples':len(holds),'partial_tasks':sum(x['partial'] for x in taskrows),'HOLD_tasks':sum(x['hold_examples']>0 for x in taskrows),'all_HOLD_tasks':sum(x['answered_examples']==0 for x in taskrows),'wrong_grids':0,'resource_failures_by_type':cur['summary']['resource_failures'],'accepted_family_count_on_admission':68,'new_family_count':1,'new_semantic_primitive_count':4},'delta_from_last_accepted_and_frozen60':{'complete_tasks':1,'correct_examples':2,'unanswered_examples':-2,'wrong_grids':0,'resource_failures':0},'solved_task_ids':cur['original_audit']['solved_task_ids'],'correct_examples':answered,'HOLD_examples':holds,'HOLD_reason_counts':dict(reasoncounts),'tasks':taskrows,'reuse':comparison['再利用計数'],'regression':comparison['回帰'],'evidence':{'current':ref(C/'optimized-official.json'),'previous':ref(A/'baseline-fresh.json'),'independent_comparison_to_previous_and_frozen60':ref(A/'reviewer-candidate002-optimized-score.json'),'all120_teacher_preflight':ref(prepath),'full_hypothesis_teacher_raw':ref(C/'production-preflight/all-hypothesis-teacher-results.jsonl.gz')},'counting':'wrong_attempted_tasksはlegacy scorerのpartial7件を含む。wrong gridsへ読み替えない。正解例識別は保存済みwrong0と各task answered==correct_examplesから索引化し、testtargetを再読しない。','inherited_negatives':comparison['HDSと再観測境界'],'supplemental_full120_v3_return_replay':'pending integrator artifact; existing raw returned hypothesis grids already preserved'})
assert oldhash=={str(p.relative_to(R)):sha(p) for p in oldfiles}
write('stage1-validation.json',{'same_ledger_row_keys':set(row)==set(template),'same_experience_keys':set(exp)==set(oldexp),'fields21':len(items),'origins5':len(origins),'old_v1_hashes_unchanged':True,'source_quote_count':sum(len(x['evidence']) for x in items.values()),'no_solver_query_or_evaluation_run':True,'no_official_target_files_read':True,'publication_commit':None,'artifacts':[ref(x) for x in [comp,ledgerp,expp,index,metrics]]})
print(json.dumps({'stage':'stage1_ready','path':str(S),'artifacts':[{**ref(x),'bytes':x.stat().st_size} for x in [comp,ledgerp,expp,index,metrics]]},ensure_ascii=False))
