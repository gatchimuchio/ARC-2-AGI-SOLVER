"""全実描画候補でmemo前後の出力・完全診断recordを照合。"""
import hashlib, itertools, json
from verify import HERE, load_teachers, save
import prototype as new
import prototype_unmemoized as old
train=load_teachers()
colors=sorted({v for p in train for row in p['input'] for v in row})
checked=0;roles_checked=0;h=hashlib.sha256()
for vals in itertools.permutations(colors):
 roles=dict(zip(new.ROLE_NAMES,vals))
 parsed=[new.parse(p['input'],roles) for p in train]
 oldparsed=[old.parse(p['input'],roles) for p in train]
 assert parsed==oldparsed
 roles_checked+=1
 shapes={x['shape'] for x,e in parsed if x is not None}
 if any(e for x,e in parsed) or len(shapes)!=1:continue
 dc=[{} for _ in train];sc=[{} for _ in train]
 for params in (dict(zip(new.AXES,x)) for x in itertools.product(*new.AXES.values())):
  for i,p in enumerate(train):
   dk=tuple(params[k] for k in ('metric','origin','wall_passable','source_transit'))
   sk=tuple(params[k] for k in ('capacity','slot_order'))
   if dk not in dc[i]:dc[i][dk]=new.source_distances(p['input'],parsed[i][0],params)
   if sk not in sc[i]:sc[i][sk]=new.ordered_slots(parsed[i][0],params)
   a=old.render(p['input'],roles,params,next(iter(shapes)))
   b=new.render_prepared(p['input'],roles,params,parsed[i][0],dc[i][dk],sc[i][sk])
   assert a==b,(roles,params,i)
   h.update(json.dumps({'roles':roles,'parameters':params,'teacher':i,'output_and_full_record':a},sort_keys=True,separators=(',',':')).encode())
   checked+=1
result={'all_equal':True,'role_parse_comparisons':roles_checked,'full_output_and_record_comparisons':checked,'transcript_sha256':h.hexdigest(),'no_models_removed':True,'cached_keys':['input+roles+metric+origin+wall_passable+source_transit','input+roles+capacity+slot_order'],'fit_files_identical':{n:hashlib.sha256((HERE/n).read_bytes()).hexdigest()==(HERE/(n+'.unmemoized.sha256')).read_text().strip() for n in ('fit-exhaustive-evidence.json','teacher-exact-evidence.json')}}
save('memoization-equivalence.json',result);print(json.dumps(result,ensure_ascii=False))
