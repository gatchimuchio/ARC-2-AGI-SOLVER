"""Whole120 teacher-only fit with lossless per-hypothesis returned grids/diagnostics."""
from pathlib import Path
import gzip
import hashlib
import json
import resource
import sys
import time
ROOT=Path(__file__).resolve().parents[2]/'arc2-second-half'
HERE=Path(__file__).resolve().parent
SOURCE=ROOT.parent/'arc2-restored-592d2c5-audit/evaluation-teachers-only.json'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
if sha(SOURCE)!='012924cb967106a6d72e9323b83534539471c27dc4f5fba5d8d4a0dbe334c8aa':raise ValueError('source changed')
tasks=json.loads(SOURCE.read_text())
if len(tasks)!=120 or any(set(x)!={'train'} for x in tasks.values()):raise ValueError('teacher-only scope')
sys.path[:0]=[str(ROOT),str(ROOT/'HDS/学習系統/v0.4.2')]
from 接続.ARC2 import 距離回収候補 as core,距離回収教材 as material
from 接続.ARC2.HDS接続 import HDS学習実行系,候補機構を学習
out=HERE/'production-preflight';out.mkdir(exist_ok=False)
active={'task':None,'inputs':{}};sequence=[0];raw_hash=hashlib.sha256();raw_bytes=[0]
original=core.render_prepared
stream=gzip.GzipFile(filename=str(out/'all-hypothesis-teacher-results.jsonl.gz'),mode='wb',mtime=0)
def observe(grid,roles,parameters,parsed,distances,slots):
    result=original(grid,roles,parameters,parsed,distances,slots)
    event={'sequence':sequence[0],'task_id_audit_only':active['task'],
           'teacher_index':active['inputs'][id(grid)],'roles':roles,'parameters':parameters,
           'candidate':result[0],'detail':result[1]}
    raw=(json.dumps(event,ensure_ascii=False,separators=(',',':'))+'\n').encode()
    stream.write(raw);raw_hash.update(raw);raw_bytes[0]+=len(raw);sequence[0]+=1
    return result
records=[];start=time.monotonic();cpu=time.process_time()
core.render_prepared=observe
try:
    for task_id,task in sorted(tasks.items()):
        active.update(task=task_id,inputs={id(p['input']):i for i,p in enumerate(task['train'])})
        count_before=sequence[0];models,record=material.距離回収をfit(task['train'])
        records.append({'task_id_audit_only':task_id,'teachers':len(task['train']),'models':models,
                        'fit':record,'raw_event_span':[count_before,sequence[0]]})
finally:
    core.render_prepared=original;stream.close()
native=[]
for r in records:
    if not r['models']:continue
    task=tasks[r['task_id_audit_only']];obj=material.距離回収教材(task['train'])
    machine=HDS学習実行系(最小支持数=2 if len(task['train'])==2 else 3)
    record=候補機構を学習(machine,{'train':task['train'],'test':[]},(),'ARC距離順位回収',obj.候補)
    native.append({'task_id_audit_only':r['task_id_audit_only'],'record':record,
                   'state':obj.モデル群,'native_ledgers':machine.台帳.JSON相当()})
raw=json.dumps({'source_sha256':sha(SOURCE),'records':records,'native':native},ensure_ascii=False,indent=2).encode()
(out/'full-preflight.json.gz').write_bytes(gzip.compress(raw,mtime=0))
summary={'tasks':len(records),'teachers':sum(x['teachers'] for x in records),
         'fits':[{'task_id':x['task_id_audit_only'],'models':len(x['models']),'raw_events':x['raw_event_span'][1]-x['raw_event_span'][0]} for x in records if x['models']],
         'fully_evaluated_hypothesis_teacher_pairs':sequence[0],
         'raw_events_sha256':raw_hash.hexdigest(),'raw_events_bytes':raw_bytes[0],
         'gzip_events_sha256':sha(out/'all-hypothesis-teacher-results.jsonl.gz'),
         'full_preflight_raw_sha256':hashlib.sha256(raw).hexdigest(),
         'seconds':time.monotonic()-start,'cpu_seconds':time.process_time()-cpu,
         'max_rss_kib':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,
         'query_or_scorer_run':False,'native':[{k:v for k,v in x.items() if k not in ('native_ledgers','state')} for x in native]}
(out/'summary.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2));print(json.dumps(summary,ensure_ascii=False))
