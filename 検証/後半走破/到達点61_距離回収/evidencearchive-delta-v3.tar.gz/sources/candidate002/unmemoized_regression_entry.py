"""Read-only process-local substitution of the preserved unoptimized pure candidate."""
from pathlib import Path
import importlib.util
import runpy
import sys
HERE=Path(__file__).resolve().parent
ROOT=HERE.parents[1]/'arc2-second-half'
target=Path(sys.argv[1]).resolve()
if target.parent!=ROOT/'検証' or not target.name.endswith('回帰.py'):
    raise ValueError('Expected a current top-level regression script')
sys.path[:0]=[str(ROOT),str(ROOT/'HDS/学習系統/v0.4.2')]
from 接続.ARC2 import 距離回収候補 as production
spec=importlib.util.spec_from_file_location('preserved_unmemoized_candidate',HERE/'prototype_unmemoized.py')
unmemoized=importlib.util.module_from_spec(spec);spec.loader.exec_module(unmemoized)
# No inference grammar/parameters/HDS/file changes; replace only preserved pure functions.
for name in ('fit','render','consensus'):
    setattr(production,name,getattr(unmemoized,name))
sys.argv=[str(target)]
runpy.run_path(str(target),run_name='__main__')
