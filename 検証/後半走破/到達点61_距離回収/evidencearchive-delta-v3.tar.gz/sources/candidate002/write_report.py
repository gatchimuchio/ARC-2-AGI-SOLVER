import hashlib,json
from pathlib import Path
HERE=Path(__file__).resolve().parent
report={
'対象':'dd6b8c4b。固定HDS/currentrouteの教師専用候補検証。production/core/bridge未変更、採用・query・評価・git操作なし。',
'観測':[
'全3教師を閉じた。元source数12/15/4、到達数2/15/4、回収数2/9/4、回収後もsource色総画素数12/15/4。消去位置とtarget充填は各教師完全一致。seedは5番目slotであり、回収2/4では保存、回収9では上書き。wall/未選択source/操作外を保存。',
'教師前固定契約は全120色role割当×5120有限axis=614400仮説。118role×5120=604160は全教師入力の構造不可能証明で否定。残る2roleの全10240axis組を全3教師で比較。成功優先・firstmatch・数上限・候補近似削減なし。',
'残存は2モデル。roleはbackground7/seed2/target3/source9/wall6、target3×3。C4 BFS、wall通過不可、source通過可、近い順、中心含む容量9、row-major、元位置をbackground化が共通。距離起点だけseed単独/target全域が教師上未識別。数値色は教師fit値であり固定palette priorではない。'],
'既存規則適用結果':'67登録を対象・role・関係・作用・保存・HOLD・教師fit/入力導出/固定priorの各欄で比較。近傍9familyも当task教師で再確認し成立なし。C4/C8近傍定数・open_components・clone_gridのみ実import再利用。boundary_layers_8は境界seed/C8、flood_same_colorは距離なしclosureのため代用していない。',
'不足':'既存familyにはsource画素の全距離→容量prefix選択→消去/充填→物量保存を連結する契約がない。起点は2仮説を残す必要があり、teacherのみでは唯一原理を主張できない。',
'候補':'分類は既存純粋helperを使用した新規距離adapterと複合candidate。有限priorは相異なる5role・中心singletonを含む奇数正方形target・画素単位回収・全axis集合。teacher fitはrole色/target寸法/axis全一致集合。入力から全距離・到達不能・選択/保存集合を導出。全残存modelの成功と完全格子一致だけ候補を返し、いずれか失敗/相違は全体HOLD。',
'反証':[
'代替仮説13種を全3教師で照合し、全差分座標/HOLD理由を保存。source通過不可は教師0で2cell相違、遠い順は教師1で12cell相違、seed永久保存は教師1で2cell相違、全到達回収は教師1の15>9でHOLD。C8は教師1のcutoff tie、Manhattanは教師0/1のcutoff tie。source複写は2/9/4cell相違。',
'通常/-Oとも55検査を通過。130palette再符号化×3教師=390比較、wall padding平行移動9件、回収容量1〜9、到達不能、C4角接点、壁の開閉、厳密cutoff余剰保存、距離同率HOLD、複数/欠落seed、未知色、target欠損/余分/偏心、5×5逸脱、role alias、不正格子、反実teacher不採用を検査。',
'起点曖昧性を区別する合成入力でseed起点のみ成功・target全域起点はcutoff tieとなり、候補全体がHOLDすることを確認。両仮説の保持が必要。'],
'適用範囲':'3×3中心seedの単一target、教師で確定した5色role（wallのみ欠落可）、ARC1〜30の入力。全sourceを列挙し容量を跨がない同率は全採用、跨ぐ同率はHOLD。sourceの容量prefixは課題作用であり探索候補数削減ではない。prototypeは教師だけに適合した候補であり本番性能を示さない。',
'未確認事項':'全family合算のCPU10秒/512MiB制約、HDS接続時の排気/反例隔離/合意gate、独立レビュー、凍結後query有効支持、全120回帰と性能差は未検査。3×3以外・偏心seed・複数target・役割aliasは未学習としてHOLD。',
'推奨次検査':'独立レビューで先行契約、全120roleと10240axis評価、2残存モデル、保存則、negativeとmemo同値を確認。その後だけintegratorが現行gateへ接続可否を判断し全family予算を測定。単体fitはCPU4.338秒/RSS14684KiB→純粋中間計算memoでCPU0.903秒/RSS14848KiB。全30720描画の格子/HOLD/完全diagnostic一致、120role構造一致、fit証拠SHA一致を実証。query成功や採用は未主張。',
'証拠参照':[
'00-contract-before-fit.json（SHA256 e7420794c26579521bd2136b87292b499d7b687bf15879129152165116deb712）',
'prototype_unmemoized.py / prototype.py / verify.py / test_candidate.py / verify_memoization.py / benchmark_fit.py / compare_existing.py',
'fit-exhaustive-evidence.json / teacher-exact-evidence.json / negative-alternative-evidence.json',
'ledger-67-contract-comparison.json / existing-neighbor-teacher-fit.json / primitive-reuse-and-distinction.json',
'test-results.json / test-results-optimized.json / tests.stdout / tests-optimized.stdout',
'memoization-equivalence.json / unmemoized-fit-resources.json / memoized-fit-resources.json',
'各pathのroot: /workspace/scratch/7408259c1ab2/arc2-second-half-audit/candidate-002-distance-collection/',
'許可教師出典: ../observation-shard-1/teacher-only-tasks.json#/dd6b8c4b/train と ../observation-shard-1/observations.json 当taskのみ'
]}
(HERE/'report-ten-fields.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
files={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(HERE.iterdir()) if p.is_file() and p.name!='artifact-manifest.json'}
(HERE/'artifact-manifest.json').write_text(json.dumps({'artifact_files':files,'production_write':False,'query_read':False,'teacher_only':True},ensure_ascii=False,indent=2)+'\n')
print('wrote report-ten-fields.json, artifact-manifest.json; fields=',list(report))
