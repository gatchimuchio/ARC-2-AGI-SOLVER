"""Index and losslessly package saved observations, without runtime/query/evaluation execution."""
from pathlib import Path
import json,gzip,hashlib,collections,shutil,tarfile,io
R=Path('/workspace/scratch/7408259c1ab2/arc2-second-half');A=R.parent/'arc2-second-half-audit';C=A/'candidate-002-distance-collection';S=C/'admission-staging'
ATT='attempt-002-distance-collection';BASE='cc668e34d7ca014daf9f8944767476d56c56fafc';PUB='検証/後半走破/到達点61_距離回収'
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def read(p):return json.loads(gzip.decompress(Path(p).read_bytes())) if str(p).endswith('.gz') else json.loads(Path(p).read_text())
def write(n,d):
 p=S/n;p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(d,ensure_ascii=False,indent=2)+'\n');return p
def sp(p):
 p=Path(p)
 if p.is_relative_to(S):return p.relative_to(S).as_posix()
 if p.is_relative_to(C):return 'sources/candidate002/'+p.relative_to(C).as_posix()
 if p.is_relative_to(R):return 'sources/repository/'+p.relative_to(R).as_posix()
 return 'sources/audit/'+p.relative_to(A).as_posix()
def ref(p,ptr=None):
 d={'path':sp(p),'sha256':sha(p)}
 if ptr is not None:d['pointer']=ptr
 return d
originals={}
def preserve(p):
 p=Path(p);q=S/sp(p);q.parent.mkdir(parents=True,exist_ok=True)
 if q.exists() and sha(q)!=sha(p):
  if p.name in ['build_admission_staging.py','finish_admission_staging.py']:shutil.copyfile(p,q)
  else:raise AssertionError(('preexisting source changed',str(p)))
 if not q.exists():shutil.copyfile(p,q)
 originals[sp(p)]=str(p);return q
freeze=read(C/'production-freeze.json');freezehash=sha(C/'production-freeze.json')
# Preserve entire frozen executable source set and saved evidence. No official target/source dataset is opened.
for name,h in freeze['files'].items():
 p=Path(name);assert not p.is_relative_to(R/'入力');assert sha(p)==h,(name,'frozen source changed');preserve(p)
for p in sorted(C.rglob('*')):
 if not p.is_file() or p.is_relative_to(S) or '__pycache__' in p.parts or 'unmemoized-shadow' in p.parts:continue
 preserve(p)
for p in sorted(A.glob('reviewer-candidate002*.json')):preserve(p)
for p in sorted((R/'学習台帳').glob('*_v1.*')):preserve(p)
for dirname in ['検証/同一学習機械保持','検証/後半走破/開始点60','検証/後半走破/棄却001_矩形遮蔽']:
 for p in sorted((R/dirname).rglob('*')):
  if p.is_file():preserve(p)
for p in [R/'検証/学習規則再観測比較.json',R/'検証/学習規則再観測監査.md',A/'baseline-fresh.json',A/'baseline-fresh-regressions.json',A/'checkpoint60-original-public.json',A/'reviewer-attempt001-rollback.json']:
 preserve(p)
cur=read(C/'optimized-official.json');prepath=C/'production-preflight/full-preflight.json.gz';pre=read(prepath)
rawp=C/'production-preflight/all-hypothesis-teacher-results.jsonl.gz';train=read(C/'production/検証/fixtures/距離回収教師.json')['train']
contexts={
 'hypothesis_teacher':{'attempt_id':ATT,'stage':'teacher_only_frozen_finite_hypothesis','family':'ARC距離順位回収','frozen_code_sha256':freeze['files'][str(R/'接続/ARC2/距離回収候補.py')],'input_provenance':ref(C/'production/検証/fixtures/距離回収教師.json','/train'),'allowed_exposure_stage':'train inputs and train outputs only; pre-query','candidate_counts_exhaustiveness':'5! roles ×5120 axes; per structurally valid role evaluate every axis on every teacher. Structural rejection kept separately. No first-match/top-k.','raw_source':ref(rawp),'raw_offsets':'uncompressed UTF-8 JSONL byte offsets; sequence zero-based, line sequence+1','observed_vs_inferred_cause':'classification derived only from saved candidate/detail and saved permitted teacher grid exact equality. No solver rerun.','retained_diagnostic_data':'Full candidate grids, distances, choices, conservation and failures in raw_source','follow_up':'final independent admission gate; any later candidate has a new attempt ID'},
 'teacher_fit':{'attempt_id':ATT,'stage':'all120_teacher_preflight','family':'ARC距離順位回収','frozen_code_sha256':freeze['files'][str(R/'接続/ARC2/距離回収候補.py')],'input_provenance':{'sha256':pre['source_sha256'],'saved_source_description':'evaluation-teachers-only.json; train only, no targets'},'allowed_exposure_stage':'pre-query teacher-only','raw_source':ref(prepath),'candidate_counts_exhaustiveness':'Entire 120 task/359 teacher preflight preserved. Scope failures remain failures; not counted as exhausted axis evaluations.','observed_vs_inferred_cause':'Exact saved fit reason and logical structural rejection; no inferred mechanism absence','retained_diagnostic_data':'Full fit models, role assignments and negative signatures at raw pointer','follow_up':'remaining59 closure under separately frozen candidates'},
 'family_fit':{'attempt_id':ATT,'stage':'saved_full120_native_family_admission','family':'per record','frozen_code_sha256':freeze['files'][str(R/'接続/ARC2/HDS接続.py')],'all_family_code_manifest':ref(C/'production-freeze.json','/files'),'input_provenance':'Saved full120 evaluation execution/families; runtime data-flow train and test-input only','allowed_exposure_stage':'post-freeze full120 execution','raw_source':ref(C/'optimized-official.json'),'candidate_counts_exhaustiveness':'All recorded family admissions preserved. A native early failure may not evaluate later teachers; raw record is authoritative; no all-teacher-return completeness inferred.','observed_vs_inferred_cause':'Raw native status, counts, failure details only; not a capability-impossibility claim','retained_diagnostic_data':'Entire execution and per-family diagnostic payload','follow_up':'new candidate required for unsatisfied domain/teacher contracts'},
 'query':{'attempt_id':ATT,'stage':'saved_full120_final_query','family':'HDS combined frozen registry68','frozen_code_sha256':freeze['files'][str(R/'接続/ARC2/HDS接続.py')],'all_family_code_manifest':ref(C/'production-freeze.json','/files'),'input_provenance':ref(C/'input-only.json'),'allowed_exposure_stage':'frozen teacher fit plus test-input-only execution; scores read from saved outputs only','raw_source':ref(C/'optimized-official.json'),'candidate_counts_exhaustiveness':'All167 final results; all fitted models must succeed and agree. No-answer/HOLD and runtime/resource axes distinct.','observed_vs_inferred_cause':'Final status/reasons observed. Answered=correct follows saved wrong0 and per-task answered==correct count, not a target reread.','retained_diagnostic_data':'Complete answer grids and native reasons in execution','follow_up':'remaining59 task closures; do not alter frozen candidate from query observations'},
 'negative_alternative':{'attempt_id':ATT,'stage':'teacher_negative_alternative','family':'ARC距離順位回収','frozen_code_sha256':freeze['files'][str(R/'接続/ARC2/距離回収候補.py')],'input_provenance':ref(C/'production/検証/fixtures/距離回収教師.json','/train'),'allowed_exposure_stage':'teacher only','raw_source':ref(C/'negative-alternative-evidence.json'),'candidate_counts_exhaustiveness':'All13 named alternatives × all3 teachers; full finite search separately indexed','observed_vs_inferred_cause':'Saved exact/failure/differences only','retained_diagnostic_data':'All alternative parameters, mismatch coordinates, selected cells and native failure reasons','follow_up':'Retain negative evidence unchanged'}}
ctxp=write('sample-event-contexts.json',{'schema':'arc2-shared-event-context-v1','context_resolution':'Each event inherits the named context. Together context+event supplies every reviewer-gate failure record field. No original payload is replaced.','contexts':contexts,'failure_type_rule':'Exact mechanical label from saved state. Descriptive scope failures use out_of_scope; grid mismatch is teacher_reproduction_failure; final unanswered is query_HOLD. Ambiguity is explicit tie/disagreement. No resource failure inferred from no-answer.'})
events=[];counts=collections.Counter();rawstatus=collections.Counter()
def event(context,key,typ,status,locator,**more):
 d={'event_id':ATT+':'+key,'context':context,'type':typ,'raw_reason_status':status,'raw_locator':locator,**more};events.append(d);counts[context+':'+typ]+=1
rawbytes=0;rawhash=hashlib.sha256();modelstats=collections.Counter()
with gzip.open(rawp,'rb') as f:
 for i,b in enumerate(f):
  x=json.loads(b);assert x['sequence']==i
  exact=x['candidate']==train[x['teacher_index']]['output'];reason=x['detail'].get('failure')
  status=reason or ('exact' if exact else 'grid_mismatch');rawstatus[status]+=1
  typ='success' if exact else ('ambiguous' if reason and ('tie' in reason or 'disagree' in reason) else 'candidate_generation_failure' if x['candidate'] is None else 'teacher_reproduction_failure')
  event('hypothesis_teacher',f'hypothesis-{i:05}',typ,status,{'line':i+1,'sequence':i,'uncompressed_byte_offset':rawbytes,'uncompressed_byte_length':len(b)},task_id_audit_only=x['task_id_audit_only'],teacher_index=x['teacher_index'],candidate_present=x['candidate'] is not None,teacher_exact=exact)
  rawhash.update(b);rawbytes+=len(b)
summary=read(C/'production-preflight/summary.json')
assert len(events)==30720 and rawhash.hexdigest()==summary['raw_events_sha256'] and rawbytes==summary['raw_events_bytes']
expected=collections.Counter()
for x in read(C/'fit-exhaustive-evidence.json')['diagnostics']['all_teacher_result_signatures']:
 for reason in x['signature']:expected[reason]+=x['count']
assert expected==rawstatus,(expected,rawstatus)
for i,x in enumerate(pre['records']):
 fit=x['fit'];tid=x['task_id_audit_only'];success=bool(x['models'])
 event('teacher_fit',f'fit-{i:03}','success' if success else 'out_of_scope',fit.get('failure','all_teacher_model_survived' if success else 'no_surviving_model'),{'pointer':f'/records/{i}'},task_id_audit_only=tid,teacher_count=x['teachers'],candidate_counts={'survivors':len(x['models']),'fully_evaluated':fit.get('fully_evaluated_candidates',0),'conceptual':fit.get('conceptual_candidates'),'logically_rejected':fit.get('logically_rejected_candidates')},raw_event_span=x['raw_event_span'])
 for j,r in enumerate(fit.get('role_assignments',[])):
  event('teacher_fit',f'role-{i:03}-{j:03}','success' if r['structural_pass'] else 'candidate_generation_failure','structural_pass' if r['structural_pass'] else {'teacher_failures':r['teacher_structural_failure'],'shapes':r['shapes']},{'pointer':f'/records/{i}/fit/role_assignments/{j}'},task_id_audit_only=tid,candidate_counts={'axis_evaluations':r.get('all_axis_evaluations',0),'logically_rejected':r.get('logically_rejected_parameter_combinations',0),'survivors':r.get('survivor_count',0)})
for i,x in enumerate(cur['execution']):
 for j,f in enumerate(x.get('families',[])):
  ok=f.get('採用可') and f.get('同値採用')
  event('family_fit',f'family-{i:03}-{j:02}','success' if ok else 'candidate_generation_failure' if f.get('状態')=='充足する候補なし' else 'teacher_reproduction_failure',f.get('状態'),{'pointer':f'/execution/{i}/families/{j}'},task_id_audit_only=x['task_id'],family=f.get('境界'),candidate_counts={'prior_observations':f.get('事前観測数'),'current_observations':f.get('現在観測数'),'admissible':f.get('採用可'),'equality_admitted':f.get('同値採用'),'quarantined':f.get('隔離数')})
 for j,r in enumerate(x['results']):
  event('query',f'query-{i:03}-{j:02}','success' if r.get('answer') is not None else 'query_HOLD',{'status':r.get('status'),'reasons':r.get('reasons',[])},{'pointer':f'/execution/{i}/results/{j}'},task_id_audit_only=x['task_id'],test_index=j,candidate_counts={'answered':r.get('answer') is not None,'agreeing_predictions':r.get('agreeing_predictions')},return_code=x.get('returncode'),resource_status=x.get('resource_failure'))
for i,x in enumerate(read(C/'negative-alternative-evidence.json')):
 for j,t in enumerate(x['teachers']):
  event('negative_alternative',f'negative-{i:02}-{j}','success' if t['exact'] else 'ambiguous' if 'tie' in (t.get('failure') or '') else 'candidate_generation_failure' if t.get('failure') else 'teacher_reproduction_failure',t.get('failure') or ('exact' if t['exact'] else 'grid_mismatch'),{'pointer':f'/{i}/teachers/{j}'},task_id_audit_only='dd6b8c4b',teacher_index=t['teacher_index'],alternative=x['alternative'])
rawidx=b''.join((json.dumps(x,ensure_ascii=False,separators=(',',':'))+'\n').encode() for x in events)
eventp=S/'全成功失敗HOLDイベント索引.jsonl.gz';eventp.write_bytes(gzip.compress(rawidx,mtime=0))
historypaths=[R/'検証/同一学習機械保持/summary.json',R/'検証/同一学習機械保持/retention-study/run-v1/raw-native-results.jsonl.gz',R/'検証/学習規則再観測比較.json',R/'検証/後半走破/開始点60/失敗HOLD索引.jsonl.gz',R/'検証/後半走破/開始点60/候補格子付き全記録_v3.jsonl.gz',R/'検証/後半走破/棄却001_矩形遮蔽/全標本manifest.json',R/'検証/後半走破/棄却001_矩形遮蔽/凍結候補と全標本.tar.gz']
samplep=write('全標本索引.json',{'schema':'arc2-candidate002-all-sample-index-v1','attempt_id':ATT,'context_contract':ref(ctxp),'event_index':ref(eventp),'event_count':len(events),'event_index_uncompressed_sha256':hashlib.sha256(rawidx).hexdigest(),'event_counts':dict(counts),'hypothesis_teacher_outcome_counts':dict(rawstatus),'coverage':{'tasks':120,'teachers':359,'fully_returned_hypothesis_teacher_grid_details':30720,'candidate_query_final_results':167,'native_family_records':sum(len(x.get('families',[])) for x in cur['execution']),'teacher_preflight_records':120,'structural_role_assignments':sum(len(x['fit'].get('role_assignments',[])) for x in pre['records']),'negative_alternative_teacher_records':39},'full_raw_samples':{'hypothesis_teacher':ref(rawp),'teacher_preflight_native_ledgers':ref(prepath),'query_input_only_both_variants':ref(C/'input-only.json'),'optimized_full120_execution':ref(C/'optimized-official.json'),'unmemoized_full120_execution':ref(C/'unmemoized-official.json'),'optimized_regressions':ref(C/'production-regressions.json'),'unmemoized_regressions':ref(C/'unmemoized-production-regressions.json')},'all_negative_history_unchanged':[ref(p) for p in historypaths],'classification_boundaries':['Exact saved events preserved; a candidate may match one teacher and fail the others. Individual success is not family adoption.','Final query_HOLD is separate from resource/timeout/error; current resource failures are empty.','Native family admission records are not full internal return traces for all pre-existing families. New integrator full120 v3 return replay is a separately hashed supplement when available.','Historical v1 states and negative observations are preserved as historical, not relabeled current.'],'zero_event_types_current_checkpoint':{'wrong_grid':0,'resource_failure':0,'timeout':0,'regression':0},'unperformed':['new text-ledger experience reobservation','long-lived67 HDS reinjection','new save/reload retention trial','hidden evaluation','publication final admission']})
# Verify every exact source quote in the row against its local immutable bytes.
row=read(S/'学習台帳/ARC2規則台帳_delta_068_v1.json')['規則'][0];quote_errors=[];verified=0
for k,f in row['項目'].items():
 for e in f['evidence']:
  p=S/e['source_path']
  if sha(p)!=e['content_sha256']:quote_errors.append([k,'hash',str(p)]);continue
  if 'line_start' in e:q='\n'.join(p.read_text().splitlines()[e['line_start']-1:e['line_end']])
  else:
   v=read(p)
   for t in e['pointer'].split('/')[1:]:t=t.replace('~1','/').replace('~0','~');v=v[int(t)] if isinstance(v,list) else v[t]
   q=v if isinstance(v,str) else json.dumps(v,ensure_ascii=False,separators=(',',':'))
   lo,hi=e['codepoint_span'];q=q[lo:hi]
  if q!=e['quote']:quote_errors.append([k,'quote',str(p)])
  else:verified+=1
assert not quote_errors,quote_errors
baseindex=read(S/'学習台帳/ARC2規則索引_composed_068_v1.json')
assert all(sha(R/x['repository_path'])==x['sha256'] for x in baseindex['base_unchanged'])
validp=write('final-package-validation.json',{'source_quotes_verified':verified,'source_quote_errors':quote_errors,'raw_hypothesis_teacher_records':30720,'raw_hypothesis_teacher_sha256_verified':rawhash.hexdigest(),'raw_grid_details_byte_count_verified':rawbytes,'raw_outcome_counts_equal_saved_exhaustive_signatures':True,'all_event_ids_unique':len({x['event_id'] for x in events})==len(events),'base_v1_files_byte_unchanged':True,'frozen_code_files_verified':len(freeze['files']),'same21field_and5origin_schema':len(row['項目'])==21 and len(row['由来五分類'])==5,'no_runtime_query_evaluation_or_target_read':True,'current_stage':'artifact packaging validation; independent admission remains pending'})
(S/'README.md').write_text('''# 到達点61・距離回収の採用証拠案\n\n保存済み検証出力だけから作成した、比較・068追加台帳・経験・全標本索引です。runtime実行、再採点、test target読取、Git書込は行っていません。最終採否はintegratorと独立gate待ちです。\n\n- 比較.json: 21項目、五由来、previous/current/delta、全回帰、4新規意味helperと制御実装の分離\n- 学習台帳/: 旧67v1を再生成しないappend-only 068台帳・経験・合成索引。publication commitはnull/pending\n- checkpoint61.json: 完全61/120、正解86/167、partial7、HOLD59課題/81例、wrong0、resource0\n- 全標本索引.json と 全成功失敗HOLDイベント索引.jsonl.gz: 全教師候補戻値30720件、全120native family記録、全167最終例、39代替教師検査、全構造棄却を索引\n- sample-event-contexts.json: イベント共通の凍結code・出典・stage・検査範囲。eventとcontextを合成して読む\n- sources/: 原文の変更なし複写。旧retention FAIL、保存exit137、意味Level3未知、棄却001と開始点60全標本を保持\n\n全path/source_path/archive_pathはこのpackage root相対です。JSON Pointerはdecoded JSON、codepoint_spanはUnicode code point、line_start/endは1-based inclusiveです。gzip原標本のbyte offsetは展開後UTF-8に対するものです。旧v1の参照は合成索引のrepository_pathとSHAで検証します。\n\nsource_distancesは新規adapterであり、旧BFS再利用やHDSによる距離学習ではありません。既存関数再利用はopen_components/clone_gridとNEIGHBORS_4/8定数。厳密な「新規規則なし」再利用閉鎖は0課題、既存helper＋新規合成は1課題です。\n\n068文章経験の標準interfaceは記録のみでnativeへ未投入です。HDS実学習は3教師boardの候補→出力同値のみ。seed/target全域の起点2モデルを残し、どちらも成功し完全格子一致した場合だけ回答します。\n''')
write('報告十項目.json',{'対象':'candidate002距離回収。全120閉鎖に向けた到達点61の採用証拠案。publication/admissionはpending。','観測':'保存済み全120/167評価は60課題84例→61課題86例。dd6b8c4b完全解決、既存84正解格子不変、wrong0/resource0。68script/1162testはmemo/非memo両方PASS。','既存規則適用結果':'旧67v1 bytes不変。21項目・五由来を同一row schemaで068追加。厳密な新規規則なし再利用閉鎖0課題、既存helper＋新規合成で1課題。実再利用はopen_components/clone_gridとNEIGHBORS_4/8。','不足':'未完了59課題81例。旧retention FAIL、保存exit137×2、意味Level3未知は不変。source_distancesは新規adapter。全baseline primitive censusは未実施。','候補':'新規1family、parse/source_distances/ordered_slots/render_preparedの4意味helper。fit/consensus/cache/wrapper/guardは制御・補助実装として分離。origin2モデルを両方保持し全成功・完全格子一致を必須とする。','反証':'30720仮説教師全格子・詳細、1080構造role、120fit、8160family、167query、39代替教師検査を40286イベントとして索引。過去negative/棄却001/retentionの原文もlossless保存。','適用範囲':'教師5色role・3×3中心seed単一target、入力由来距離/容量prefixの回収。公開開発評価でhidden一般化未確認。nearest容量prefixは課題作用で探索枝刈りではない。','未確認事項':'068文章経験は既存interfaceに記録のみ、旧67長寿命HDSに再投入なし。task-native HDSは3教師board候補→出力同値のみ。最終採否/公開commit未確定、full120 v3戻値replayは独立supplement待ち。','推奨次検査':'独立gateが同一schema、quote/hash、全samplecoverageを確認後integratorが採用判断。残る閉鎖は別candidateとして凍結・検証し、本候補をquery駆動で変更しない。','証拠参照':[ref(S/'比較.json'),ref(S/'学習台帳/ARC2規則台帳_delta_068_v1.json'),ref(S/'学習台帳/ARC2規則経験_delta_068_v1.jsonl'),ref(S/'学習台帳/ARC2規則索引_composed_068_v1.json'),ref(S/'checkpoint61.json'),ref(samplep),ref(validp)]})
# Hash every payload (excluding only manifest, archive and publication proposal to avoid cycles).
exclude={'lossless-manifest.json','evidencearchive.tar.gz','publication-proposal.json'}
files=[]
for p in sorted(S.rglob('*')):
 if not p.is_file() or p.relative_to(S).as_posix() in exclude:continue
 ent={'path':sp(p),'bytes':p.stat().st_size,'sha256':sha(p),'source_original_path':originals.get(sp(p))}
 if p.suffix=='.gz' and not p.name.endswith('.tar.gz'):
  b=gzip.decompress(p.read_bytes());ent.update(decoded_bytes=len(b),decoded_sha256=hashlib.sha256(b).hexdigest())
 files.append(ent)
manifest=write('lossless-manifest.json',{'schema':'arc2-candidate002-lossless-evidence-manifest-v1','attempt_id':ATT,'base_commit':BASE,'freeze_sha256':freezehash,'publication_commit':None,'publication_status':'pending; staging only','files':files,'lossless':'Each source copied byte-for-byte. Existing gzip preserved verbatim and decoded hash recorded. No negative, failure, historical v1 record or quote was rewritten.','coverage':'This candidate evidence, frozen runtime source set, old67 ledger bytes, baseline/rejected001/retention published history, and event indexes. Separate v3 replay may be appended by integrator after its completion.','exclusions':['official original input/solutions datasets not read or copied','unmemoized-shadow directory duplicate excluded; exact source and shadow manifest retained','Python cache files','self manifest/archive/proposal hash-cycle exclusions only']})
# Deterministic tar/gzip, then read every member and verify actual bytes against manifest.
archive=S/'evidencearchive.tar.gz'
with archive.open('wb') as raw:
 with gzip.GzipFile(filename='',mode='wb',fileobj=raw,mtime=0) as gz:
  with tarfile.open(mode='w',fileobj=gz,format=tarfile.PAX_FORMAT) as tar:
   for p in [S/x['path'] for x in files]+[manifest]:
    b=p.read_bytes();t=tarfile.TarInfo(sp(p));t.size=len(b);t.mtime=0;t.mode=0o644;t.uid=t.gid=0;t.uname=t.gname='';tar.addfile(t,io.BytesIO(b))
with tarfile.open(archive,'r:gz') as tar:
 members=tar.getmembers();assert len(members)==len(files)+1
 by={x['path']:x for x in files}
 for m in members:
  if m.name=='lossless-manifest.json':assert tar.extractfile(m).read()==manifest.read_bytes();continue
  b=tar.extractfile(m).read();assert hashlib.sha256(b).hexdigest()==by[m.name]['sha256']
proposal=write('publication-proposal.json',{'schema':'arc2-candidate002-publication-proposal-v1','status':'proposed only; no Git writes/upload','publication_commit':None,'publication_commit_state':'pending integrator final independent gate','package_root_proposal':PUB,'path_resolution':'All relative source paths resolve at package root. Keep nested 学習台帳 payloads within this root unless the integrator updates path interpretation explicitly. Existing repository 学習台帳/*_v1 bytes must not change.','standalone_review_files':[{'from':sp(S/n),'to':PUB+'/'+n,'sha256':sha(S/n)} for n in ['比較.json','checkpoint61.json','全標本索引.json','sample-event-contexts.json','全成功失敗HOLDイベント索引.jsonl.gz','学習台帳/ARC2規則台帳_delta_068_v1.json','学習台帳/ARC2規則経験_delta_068_v1.jsonl','学習台帳/ARC2規則索引_composed_068_v1.json','lossless-manifest.json','final-package-validation.json','README.md']],'lossless_archive':{'from':sp(archive),'to':PUB+'/evidencearchive.tar.gz','bytes':archive.stat().st_size,'sha256':sha(archive),'member_count':len(files)+1,'all_members_verified_against_manifest':True},'manifest':ref(manifest),'gate_inputs':[ref(S/'stage1-validation.json'),ref(validp),ref(A/'reviewer-candidate002-optimized-score.json'),ref(A/'reviewer-candidate002-full120-parity.json')],'acceptance_owner':'integrator + independent gate; this package does not self-adopt','pending_supplements':['new full120 v3 returned-sample replay if produced; do not relabel pending as PASS']})
print(json.dumps({'status':'packaged','root':str(S),'events':len(events),'event_counts':dict(counts),'artifact_paths_hashes':[ref(p) for p in [samplep,eventp,validp,manifest,archive,proposal]],'archive_bytes':archive.stat().st_size},ensure_ascii=False))
