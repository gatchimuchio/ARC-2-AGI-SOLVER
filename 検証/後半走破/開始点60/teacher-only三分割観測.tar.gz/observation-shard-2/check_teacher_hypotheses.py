"""Pure teacher-only diagnostics. No query API, scorer, or production edits."""
import json,collections
from pathlib import Path
HERE=Path(__file__).resolve().parent;D=json.loads((HERE/'teacher-only-tasks.json').read_text())
def comps(a,bg,mixed=True):
 pts={(r,c)for r,row in enumerate(a)for c,v in enumerate(row)if v!=bg};out=[]
 while pts:
  s=min(pts);pts.remove(s);color=a[s[0]][s[1]];seen={s};q=[s]
  while q:
   r,c=q.pop()
   for dr in (-1,0,1):
    for dc in (-1,0,1):
     t=(r+dr,c+dc)
     if t in pts and (mixed or a[t[0]][t[1]]==color):pts.remove(t);seen.add(t);q.append(t)
  out.append(seen)
 return out
R=[]
for tid in ['581f7754','e376de54']:
 evidence=[]
 for i,p in enumerate(D[tid]['train']):
  a=p['input'];h,w=len(a),len(a[0]);bg=collections.Counter(v for row in a for v in row).most_common(1)[0][0]
  g=[[bg]*w for _ in a]
  if tid=='581f7754':
   cs=comps(a,bg);anchors=[next(iter(s))for s in cs if len(s)==1];movements=[]
   assert anchors
   for s in cs:
    if len(s)==1:
     r,c=next(iter(s));g[r][c]=a[r][c];continue
    pairs=[]
    for ar,ac in anchors:
     marks=[(r,c)for r,c in s if a[r][c]==a[ar][ac]]
     if len(marks)!=1:continue
     mr,mc=marks[0]
     if (ar in(0,h-1)) != (ac in(0,w-1)):
      dr,dc=(0,ac-mc) if ar in(0,h-1) else (ar-mr,0)
      pairs.append((ar,ac,mr,mc,dr,dc))
    assert len(pairs)==1,pairs
    ar,ac,mr,mc,dr,dc=pairs[0];movements.append(([mr,mc],[dr,dc],len(s)))
    for r,c in s:
     assert 0<=r+dr<h and 0<=c+dc<w
     assert g[r+dr][c+dc]in(bg,a[r][c])
     g[r+dr][c+dc]=a[r][c]
   evidence.append(f'train{i}: anchors={anchors}; marker/shift/area={movements}; exact={g==p["output"]}; color_count_conserved={collections.Counter(v for row in a for v in row)==collections.Counter(v for row in g for v in row)}')
   if g!=p['output']:evidence.append('difference='+str([(r,c,g[r][c],p['output'][r][c])for r in range(h)for c in range(w)if g[r][c]!=p['output'][r][c]]))
  else:
   cs=comps(a,bg,mixed=False);dirs=[]
   for dr,dc in [(0,1),(1,0),(1,1),(1,-1)]:
    if all(len({r*dc-c*dr for r,c in pts})==1 for pts in cs):dirs.append((dr,dc))
   assert len(dirs)==1;dr,dc=dirs[0]
   rows=sorted(cs,key=lambda item:next(iter(item))[0]*dc-next(iter(item))[1]*dr)
   L=len(rows[len(rows)//2]);ends=[sorted(pts,key=lambda x:x[0]*dr+x[1]*dc)for pts in rows]
   modes=[k for k in [0,-1] if len({e[k][0]*dr+e[k][1]*dc for e in ends})==1];assert len(modes)==1
   for pts,e in zip(rows,ends):
    r,c=e[modes[0]];col=a[r][c];s=1 if modes[0]==0 else -1
    for n in range(L):
     rr,cc=r+s*n*dr,c+s*n*dc;assert 0<=rr<h and 0<=cc<w;g[rr][cc]=col
   evidence.append(f'train{i}: direction={(dr,dc)}; ordered_lengths={[len(x)for x in rows]}; middle_length={L}; common_endpoint={modes}; exact={g==p["output"]}')
 row={'対象':tid,'観測':evidence,'既存規則適用結果':'existing-family-evidence.json参照。','不足':'現行候補にはこの参照関係がない。','候補':'上記入力-only関係を有限手続きで観測。実装提案の採否は親で判断。','反証':'不正role/複数role/範囲外はassertで診断停止。これはproduction guard実装ではない。','適用範囲':'このassigned teachersだけ。','未確認事項':'negative/metamorphic/regression/query未検査。','推奨次検査':'関係を既存primitiveへ合成できるかsource境界を検査。','証拠参照':['teacher-only-tasks.json','check_teacher_hypotheses.py']}
 R.append(row);print(tid,*evidence,sep='\n')
(HERE/'teacher-hypothesis-evidence.json').write_text(json.dumps(R,ensure_ascii=False,indent=2)+'\n')
