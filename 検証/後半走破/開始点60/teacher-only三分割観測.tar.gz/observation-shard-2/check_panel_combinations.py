"""Teacher-only panel relation diagnostics, observed panel coordinates are not a production parser."""
import json,collections
from pathlib import Path
HERE=Path(__file__).resolve().parent;D=json.loads((HERE/'teacher-only-tasks.json').read_text());rows=[]
for tid in ['7491f3cf','a32d8b75']:
 evidence=[]
 for i,p in enumerate(D[tid]['train']):
  a=p['input']
  if tid=='7491f3cf':
   parts=[[row[x:x+5]for row in a[1:6]]for x in[1,7,13,19]];bg=next(iter(set(v for row in parts[3]for v in row)));cue=[(r,c)for r,row in enumerate(parts[0])for c,v in enumerate(row)if v!=bg];candidates=[]
   for dr,dc in[(0,1),(1,0),(1,1),(1,-1)]:
    groups=collections.defaultdict(list)
    for r,c in cue:groups[r*dc-c*dr].append((r,c))
    for k,line in groups.items():
     extra=[(r,c)for r,c in cue if r*dc-c*dr!=k]
     if len(line)!=5 or len(extra)!=1:continue
     rr,cc=extra[0];side=rr*dc-cc*dr-k;g=[row[:]for row in a];overlap=[]
     for r in range(5):
      for c in range(5):
       val=r*dc-c*dr-k;v=bg
       if val*side<=0 and parts[2][r][c]!=bg:v=parts[2][r][c]
       if val*side>=0 and parts[1][r][c]!=bg:
        if v!=bg:overlap.append((r,c))
        v=parts[1][r][c]
       g[r+1][c+19]=v
     candidates.append(((dr,dc),k,extra,g==p['output'],overlap))
   evidence.append(f'train{i}: control direction/offset/sidepoint/exact/overlap={candidates}')
  else:
   glyph=[row[1:4]for row in a[1:4]];palette=sorted(set(v for row in glyph for v in row));assert len(palette)==2
   swap={palette[0]:palette[1],palette[1]:palette[0]};glyph=[[swap[v]for v in row]for row in glyph]
   pts=[(r,c)for r in range(5,12)for c in range(5)if a[r][c]!=0];r0,r1=min(r for r,c in pts),max(r for r,c in pts);c0,c1=min(c for r,c in pts),max(c for r,c in pts)
   layout=[[int((r,c)in pts)for c in range(c0,c1+1)]for r in range(r0,r1+1)]
   anchor=[(r-13,c-1)for r in range(13,16)for c in range(1,4)if a[r][c]!=0];arrow=[(r-17,c-1)for r in range(17,20)for c in range(1,4)if a[r][c]!=0];assert len(anchor)==1 and len(arrow)==2 and (1,1)in arrow
   tip=next(x for x in arrow if x!=(1,1));k={(0,1):0,(1,2):1,(2,1):2,(1,0):3}[tip]
   for _ in range(k):layout=[list(row)for row in zip(*layout[::-1])]
   g=[row[6:]for row in a];H,W=len(layout)*3,len(layout[0])*3;ar,ac=anchor[0];top=0 if ar==0 else len(g)-H;left=0 if ac==0 else len(g[0])-W
   assert ar in(0,2)and ac in(0,2)and top>=0 and left>=0
   n=0
   for r,row in enumerate(layout):
    for c,v in enumerate(row):
     if not v:continue
     n+=1
     for dr in range(3):
      for dc in range(3):g[top+3*r+dr][left+3*c+dc]=glyph[dr][dc]
   evidence.append(f'train{i}: layout_bbox={[r0,c0,r1,c1]}; anchor={anchor}; direction={tip}; clockwise={k}; tile_origin={(top,left)}; layout_shape={(len(layout),len(layout[0]))}; stamp_count={n}; exact={g==p["output"]}')
 rows.append({'対象':tid,'観測':evidence,'既存規則適用結果':'existing-family-evidence.json参照。','不足':'これは観測panel座標で関係を検査した診断であり、汎用input parserではない。','候補':'入力構造のparse一意性を別途先決し既存primitiveの合成として検査する。','反証':'教師3/3または4/4はquery能力を証明しない。','適用範囲':'assigned sanitized trainのみ。','未確認事項':'input-only panel parserと負例・変形検査・query・scorer未実施。','推奨次検査':'比較台帳と既存guardを用い、roleの成功後選び直しなしで合成可能か確認。','証拠参照':['teacher-only-tasks.json','check_panel_combinations.py']})
 print(tid,*evidence,sep='\n')
(HERE/'panel-combination-evidence.json').write_text(json.dumps(rows,ensure_ascii=False,indent=2)+'\n')
