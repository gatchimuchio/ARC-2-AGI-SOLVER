"""Observation-only: reads assigned teacher corpus; calls only pure current renderers."""
import json,sys
from pathlib import Path
ROOT=Path('/workspace/scratch/7408259c1ab2/arc2-second-half')
HERE=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT))
from 接続.ARC2.二軸補完教材 import guarded_render
from 接続.ARC2.既存二軸補完 import render_zero_mask_bidirectional_reflection_fill
D=json.loads((HERE/'teacher-only-tasks.json').read_text())
rows=[];shared=None;role_records=[]
for i,pair in enumerate(D['0934a4d8']['train']):
 a=pair['input'];h,w=len(a),len(a[0]);roles=[]
 for color in sorted({v for row in a for v in row}):
  cells=[(r,c)for r,row in enumerate(a)for c,v in enumerate(row)if v==color]
  r0,c0=min(r for r,c in cells),min(c for r,c in cells);r1,c1=max(r for r,c in cells),max(c for r,c in cells)
  if len(cells)==(r1-r0+1)*(c1-c0+1):roles.append((color,r0,c0,r1,c1))
 if len(roles)!=1:raise ValueError('input role not unique')
 color,r0,c0,r1,c1=roles[0];role_records.append(roles[0])
 enc={v:i+1 for i,v in enumerate(sorted({v for row in a for v in row}-{color}))};dec={v:k for k,v in enc.items()}
 norm=[[0 if v==color else enc[v] for v in row]for row in a]
 raw=[];guard=[]
 for R in range(2*h-1):
  for C in range(2*w-1):
   out,rec=render_zero_mask_bidirectional_reflection_fill(norm,R,C)
   if out is None:continue
   crop=[[dec[v]for v in row[c0:c1+1]]for row in out[r0:r1+1]]
   if crop==pair['output']:raw.append([R,C])
 # All raw axes retained until shared intersection, no guarded filtering here.
 axis_set=set(map(tuple,raw));shared=axis_set if shared is None else shared&axis_set
 rows.append({'対象':f'0934a4d8/train/{i}', '観測':[f'input roles before target: {roles}',f'encoding: {enc}',f'mask bbox: {[r0,c0,r1,c1]}'],
 '既存規則適用結果':[f'raw_crop_exact_axis_count={len(raw)}',f'raw_crop_exact_axes={raw}'],
 '不足':'元adapterは同寸法かつ0欠損の教師のみ。色矩形maskとcropが未表現。',
 '候補':'原入力の全支持がsolid bboxとなる唯一色を欠損役割とし、残色を1..9へ可逆符号化。現行raw二軸rendererとcropを合成。',
 '反証':'raw共通軸の一意性確定前にguardで候補を落とさない。',
 '適用範囲':f'教師{i}のみ。候補役割は出力寸法を見る前に一意。',
 '未確認事項':'全教師共通raw軸は別途交差集計。query未確認。',
 '推奨次検査':'共通raw軸が一意なら既存全軌道guardを適用。',
 '証拠参照':['teacher-only-tasks.json', '接続/ARC2/二軸補完教材.py', '接続/ARC2/既存二軸補完.py']})
print('SHARED',sorted(shared))
if len(shared)==1:
 axes=next(iter(shared))
 for i,pair in enumerate(D['0934a4d8']['train']):
  a=pair['input'];color,r0,c0,r1,c1=role_records[i]
  enc={v:j+1 for j,v in enumerate(sorted({v for row in a for v in row}-{color}))};dec={v:k for k,v in enc.items()}
  norm=[[0 if v==color else enc[v]for v in row]for row in a]
  g,rec=guarded_render(norm,axes)
  exact=g is not None and [[dec[v]for v in row[c0:c1+1]]for row in g[r0:r1+1]]==pair['output']
  rows[i]['既存規則適用結果'] += [f'shared_raw_axes={sorted(shared)}',f'guard_after_raw_unique_exact={exact}',f'guard_failure={rec.get("failure")}',f'orbits={rec.get("orbit_count")}; known_preserved={rec.get("observed_cells_preserved")}; filled={rec.get("filled_zero_count")}']
  print(i,rows[i]['既存規則適用結果'])
(HERE/'0934a4d8-axis-evidence.json').write_text(json.dumps(rows,ensure_ascii=False,indent=2)+'\n')
