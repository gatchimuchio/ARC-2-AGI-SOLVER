import json
from pathlib import Path
P=Path(__file__).resolve().parent
D=json.loads((P/'teacher-only-tasks.json').read_text());B={r['task_id']:r for r in json.loads((P/'baseline-observations.json').read_text())};E={r['対象']:r for r in json.loads((P/'existing-family-evidence.json').read_text())}
R=[]
def add(t,cls,obs,applied,gap,cand,neg,unknown,nextcheck,refs):
 b=B[t]
 row={'対象':t,'観測':['分類: '+cls,*obs],
 '既存規則適用結果':[f"baseline: 採用={[x['境界'] for x in b['adopted_families']]}; 既往正答例={b['previous_correct_examples']}; 未回答={b['unanswered']}。当workerはqueryを再実行していない。",*applied,*E[t]['既存規則適用結果']],
 '不足':gap,'候補':cand,'反証':neg,
 '適用範囲':f"assigned sanitized train {len(D[t]['train'])}対のみ。教師出力は観測/fitにだけ使用。原評価task・test入力/正解・query API・scorerは未使用。runtime実装・採用・HDS学習は行っていない。",
 '未確認事項':unknown,'推奨次検査':nextcheck,
 '証拠参照':[f'teacher-only-tasks.json#/{t}/train','teacher-observation.txt TASK '+t,'baseline-observations.json 対象'+t,'existing-family-evidence.json 対象'+t,*refs]}
 R.append(row)
add('36a08778','現行表現では原因未確定（教師範囲は既存familyで閉じる）',[
 '6教師全て背景7/流色6/障害2。盤面形は14×14、16×13、8×9、14×5、8×20、15×16。背景から6へ追加61/48/28/21/36/65cell。原6と全2は保存。',
 '流seedから下向きに進み、接触した障害の水平最大run直上と左右1cellへ分岐する。教師には盤外出口切詰め、非到達障害、複数seedがある。'],[
 '流路教材のfitはflow6/obstacle2に一意、現行guardを通し教師6/6完全再現。baselineは既存ARC下向き流路を採用済みだが1例HOLD。',
 '台帳044はtriggered_span_crosses_obstacleを全体HOLDにする明示境界を記録。教師再fitでこれを解除する根拠は増えていない。'],[
 '対象/関係/作用: 既存の三色role・下向き到達閉包・障害run上側展開と一致。保存: 非背景全保存＋背景→flowだけ。HOLD: 一意背景、役割palette、実発火span横障害、元出力不一致。prior: 下向きと左右出口規則は既存固定。未回答域の不足は教師から確定できない。'],[
 '新family不要。教師は現行familyだけで閉じる。新規原理候補を増やすより、歴史的HOLD境界を保持したまま未確認事項として残す。'],[
 '横spanに障害があるケースを無視・短縮・飛越許可してはならない。教師全再現6/6を未回答例の改善へ読み替えない。'],[
 '未回答入力そのものは読んでいない。現行学習経験だけで横障害時の作用を同定できるか不明。'],[
 '既存guard負例を保持。独立した追加教師証拠がない限り拡張案を実装・再評価しない。'],['学習台帳/ARC2規則台帳_v1.json#/規則/43','接続/ARC2/流路教材.py raw_fits/guarded_render','接続/ARC2/既存流路.py gravity_corridor_route'])
add('65b59efc','現行表現では原因未確定（教師範囲は既存familyで閉じる）',[
 '3教師は10×11→9×9、10×11→9×9、14×17→25×25。上段glyph辞書・中段token配置・下段palette markerがseparator5で区分される。glyph幅3/3/5の二乗が出力辺9/9/25。',
 '全入力の色数ではなくtokenごとのglyphとpaletteを結合する。入力のseparatorや辞書key色が出力にそのまま保存されるわけではない。'],[
 '現行凡例展開教材が3/3全教師を完全再現し、baselineでも採用済み。現在観測は未回答1例の原因を特定する追加証拠ではない。'],[
 '対象: glyph/map/palette slot。関係: token辞書一対一とmacro位置。作用: 無回転block product。保存: glyphのactive/blankを含むtile全cellと色別複写数。HOLD: raw separator role一意、slot重複/未帰属前景/非全単射/marker一意性/出力上限。prior: slot順・separator先決・glyph辺二乗は現行。これらを緩める理由は教師にない。'],[
 '既存familyをそのまま保持。新viewや役割再探索は未回答を見てから都合よく追加しない。'],[
 '教師3/3再現でも未回答例を閉じたとはしない。失敗slotを落とす、余剰前景を捨てる、成功するseparatorへ選び直すことは反証を隠す。'],[
 'baselineの未確定理由はfamily候補未確定までで、どのinput guardに当たるか当worker未確認。'],[
 '保存済みHOLDと所有条件を保持。独立証拠が得られた場合のみ、具体的な最小view差分を検査。'],['学習台帳/ARC2規則台帳_v1.json#/規則/7','接続/ARC2/凡例展開教材.py guarded_render','接続/ARC2/既存凡例展開.py'])
R.append(json.loads((P/'0934a4d8-observation.json').read_text()))
add('16de56c4','新規関係表現',[
 '3教師とも疎な点列。教師0は横列、教師1/2は縦列。変更は等間隔点の補完、場合によって始端2点の再着色。教師0の追加14cell＋9→6が2cell/8→3が2cell、教師1の追加11cell＋3→4が2cell、教師2追加13cell。',
 '教師0: row1の1は列0,3から6へ、row4の1は列0,1から右端へ。row8の9は列0,2だが列6の6を終端cueにすると0,2,4,6を6にする。row11の8は列0,1、列7の3まで3で埋める。',
 '教師1: 列18の9は下端row8/6から2間隔で上へ伸びるが、row3の5は位相外として保存。これは単純な行/列内全非背景統一を反証する。'],[
 '行周期は一意separatorの片側run長を周期として反対側へ重ねる。側周期は反復するsize≥3のkeyの上下。周期帯は境界barと教師fit schedule。いずれもこの点対/終端color契約を満たさず候補なし。'],[
 '対象: 境界起点の同色2点と同列/同行の残余。関係: 点間距離→周期、同位相の異色終端→停止と再着色。作用の線形補完/再着色自体は既存primitive。保存: 位相外の5を残す必要。HOLD: 始端方向/点対/終端役割が複数なら未確定。prior: 境界から読む向きと終端の意味は新しい関係であり既存run周期と同一ではない。'],[
 '先に4方向の境界起点point-pair viewを列挙し、全active列のcoverageと共通方向を入力だけで確定。その後等差列とterminal colorを解釈する候補。'],[
 '全非背景を終端とみなすと教師1の位相外5を誤消去。教師0の途中停止を無視して盤端まで延長する仮説も反証される。'],[
 '完全なinput-only parserと全教師候補の一意性は未検査。単一点、複数同位相終端、角起点、障害との交差は未観測。'],[
 '終端あり/なし・位相外色の負例を含めteacher-only全候補を比較。既存行周期のseparator guardを外して救済しない。'],['学習台帳/ARC2規則台帳_v1.json#/規則/53','学習台帳/ARC2規則台帳_v1.json#/規則/5','学習台帳/ARC2規則台帳_v1.json#/規則/19','接続/ARC2/行周期教材.py','接続/ARC2/側周期教材.py','接続/ARC2/周期帯教材.py'])
add('21897d95','現行表現では原因未確定',[
 '4教師は全面を多色領域へ区分し、色1の小さい矢印状glyphが領域内/境界にある。出力はglyphを除去した単純領域へ変わる。教師0/2は16×12→12×16、14×9→9×14と縦横交換、教師1/3は10×10。',
 '教師3の領域境界は保存されるが、右3領域は2へ、中央6領域は3へ、上2/下4領域は6へ。単純な全色一対一置換では4色→3色となる。教師0/2には9のL字cueもある。'],[
 '凡例矩形の左key列つき独立2列辞書は存在せず、sourceをsolid矩形または対角Lの2成分へ分ける契約とも異なる。軸反射の点/線markerによる個々の物体反射でも全教師fitなし。'],[
 '対象: 背景/前景の最多色分割より多色領域と局所glyphが必要。関係: 矢印の出発領域→隣接領域への色伝搬らしさはあるが、L字cueと全盤D4、矢印交差/競合の意味が未確定。作用/保存: 領域再色とglyph除去、場合により全盤寸法交換。HOLD/prior: 現行辞書や反射guardの単純拡張として扱えない。'],[
 '最初に元領域の潜在境界とglyph位置・向き・隣接領域をteacher-onlyで一覧化し、同時色転写関係を反証可能にする。新family実装は保留。'],[
 '単純回転だけではpaletteと領域の色変更を説明できない。単純色置換だけでは非正方教師の寸法交換を説明できない。矢印を見た目だけで命令と固定しない。'],[
 '全教師を説明する有限同時更新規則、9cueの意味、伝搬の一回/反復、競合色の選択が未確定。'],[
 '入力の全1glyphをC4/C8で抽出し、周囲色とD4型を列挙。teacher変化を関係表として照合してから最小不足を再分類する。'],['学習台帳/ARC2規則台帳_v1.json#/規則/9','学習台帳/ARC2規則台帳_v1.json#/規則/57','接続/ARC2/凡例矩形教材.py','接続/ARC2/軸反射教材.py'])
add('291dc1e1','既存primitiveの組合せ',[
 '4教師に0角と1/2の直交辺があり、内部背景8上に複数の厚さ2などの物体がある。出力は背景8の縦stack。形は20×8→12×6、8×11→8×4、8×28→14×8、8×23→14×6。',
 '辺1が横上なら左→右のrow-major、左辺なら上→下のcolumn-major、0角が右なら横の読順が逆、という順序候補が観測と整合する。内部の1/2は削除されない教師0があるので色全体削除は不可。',
 '外部辺を除いたpayloadの形と色面積を保ち、最大幅へ中央寄せし、背景行を詰めて直列化する候補。教師0は混色6/3/1/2および7/4が一つの物体として必要。'],[
 '成分直列は全同色C4成分を接触simple path順に1列へserializeし、高さ=前景画素数≤30を要求。ここでは離れた混色物体と幅4/6/8の形保存が必要。物体群整列の同寸法・単色・外観一意な物体契約は4教師全て照合false。'],[
 '対象: 辺cue除外後の混色全成分。関係: 辺役割によるscan順。作用: crop/平行移動/stack/中央配置は既存primitiveで足りる可能性。保存: payload色別面積と内部孔、辺cueだけ消費。HOLD: 辺役割曖昧、読順tie、偶奇中央差、overlapは保留。prior: 二辺の1/2意味と中央寄せは新たに明示する必要。'],[
 '成分抽出→辺順序正規化→全payload cropを隙間なく縦結合、という小さな合成を検査。既存成分直列の1列出力を恣意的に伸ばす新family化は避ける。'],[
 '全色1/2をcommandとして消すと教師0のpayload内1/2を破壊。component別色分離や面積順ソートでは順序と形が変わる。'],[
 '混色C4/C8選択、同じscan位置のtie、stack中央寄せの整数条件、input-only全役割一意性は未検査。'],[
 '辺構造だけでroleを先決し、全教師のpayload ownership/移動vector/色数を記録。全配置が一意になるかteacher-onlyで確認。'],['学習台帳/ARC2規則台帳_v1.json#/規則/30','学習台帳/ARC2規則台帳_v1.json#/規則/46','接続/ARC2/成分直列教材.py','接続/ARC2/物体群整列.py'])
add('3dc255db','新規入力view',[
 '3教師は矢印/漏斗状の大きい物体内に別色の点/成分があり、その内部成分を消して尖端の外へ同色の直線dot列を出す。教師0は4物体右向きと3物体左向き、教師1/2は上向き。',
 '教師0の二つの内部6点→右に2cell、二つの内部7点→左に2cell。外部6点は不変。教師1の3個9点→上に3cell、別の1個9→1cell。教師2の7画素はC4で3成分（5+1+1）になり出力3cell。画素数ではなく物理成分数が候補。'],[
 '標識計数は固定0 panel内odd-row markerに外部C8成分数を横stride2で表示。枠計数は色別外部componentを矩形中央rowのslotへ置く。対象役割・包含・方向・count connectivityが異なり教師候補なし。'],[
 '対象: 大物体の方向付き内部と内部別色C4成分。関係: 内外判定と尖端方向。作用: 計数/消去/連続dot描画は既存primitive。保存: 大物体および対象外6を保持、内部画素面積は保存しない。HOLD: 曖昧内部/方向/複数target色/盤外は保留。prior: 開いた漏斗でも内部とみなす新viewが必要。'],[
 '閉矩形frameへ押し込まず、左右railまたは尖端を持つ方向付き領域viewを定義し、既存countを接続できるか検査。'],[
 'C8 countだと斜め点を誤併合する。画素countだと教師2を7cellにして失敗。全同色を数えると教師0の外部6点を誤回収する。'],[
 '尖端/開口/内部の入力-only定義、複雑分岐物体、混色内域、描画範囲外は未検証。'],[
 'teacher-onlyで全大物体の4方向正規化と内部成分ownershipを列挙し、3/3同一領域規約で閉じることを検査。'],['学習台帳/ARC2規則台帳_v1.json#/規則/40','学習台帳/ARC2規則台帳_v1.json#/規則/35','接続/ARC2/標識計数教材.py','接続/ARC2/枠計数教材.py'])
add('4c416de3','新規入力view',[
 '3教師は背景1/8/2上の0矩形枠と各corner近傍の色cue。一部cornerに完成した局所motifがあり、他cornerのsingleton cueから同じ向き正規化motifを補完するように見える。枠は一部盤外で切れる。',
 '教師0: 既存8の6cell角装飾を手掛かりに3/4/2のsingletonが各6cellへ、別枠の4も6cellへ。教師1もcue色の各装飾が6cell。教師2は既存4の4cell角装飾と対応する1/3/8/9の4cell装飾。0枠の一部も上書きされる。'],[
 '基点複製は単一motif/marker roleとGCD pitchによる全mask平行展開。疎点転写は色別25点以下の閉路/graph補間とsingleton隣接anchor。複数枠cornerの正規化patchと完成/未完成対応は含まれずfitなし。'],[
 '対象: 0frameのcorner局所patchを共通座標へ写したview。関係: 完成patch→同corner距離のpartial cueへのD4対応。作用: mask複写と再色は既存。保存: 元装飾/対象外は保持するがframe色0も置換対象。HOLD: 複数template、対応不一致、partial clippingの証明不足は保留。prior: corner距離と外向き方向を入力から導出する新view。'],[
 'frameを消して全foreground成分へ分割するのではなく、corner参照frame付きpatchとして既存D4/mask copyを再利用する案。'],[
 '固定6cell motifだと教師2で失敗。背景だけをpaintする保存規則でも0frame置換を説明できない。盤外に切れた枠を無条件で捨てない。'],[
 '完成templateを教師出力なしで選ぶ条件、異template競合、見えていないcornerの意味は未検査。'],[
 '全cornerの入力局所patchと追加集合をD4正規化し、完成/partialの一致条件と元foreground保存をteacher-onlyで検査。'],['学習台帳/ARC2規則台帳_v1.json#/規則/22','学習台帳/ARC2規則台帳_v1.json#/規則/47','接続/ARC2/基点複製教材.py','接続/ARC2/疎点転写教材.py'])
add('581f7754','現行表現では原因未確定',[
 '3教師の全色個数は完全保存。境界のsingleton cueと、内部同色markerを含む混色物体がある。教師0/2は横移動、教師1は主に縦移動。',
 '入力-only仮説「境界cueと同色markerを軸合わせする平行移動」は教師0/2で完全一致。教師1では全色保存するが8cell不一致。3×3の3/1物体は観測出力で横にも-1移動し、単純なcue行合わせだけでは説明できない。'],[
 '標識移動は4役割box/fuel/filled/markerで距離min(fuel,destination)と接触marker消費を持つ。区切投射は一意separatorへ単色物体右端を接する。どちらもmarker座標合わせとは異なりfit0/none。'],[
 '対象/関係: 同色marker対応自体は入力で読めるが、教師1の追加横vectorが不足。作用: 原形・色保存の全体平行移動。保存/HOLD: 全source消去後同時proposal・色別個数・衝突なしは既存から再利用可能。prior: axis-only投射で全教師が閉じると主張できない。'],[
 '現段階は原因未確定。新しいnearest/center/packing tie-breakを足して8cell残差を隠さず、残差物体の位置関係を再観測する。'],[
 'teacher-hypothesis-evidence.jsonに2/3成功と教師1の全8相違座標を保存。色数保存だけは完全な教師再現を意味しない。'],[
 '横-1移動が同じ入力関係から導出可能か、単なる別規則/異常か未確定。'],[
 '全物体のsource/target bboxとmarkerの移動vectorを比較。既存familyの任意guard解除やqueryによるoffset選び直しは行わない。'],['teacher-hypothesis-evidence.json 対象581f7754','check_teacher_hypotheses.py','学習台帳/ARC2規則台帳_v1.json#/規則/38','学習台帳/ARC2規則台帳_v1.json#/規則/15','接続/ARC2/標識移動教材.py','接続/ARC2/区切投射教材.py'])
add('6e4f6532','既存primitiveの組合せ',[
 '教師0は縦の1/4/2二重barが2区画を作り、教師1は上下左右の2/3/4/7二重barが一つの枠を作る。内側の8主体混色物体に辺色labelと9markerがある。別の9単点/2cell位置が移動先候補。',
 '出力では枠barと8/辺色の各個数を保存、9だけ6→3。物体の回転/移動とmarker重なり消費が示唆される。9の単点/2cell形が物体と配置先の対応候補であり単なる最寄りではない。'],[
 '接触配置の2色payload＋単色slot役割、標識組立の二つのC4markerとtarget側群分割ではこの多色辺label/局所区画を処理できずfitなし。辺対応抽出はD4を辺色対応で一意にする既存語彙を持つ。'],[
 '対象: frame区画内の多色物体とmarker support。関係: 自己markerとdestination形照合、辺色→frame sideのD4対応。作用: D4/平行移動/同色marker重畳は既存primitive候補。保存: 枠・body全色数、重なったmarkerだけ減少。HOLD: D4またはanchor複数/異色衝突/外出しは保留。prior: 同時物体転送と各区画所有の新しい結合が必要。'],[
 '辺対応抽出の唯一D4証明と標識組立の同時移動証明を組み合わせる案を先に検査。別のorientation familyを一から追加しない。'],[
 '色別個数保存を9にも要求すると教師と矛盾。全9を消して描き直すとmarker所有が曖昧になる。辺を最頻色/最寄りで選ぶだけでは保証にならない。'],[
 '物体分解C4/C8、同色barとの切分け、全部品の一意対応、同色marker形の回転aliasは未確認。'],[
 '入力で全frame区画・marker support・辺labelを列挙し、全D4と全対応を保持して教師完全一致/唯一性を検査。'],['学習台帳/ARC2規則台帳_v1.json#/規則/59','学習台帳/ARC2規則台帳_v1.json#/規則/39','学習台帳/ARC2規則台帳_v1.json#/規則/31','接続/ARC2/既存辺対応抽出.py','接続/ARC2/標識組立教材.py','接続/ARC2/接触配置教材.py'])
add('7491f3cf','新規関係表現',[
 '4教師は全て7×25、外枠＋内部3本で5×5の4panel。controlは長さ5の水平/垂直/45度線と線外の1点。次の2panelがsource模様、最後がblank。元3panelとframeは保存。',
 '有限teacher診断: control線の点側（線上含む）へsource2、反対側（線上含む）へsource3を置く。線上の両者非背景重複ではsource2優先。4/4完全一致。方向は反対角/縦/主対角/横。色や点側の符号を固定していない。',
 'teacher0/1/3は重複が中心(2,2)の1cell、teacher2は重複なし。control strokeそのものを出力へpaintする規則ではない。'],[
 '四欄反復は内部だけの3separator、最初2binary mask/count＋最後2uniform paletteという異なる型。この入力は外枠込み5separatorでraw_layout_not_unique相当の契約外。凡例集合のpalette-set成分選択も該当しない。'],[
 '対象: equal-size panelと線/side点。関係: signed half-plane ownershipと線上二層優先。作用: mask intersect/unionと元canvas保持は既存primitive。保存: source/control/frameは不変、destinationだけ補完。HOLD: 分割・直線/点・背景・競合優先が未確定なら保留。prior: point側を第2panel、境界重複は第2優先という新規関係。'],[
 'panel抽出を共用し、新しいhalf-plane selectorだけを小さく加える候補。controlは全非背景を一本の連続stroke＋1点として完全所有させる。'],[
 '直線境界を排他的にどちらか一方へ割り当てると教師の線上模様を失う。重複色を無条件HOLDにするだけでもteacher0/1/3が閉じない。優先は明示prior/教師fitとして扱い、自然一意と呼ばない。'],[
 '診断は観測済みpanel座標を使ったためgeneric input-only parserは未実装。別panel寸法/複数off-line点/曲線/未知重複は未確認。query/過去候補の独立性未確認。'],[
 '外枠付きequal-panel viewの全役割一意性を先決。境界priorityの有限候補を教師fitし全適合modelを保持。全4教師、色置換/D4、複数役割、範囲外、衝突負例を調べる。'],['panel-combination-evidence.json 対象7491f3cf','check_panel_combinations.py','学習台帳/ARC2規則台帳_v1.json#/規則/21','学習台帳/ARC2規則台帳_v1.json#/規則/12','接続/ARC2/四欄反復教材.py','接続/ARC2/凡例集合教材.py'])
add('80a900e0','新規入力view',[
 '2教師の背景は0/1 checkerboard。0は全保存、1だけ既存色へ追加される。教師0は1→8が18cell、教師1は1→2が38cell/1→4が24cell、中央3の8cellは保存。',
 '中央は45度の3輪郭とその外側の3cell色線。出力はその外側色線から45度方向へ平行なrayを伸ばす。通常の一意最多背景は0を選べるが、可用canvasは1位相だけ。'],[
 '対角線橋は主色pair間の空白bridgeと内部markerから垂直対角線を描く。側周期はC4反復keyの上下tuple周期。checkerboardの二位相を一つの斜格子として読むviewも、中心外向きray ownershipも現行契約にない。'],[
 '対象: (r+c,r-c)斜格子の有効parityと中央motif。関係: 中央輪郭に対する外向きray。作用: 既存直線延長で足りる可能性。保存: 0parityと中心3/元色、1だけ変更。HOLD: 背景parity/中心/方向/異色ray交差が一意でなければ保留。prior: 45度lattice正規化の入力viewが不足。'],[
 'まず0/1 checkerboardを入力で証明し、斜格子へ可逆正規化して既存線分/射線primitiveと比較。背景0を単に塗れる空白として扱わない。'],[
 '通常C4成分抽出では全斜線がsingletonへ割れる。全対角線を両方向に延ばすと中央/反対側や不要領域を侵す。'],[
 '全外側3cell motifの解釈、片側rayの始点と停止、色交差時規則、他parity配色への一般化は未確認。'],[
 'teacher-onlyで斜座標の各線分と追加集合を記録し、両方向/外向き等の有限仮説を比べる。'],['学習台帳/ARC2規則台帳_v1.json#/規則/24','学習台帳/ARC2規則台帳_v1.json#/規則/25','学習台帳/ARC2規則台帳_v1.json#/規則/5','接続/ARC2/対角線橋教材.py','接続/ARC2/側周期教材.py'])
add('8b7bacbf','新規関係表現',[
 '4教師は丸い輪郭objectと斜/直線wire、唯一singleton seed色7または4。出力は一部輪郭内部の背景0だけをseed色へ。追加24/12/12/4cell、元前景は全保存。',
 '教師0はselected object内域7+9+4+4cell、教師1は3object×4cell、教師2も3×4cell（右盤端で切れた輪郭を含む）、教師3は1×4cell。全objectを無条件に埋めない。',
 '試行した入力only「mixed-C8 seed連結成分内の色別輪郭穴（canvas端を閉境界扱い）」は教師0/2/3で一致、教師1で余分な1穴4cellを埋める。C4接触node graphだけに変えると教師3を落とす。単純近接だけではwire attachmentが閉じない。'],[
 '成分最短経路は8近接graphと二terminal間の一意最短経路を再色。ここはseedからのattachmentで内域fill。穴輪郭はbinary input/5異色roleで全物体へoutline処理。どちらもfitなし。'],[
 '対象: wireと輪郭の意味役割を分けたgraph。関係: どの接触がwire attachmentで、どれが近接/接線かを区別する不足。作用: hole fillは既存。保存: 非背景/非選択穴保存。HOLD: attachment不確定、閉じない輪郭、seedrole複数は保留。prior: C4/C8どちらか一律では教師を説明できない。'],[
 'typed attachment relationを先に観測し、既存成分graph＋背景領域fillを合成する候補。新しい最短距離tie-breakは入れない。'],[
 'mixed-C8 floodは教師1に4cell反例、C4だけは教師3で未到達。canvas端のpartial輪郭を全部捨てると教師2に反例。'],[
 'teacher1の近接輪郭を除く入力幾何条件、wire端点の向き/継続、branch・cycle・複数seed時の定義は未確定。'],[
 '輪郭別の全wire接触を局所方向つきで一覧化し、反例を残したままattachment述語を教師全体で照合。'],['学習台帳/ARC2規則台帳_v1.json#/規則/29','学習台帳/ARC2規則台帳_v1.json#/規則/50','学習台帳/ARC2規則台帳_v1.json#/規則/48','接続/ARC2/成分経路教材.py','接続/ARC2/穴輪郭教材.py','接続/ARC2/種境界教材.py'])
add('a32d8b75','既存primitiveの組合せ',[
 '3教師は20×30→20×24。左6列が制御stripで右24列canvasはcropして保持。左に二色3×3glyph、binary layout、singleton corner cue、中心＋隣1cellのdirection cue。',
 '観測panel座標で検査した合成は3/3完全一致: glyph2色を交換、layoutをdirection(up=0/right=90/down=180度)で回転、glyph block product、corner cueへcanvas内bboxを合わせ全tileをoverlay。',
 '教師0/1/2はstamp16/9/9個、回転180/0/90度、配置origin(2,9)/(0,0)/(0,9)。背景canvasの模様はstamp外で保存。'],[
 '配置展開は混色C8 motifと単色layoutのちょうど2成分・無回転・tight bbox積を新canvasへ出力。凡例展開はtop辞書/map/paletteのtoken積。両者は制御strip、方向/anchor、既存canvasへのoverlayとglyph色交換を含まない。'],[
 '対象: glyph/layout/角/向き/canvasを構文で分けたview。関係: direction→D4、corner→配置原点。作用: 二色交換＋回転＋block product＋crop/overlayは既存primitiveの組合せ。保存: canvasの非stamp全cell、各glyph色数×mask数。HOLD: raw分割/各roleが複数、OOB、未帰属pixelは全体保留。prior: cue符号とswapは新結合規約で自然一意ではない。'],[
 '配置展開のproduct kernelを再利用し、control parserとD4/anchorの小さな合成を検査。元familyの2成分/無回転guardは維持。'],[
 'swapなし、layout無回転、canvas背景を単色化、stampをclipする仮説はいずれも教師差分と不一致。診断の固定観測panel座標をruntime task専用規則として移してはならない。'],[
 'generic parserの一意性、制御色alias、複数glyph、他方向/中央anchor、marker位置の曖昧性は未検査。queryなし。'],[
 'separator構造から任意寸法のstrip/slotをinput-only parseできるか先に検査。全teacherと色置換、移動、各cue破壊、複数roleを負例にする。'],['panel-combination-evidence.json 対象a32d8b75','check_panel_combinations.py','学習台帳/ARC2規則台帳_v1.json#/規則/62','学習台帳/ARC2規則台帳_v1.json#/規則/7','接続/ARC2/配置展開教材.py','接続/ARC2/凡例展開教材.py'])
add('abc82100','現行表現では原因未確定',[
 '4教師は5×5/15×15/20×20/8×8。色8の小glyphと隣接する2色のcode、別領域のsource点群がある。出力から8とlegendが消え、source点位置付近に別色glyphがstampされるように見える。',
 '同色overlapのunion、盤端切詰め、複数dictionary、source再色等が混ざる。教師3は縦2列と横1列の色が交換されcode8が消える。単一色の全画素置換だけでない。'],[
 '倍率置換は2motif交換とscale anchor保存、基点複製は全marker差GCDと元motif原点への展開。現在どちらも教師fitなし。',
 '歴史的keyed-stamp-rejection.jsonは4教師714cell再現後、固定input-only56 role組合せ完走でrole0/HOLDとなりREJECT、scoringなし・条件変更なしを記録。この負例は継承する。'],[
 '対象/関係: glyphと色codeのjoint role抽出が未閉。作用: stamping自体は既存primitive。保存: code消費とpayload変更の所有が必要。HOLD: 役割0/複数を描画成功やqueryに合わせて救済不可。prior: 旧keyed-stampのteacher fitを新たな証拠として再計数しない。'],[
 '新family再投入は保留。独立した入力role表現の証拠が見つかった場合に、旧negativeを保ったteacher-only比較として扱う。'],[
 '過去56joint-role全探索で0という結果を、成功roleだけ抽出する探索へ変えて救済してはならない。教師4/4だけで再採用しない。'],[
 'keyed-stamp parserのどの意味関係が不足していたかは当teacher観測だけでは確定しない。旧query格子/targetは開いていない。'],[
 '既存negativeと入力role所有の差分を先に言語化。query-based retryや新たな色/距離例外を加えない。'],['学習台帳/ARC2規則台帳_v1.json#/規則/4','学習台帳/ARC2規則台帳_v1.json#/規則/22','接続/ARC2/倍率置換教材.py','接続/ARC2/基点複製教材.py','/workspace/scratch/7408259c1ab2/arc2-restored-592d2c5-audit/keyed-stamp-rejection.json（decision/reasonのみ参照）'])
add('cbebaa4b','新規関係表現',[
 '2教師は22×22、複数の単色形状に色2の接合marker、中央に色4の3×3anchor。出力では4anchorが同位置のまま他部品が上下左右に接続される。',
 'body色の全個数は保存、2は両教師16→8。markerの重複/接続消費が必要。教師0は上に3→8→4、右下側へ1→5が連結する。元body形は平行移動候補である。'],[
 '重畳組立は全8成分bboxの背景も含むoverlap一致と最大spanning-tree一意性、標識組立は2つのmarker component＋二色target群の一回移動。今回の多部品port match graph、固定anchor、連鎖は現行範囲外。'],[
 '対象: markerを含む各部品とanchor。関係: 接合portの個数/間隔/向きによる全部品graph。作用: 平行移動と同色marker重畳。保存: 全bodyとanchor、重なる2だけ消費。HOLD: 複数assembly、cycle矛盾、異色body衝突、未使用部品は保留。prior: maximum overlapの重みで選ぶのではなくport制約として再表現する必要。'],[
 '既存重畳組立の全配置整合/所有検査を参考に、接合marker形による制約graphへ最小置換できるか検査。部品の順番lookupは作らない。'],[
 '2の全消去も全保存も教師と矛盾。最大pixel overlapだけではport意味とanchor固定を証明できない。'],[
 '部品のC4/C8分解、回転可否、全portの一意対応、全完成解数は未検査。'],[
 '全部品とport footprint、可能relative offsetを入力から列挙。4anchorを固定する役割証拠を先決し、全assembly合意をteacher-onlyで確認。'],['学習台帳/ARC2規則台帳_v1.json#/規則/63','学習台帳/ARC2規則台帳_v1.json#/規則/39','接続/ARC2/重畳組立教材.py','接続/ARC2/標識組立教材.py'])
add('db0c5428','現行表現では原因未確定',[
 '3教師は背景8、9×9の3×3tile ring（中央3×3blank）を含む。出力は元前景を保存し、追加は各81cell。リングの外周方向と中央へ3×3模様が増え、15×15程度の有効範囲になる。',
 '入力前景72cellに対し出力153cell。教師0の4/6/9、教師1の1/7、教師2の2/3/5/6はそれぞれ異なる位置模様を持つ。単一色のsolid ring拡大ではない。'],[
 '二軸補完は0欠損/同寸法の有限orbit埋め、格子自己マスクは32候補のmacro mask展開とseed合意。現行teacher fitなし。入力ring自体が中心反射対称でも、外側への新たな軸/translationはそこから自動的には得られない。'],[
 '対象: 3×3tileの局所変換とring配置。関係: 中央tile生成、外側tileの向きと位置の決定が不足。作用: 複写/反射が候補だがどの共通関係か未確定。保存: 元前景全保存、8→各色だけ。HOLD/prior: tile幅3/step3/15×15を未説明の固定答え文法にしない。'],[
 '全9tile位置（blank含む）と追加9tileのD4形状対応を教師出力で観測し、入力由来の反射軸/結合関係を同定する。実装提案は保留。'],[
 '元中心二軸だけでは外部canvasのunwitnessed軌道を解決しない。81追加という面積一致だけでパターン生成を説明したとはしない。'],[
 'どの原tile/細部から中央/外tileを作るか、全自然仮説の有限範囲、別寸法の規約が未確定。'],[
 '既存二軸/格子自己マスクの対象とrendererを変えずに、tile viewだけで教師が閉じるか反証優先で調べる。'],['学習台帳/ARC2規則台帳_v1.json#/規則/3','学習台帳/ARC2規則台帳_v1.json#/規則/36','接続/ARC2/二軸補完教材.py','接続/ARC2/格子自己マスク.py'])
add('de809cff','新規入力view',[
 '2教師は20×20、背景0と二つの大領域色（3/4または1/2）、散在noise。出力には色8が17/12cell追加され、領域中の元0が8へ、近傍が反対の領域色へ変わる。外側の小noiseが0化する。',
 '教師0の3/4領域は複数矩形と重なり、教師1の1/2は大矩形の段差境界を持つ。境界穴もあり、単なる完全閉穴の全抽出では不足。元0→反対領域色も起こるため近傍膨張が領域外へ及ぶ例がある。'],[
 '穴輪郭は全教師入力binary/5rolepaletteを要求し、body再色＋hole＋外outlineである。今回は3入力色/4出力色、二つの相互roleとnoise除去。遮蔽区画は薄い閉線と区画数unary出力で、solid領域の潜在復元とは異なる。'],[
 '対象: noiseを分けた潜在solid矩形/領域のview。関係: 領域内0欠損→8、周囲8近傍→他方body色。作用: 穴fill/近傍膨張/消去は既存primitive。保存: 大領域の非近傍部分を保持、noise消費。HOLD: 矩形/前後/穴の役割が複数なら保留。prior: 小成分を無条件noiseとする面積閾値は未導出。'],[
 '先に全大領域の潜在bboxとnoise所有を入力だけで証明し、既存穴/膨張primitiveへ渡す案。binary穴輪郭のrole数guardを外さない。'],[
 '全0を埋めると外背景が壊れる。全小foregroundを消すだけでは領域内の境界noise/穴を説明できない。閉穴限定は境界へ開く欠損を落とす。'],[
 '潜在領域の復元/重なりorder/矩形の一意性、halo競合とnoise分類の全教師一致は未検査。'],[
 '入力maskの全bboxと元0位置を列挙し、同じ幾何規約で2教師の全変更集合を説明できるか検査。'],['学習台帳/ARC2規則台帳_v1.json#/規則/50','学習台帳/ARC2規則台帳_v1.json#/規則/60','接続/ARC2/穴輪郭教材.py','接続/ARC2/遮蔽区画教材.py'])
add('e376de54','現行表現では原因未確定（新関係候補の教師支持のみ）',[
 '3教師は16×16、平行な同色C8 straight run群。空間順の中央run長が他runの長さを決める候補。長さ列は[4,9,6,2,3]→全6（斜）、[2,7,12]→全7（横）、[6,3,4,4,2]→全4（縦）。',
 '各教師で一方の端点の方向投影が全runに共通。その端点を保持して中央長まで延長/切詰めする入力only診断は3/3完全一致。全run色は保持するが画素数は非保存。'],[
 '順位着色は上端header高さ→括りrun序数の再色、対称剪定は縦対称部分の最大保持。いずれもこの中央run参照/端点関係ではなく候補なし。',
 '歴史的ordered-line-rejection.json: signed lexicographic endpointの有限8ruleから唯一教師fitを得たがquery新規1誤答、production復元。exact missing relation unknown。今回の3/3を独立解決とは扱わず、旧grammar拡張/再選択禁止を保持。'],[
 '対象: 平行straight run。関係: 空間中央→長さ、共通端点投影→固定端の候補は観測したが、旧失敗priorとの独立性が未証明。作用: 線伸縮。保存: 元色と選択端、前景個数は非保存。HOLD: 偶数run/端点不一致/複数方向は保留候補。prior: 中央選好と共通端点の範囲を教師3例だけで一般化できない。'],[
 '新規関係表現の候補として記録のみ。過去の新誤答を解消するためにqueryを参照した変更はしない。'],[
 '過去の唯一教師fit→query誤答は重要な反例経験。単に3/3再現したこと、線の向きが増えたことを改善や独立性にしない。'],[
 '共通端点が旧signed endpointと実質同じ選好か、どの意味関係が不足しているか未確定。旧query入力/正解は未閲覧。'],[
 '旧候補のteacher-only定義との意味差を先に比較し、独立した入力証拠がない限り実装再投入しない。'],['teacher-hypothesis-evidence.json 対象e376de54','check_teacher_hypotheses.py','学習台帳/ARC2規則台帳_v1.json#/規則/65','学習台帳/ARC2規則台帳_v1.json#/規則/23','接続/ARC2/順位着色教材.py','接続/ARC2/対称剪定教材.py','/workspace/scratch/7408259c1ab2/arc2-current-9acf512-audit/ordered-line-rejection.json（hypothesis/observed_failure/no_repairのみ参照）'])
add('f560132c','現行表現では原因未確定',[
 '2教師20×20→8×8/10×10。4つのwhole foreground部品、うち1つのhostに四つのglobal singleton色からなる2×2legend。全support面積64/100が出力面積と一致。hostはbody11/27＋legend4で15/31cell。',
 '出力では部品が回転/移動して全矩形をtileし、各部品はlegendの色へ再色。legend4cellは削除されずhost supportとして運ばれる。body色とlegend色集合は両教師でdisjoint。',
 '過去teacher-only詳細: 各部品が出力cornerを1つずつ所有、corner色は元legend TL/TR/BL/BRに一致。ただし完成owner mapをC4回転しcorner色を再割当すれば3つの別出力も同じ弱関係を満たす。'],[
 '標点組立はsingle marker hostの4回転＋aspect exact coverだが色保持・標点を(0,0)へ、再色しない。ここは2×2palette legendで役割が不一致。色群充填はteacher入力既存候補0だが候補出力もなし。',
 '過去piece-relations-teacher-f560132c-facts.mdはhost TL/無回転が教師で観測されるだけで入力-only証明でなく、C4全解数も未測定と明記。形状対応は出力条件付きである。'],[
 '対象: legendを含むwhole support。関係: 部品→corner/色とhost orientationが未確定。作用: exact-cover回転配置＋再色は既存primitive。保存: support全使用/無重複、legend4support保持、paletteは非保存。HOLD: orientation/色assignmentが複数なら全体保留。prior: square/host TL/無回転を入力証拠なしで追加して唯一化できない。'],[
 '既存組立を使うならまず追加orientation/corner priorを明示し、そのteacher支持と反証範囲を区別。現段階で新family実装を推奨しない。'],[
 'body色=legend keyという対応は両教師で不可能。legendを消すとsupport60/96になり足りない。C4-onlyでもglobal回転＋corner再色の別解を除去できない。'],[
 'hostの角/向きの入力-only決定、square aspect選択、全配置の一意性、D4反射許否が未確定。'],[
 '既存negative/ambiguity witnessを保持。出力から得たpiece-color対応をruntime辞書にせず、入力に独立したorientation証拠があるかだけを次観測とする。'],['学習台帳/ARC2規則台帳_v1.json#/規則/37','学習台帳/ARC2規則台帳_v1.json#/規則/52','接続/ARC2/標点組立教材.py','接続/ARC2/色群充填.py','/workspace/scratch/7408259c1ab2/arc2-restored-592d2c5-audit/piece-relations-teacher-f560132c-facts.md','/workspace/scratch/7408259c1ab2/arc2-restored-592d2c5-audit/piece-relations-teacher-f560132c.json（教師のみ）'])
assert len(R)==20 and set(r['対象']for r in R)==set(D)
FIELDS=['対象','観測','既存規則適用結果','不足','候補','反証','適用範囲','未確認事項','推奨次検査','証拠参照']
assert all(list(r)==FIELDS for r in R)
(P/'observations.json').write_text(json.dumps(R,ensure_ascii=False,indent=2)+'\n')
with (P/'observations-report.md').open('w')as f:
 for r in R:
  for field in FIELDS:
   val=r[field];f.write(field+'：'+ ('\n- '+'\n- '.join(val)if isinstance(val,list)else val)+'\n')
  f.write('\n')
print('wrote',len(R),'records',len((P/'observations.json').read_bytes()),'bytes')
