"""Observation only, teacher-only candidate adapters, no HDS query or scorer."""
import json,sys,importlib,inspect
from pathlib import Path
ROOT=Path('/workspace/scratch/7408259c1ab2/arc2-second-half');HERE=Path(__file__).resolve().parent
sys.path[:0]=[str(ROOT),str(ROOT/'HDS/学習系統/v0.4.2')]
D=json.loads((HERE/'teacher-only-tasks.json').read_text())
M={
'36a08778':['流路教材'], '65b59efc':['凡例展開教材'],
'0934a4d8':['二軸補完教材'], '16de56c4':['行周期教材','側周期教材','周期帯教材'],
'21897d95':['凡例矩形教材','軸反射教材'], '291dc1e1':['成分直列教材','物体群整列'],
'3dc255db':['標識計数教材','枠計数教材'], '4c416de3':['基点複製教材','疎点転写教材'],
'581f7754':['標識移動教材','区切投射教材'], '6e4f6532':['接触配置教材','標識組立教材'],
'7491f3cf':['四欄反復教材','凡例集合教材'], '80a900e0':['対角線橋教材','側周期教材'],
'8b7bacbf':['成分経路教材','穴輪郭教材'], 'a32d8b75':['配置展開教材','凡例展開教材'],
'abc82100':['倍率置換教材','基点複製教材'], 'cbebaa4b':['重畳組立教材','標識組立教材'],
'db0c5428':['二軸補完教材','格子自己マスク'], 'de809cff':['穴輪郭教材','遮蔽区画教材'],
'e376de54':['順位着色教材','対称剪定教材'], 'f560132c':['標点組立教材','色群充填']}
records=[]
for tid,names in M.items():
 res=[]
 for name in names:
  try:
   m=importlib.import_module('接続.ARC2.'+name)
   classes=[v for k,v in vars(m).items() if inspect.isclass(v)and v.__module__==m.__name__ and hasattr(v,'候補')]
   for c in classes:
    if name=='物体群整列':
     # no HDS machine constructed; only pure teacher correspondence function.
     r=[m.教師を照合(p)is not None for p in D[tid]['train']]
     res.append(f'{name}: pure教師を照合 {r}');continue
    o=c(D[tid]['train']);summary=o.記録()if hasattr(o,'記録')else vars(o)
    reason=[]
    for p in D[tid]['train']:
     a,b=o.候補(p['input'],{});reason.append({'candidate':a is not None,'exact':a==p['output'],'record':b})
    # bounded metadata, not full generated grids or large proof records.
    compact=[{'candidate':r['candidate'],'exact':r['exact'],'failure':r['record'].get('failure')}for r in reason]
    res.append(f'{name}/{c.__name__}: summary={summary}; teachers={compact}')
  except Exception as e:res.append(f'{name}: diagnostic exception {type(e).__name__}: {str(e)}')
 row={'対象':tid,'観測':'現在familyの教師-only候補診断。','既存規則適用結果':res,'不足':'各結果の意味はobservations.jsonで幾何とsourceguardへ対応。','候補':'この診断は候補を新実装しない。','反証':'不成立・HOLDを残す。','適用範囲':'sanitized assigned teachersのみ。','未確認事項':'queryと評価は未実施。','推奨次検査':'sourceguardと教師差分を照合。','証拠参照':['teacher-only-tasks.json','接続/ARC2/各記載module.py']}
 records.append(row);print(tid,*res,sep='\n',flush=True)
 (HERE/'existing-family-evidence.json').write_text(json.dumps(records,ensure_ascii=False,indent=2)+'\n')
