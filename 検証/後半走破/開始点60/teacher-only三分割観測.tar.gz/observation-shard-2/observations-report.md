対象：36a08778
観測：分類: 現行表現では原因未確定（教師範囲は既存familyで閉じる）。現行流路6/6。既往HOLDの横障害境界を変更する教師証拠なし。
既存規則適用結果：baseline: 採用=['ARC下向き流路']; 既往正答例=1; 未回答=1。当workerはqueryを再実行していない。
不足：詳細な対象/関係/作用/保存/HOLD/prior比較はobservations.jsonの当該項目。
候補：新family不要。教師は現行familyだけで閉じる。新規原理候補を増やすより、歴史的HOLD境界を保持したまま未確認事項として残す。
反証：横spanに障害があるケースを無視・短縮・飛越許可してはならない。教師全再現6/6を未回答例の改善へ読み替えない。
適用範囲：sanitized教師のみ。query/scorer/実装なし。
未確認事項：未回答入力そのものは読んでいない。現行学習経験だけで横障害時の作用を同定できるか不明。
推奨次検査：既存guard負例を保持。独立した追加教師証拠がない限り拡張案を実装・再評価しない。
証拠参照：observations.json、existing-family-evidence.json、teacher-observation.txt、当該項目の個別出典

対象：65b59efc
観測：分類: 現行表現では原因未確定（教師範囲は既存familyで閉じる）。現行凡例展開3/3。未回答例の具体的なinput guard原因は未確認。
既存規則適用結果：baseline: 採用=['ARC凡例token積展開']; 既往正答例=1; 未回答=1。当workerはqueryを再実行していない。
不足：詳細な対象/関係/作用/保存/HOLD/prior比較はobservations.jsonの当該項目。
候補：既存familyをそのまま保持。新viewや役割再探索は未回答を見てから都合よく追加しない。
反証：教師3/3再現でも未回答例を閉じたとはしない。失敗slotを落とす、余剰前景を捨てる、成功するseparatorへ選び直すことは反証を隠す。
適用範囲：sanitized教師のみ。query/scorer/実装なし。
未確認事項：baselineの未確定理由はfamily候補未確定までで、どのinput guardに当たるか当worker未確認。
推奨次検査：保存済みHOLDと所有条件を保持。独立証拠が得られた場合のみ、具体的な最小view差分を検査。
証拠参照：observations.json、existing-family-evidence.json、teacher-observation.txt、当該項目の個別出典

対象：0934a4d8
観測：分類: 新規入力view（既存二軸補完＋矩形mask抽出）。4教師とも30×30、多色テクスチャ内に全支持が一つのsolid矩形となる色が入力だけで唯一存在。現在4教師では色8だが、規則は色8へ固定しない。。矩形mask可逆view＋既存二軸＋cropで4/4。raw軸22/52/24/54→共通(31,31)1件→guard。
既存規則適用結果：baseline採用familyなし。現行二軸補完のpair_preserves_nonzero_and_fills_zeroはshape_mismatchで不適合。単にguardを緩める対象ではない。
不足：詳細な対象/関係/作用/保存/HOLD/prior比較はobservations.jsonの当該項目。
候補：最小案: 独立した入力viewで唯一のsolid色矩形を検出し、mask=0/既知=1..9の可逆符号化。既存raw二軸候補を全列挙して現在教師に対して共有軸をfitし、唯一性先決後に既存guardを再利用。元二軸familyの固定0契約は変えない。
反証：色役割を教師出力の寸法・正解・後段成功で選んではならない。solid全色矩形が複数なら全体HOLD。単一色canvasや既知なしもHOLD。
適用範囲：sanitized教師のみ。query/scorer/実装なし。
未確認事項：実装・HDS接続・negative tests・metamorphic tests・全体回帰・query全て未実施。教師4/4再現は性能改善や汎化を示さない。
推奨次検査：親で最小view案を採否判断。採用する場合、役割先決・可逆0符号化・raw軸一意性先決・crop完全所有をtargeted test。既知0/色置換/非30寸法/非31軸/矩形移動/複数role/無witness/既知競合/複数raw軸の負例を追加。
証拠参照：observations.json、existing-family-evidence.json、teacher-observation.txt、当該項目の個別出典

対象：16de56c4
観測：分類: 新規関係表現。境界2点の周期と同位相異色終端による補完候補。位相外5を保存する必要。
既存規則適用結果：baseline: 採用=[]; 既往正答例=0; 未回答=2。当workerはqueryを再実行していない。
不足：詳細な対象/関係/作用/保存/HOLD/prior比較はobservations.jsonの当該項目。
候補：先に4方向の境界起点point-pair viewを列挙し、全active列のcoverageと共通方向を入力だけで確定。その後等差列とterminal colorを解釈する候補。
反証：全非背景を終端とみなすと教師1の位相外5を誤消去。教師0の途中停止を無視して盤端まで延長する仮説も反証される。
適用範囲：sanitized教師のみ。query/scorer/実装なし。
未確認事項：完全なinput-only parserと全教師候補の一意性は未検査。単一点、複数同位相終端、角起点、障害との交差は未観測。
推奨次検査：終端あり/なし・位相外色の負例を含めteacher-only全候補を比較。既存行周期のseparator guardを外して救済しない。
証拠参照：observations.json、existing-family-evidence.json、teacher-observation.txt、当該項目の個別出典

対象：21897d95
観測：分類: 現行表現では原因未確定。局所矢印から領域間の色移動候補。L字cueと全盤向きが未確定。
既存規則適用結果：baseline: 採用=[]; 既往正答例=0; 未回答=2。当workerはqueryを再実行していない。
不足：詳細な対象/関係/作用/保存/HOLD/prior比較はobservations.jsonの当該項目。
候補：最初に元領域の潜在境界とglyph位置・向き・隣接領域をteacher-onlyで一覧化し、同時色転写関係を反証可能にする。新family実装は保留。
反証：単純回転だけではpaletteと領域の色変更を説明できない。単純色置換だけでは非正方教師の寸法交換を説明できない。矢印を見た目だけで命令と固定しない。
適用範囲：sanitized教師のみ。query/scorer/実装なし。
未確認事項：全教師を説明する有限同時更新規則、9cueの意味、伝搬の一回/反復、競合色の選択が未確定。
推奨次検査：入力の全1glyphをC4/C8で抽出し、周囲色とD4型を列挙。teacher変化を関係表として照合してから最小不足を再分類する。
証拠参照：observations.json、existing-family-evidence.json、teacher-observation.txt、当該項目の個別出典

対象：291dc1e1
観測：分類: 既存primitiveの組合せ。二辺cueのscan順＋混色物体crop＋中央stackの合成候補。全所有/一意性未検査。
既存規則適用結果：baseline: 採用=[]; 既往正答例=0; 未回答=1。当workerはqueryを再実行していない。
不足：詳細な対象/関係/作用/保存/HOLD/prior比較はobservations.jsonの当該項目。
候補：成分抽出→辺順序正規化→全payload cropを隙間なく縦結合、という小さな合成を検査。既存成分直列の1列出力を恣意的に伸ばす新family化は避ける。
反証：全色1/2をcommandとして消すと教師0のpayload内1/2を破壊。component別色分離や面積順ソートでは順序と形が変わる。
適用範囲：sanitized教師のみ。query/scorer/実装なし。
未確認事項：混色C4/C8選択、同じscan位置のtie、stack中央寄せの整数条件、input-only全役割一意性は未検査。
推奨次検査：辺構造だけでroleを先決し、全教師のpayload ownership/移動vector/色数を記録。全配置が一意になるかteacher-onlyで確認。
証拠参照：observations.json、existing-family-evidence.json、teacher-observation.txt、当該項目の個別出典

対象：3dc255db
観測：分類: 新規入力view。方向付き内部のC4成分数を尖端外へunary表示。教師2は7画素を3成分として数える。
既存規則適用結果：baseline: 採用=[]; 既往正答例=0; 未回答=1。当workerはqueryを再実行していない。
不足：詳細な対象/関係/作用/保存/HOLD/prior比較はobservations.jsonの当該項目。
候補：閉矩形frameへ押し込まず、左右railまたは尖端を持つ方向付き領域viewを定義し、既存countを接続できるか検査。
反証：C8 countだと斜め点を誤併合する。画素countだと教師2を7cellにして失敗。全同色を数えると教師0の外部6点を誤回収する。
適用範囲：sanitized教師のみ。query/scorer/実装なし。
未確認事項：尖端/開口/内部の入力-only定義、複雑分岐物体、混色内域、描画範囲外は未検証。
推奨次検査：teacher-onlyで全大物体の4方向正規化と内部成分ownershipを列挙し、3/3同一領域規約で閉じることを検査。
証拠参照：observations.json、existing-family-evidence.json、teacher-observation.txt、当該項目の個別出典

対象：4c416de3
観測：分類: 新規入力view。frame corner正規化patchから局所motif補完。6cell固定は教師2の4cellと矛盾。
既存規則適用結果：baseline: 採用=[]; 既往正答例=0; 未回答=1。当workerはqueryを再実行していない。
不足：詳細な対象/関係/作用/保存/HOLD/prior比較はobservations.jsonの当該項目。
候補：frameを消して全foreground成分へ分割するのではなく、corner参照frame付きpatchとして既存D4/mask copyを再利用する案。
反証：固定6cell motifだと教師2で失敗。背景だけをpaintする保存規則でも0frame置換を説明できない。盤外に切れた枠を無条件で捨てない。
適用範囲：sanitized教師のみ。query/scorer/実装なし。
未確認事項：完成templateを教師出力なしで選ぶ条件、異template競合、見えていないcornerの意味は未検査。
推奨次検査：全cornerの入力局所patchと追加集合をD4正規化し、完成/partialの一致条件と元foreground保存をteacher-onlyで検査。
証拠参照：observations.json、existing-family-evidence.json、teacher-observation.txt、当該項目の個別出典

対象：581f7754
観測：分類: 現行表現では原因未確定。境界cue軸合わせは2/3完全一致。教師1に8cell反例があり追加横移動が未説明。
既存規則適用結果：baseline: 採用=[]; 既往正答例=0; 未回答=2。当workerはqueryを再実行していない。
不足：詳細な対象/関係/作用/保存/HOLD/prior比較はobservations.jsonの当該項目。
候補：現段階は原因未確定。新しいnearest/center/packing tie-breakを足して8cell残差を隠さず、残差物体の位置関係を再観測する。
反証：teacher-hypothesis-evidence.jsonに2/3成功と教師1の全8相違座標を保存。色数保存だけは完全な教師再現を意味しない。
適用範囲：sanitized教師のみ。query/scorer/実装なし。
未確認事項：横-1移動が同じ入力関係から導出可能か、単なる別規則/異常か未確定。
推奨次検査：全物体のsource/target bboxとmarkerの移動vectorを比較。既存familyの任意guard解除やqueryによるoffset選び直しは行わない。
証拠参照：observations.json、existing-family-evidence.json、teacher-observation.txt、当該項目の個別出典

対象：6e4f6532
観測：分類: 既存primitiveの組合せ。辺色D4対応＋marker形anchor＋同時移動の合成候補。9だけ6→3、他色保存。
既存規則適用結果：baseline: 採用=[]; 既往正答例=0; 未回答=2。当workerはqueryを再実行していない。
不足：詳細な対象/関係/作用/保存/HOLD/prior比較はobservations.jsonの当該項目。
候補：辺対応抽出の唯一D4証明と標識組立の同時移動証明を組み合わせる案を先に検査。別のorientation familyを一から追加しない。
反証：色別個数保存を9にも要求すると教師と矛盾。全9を消して描き直すとmarker所有が曖昧になる。辺を最頻色/最寄りで選ぶだけでは保証にならない。
適用範囲：sanitized教師のみ。query/scorer/実装なし。
未確認事項：物体分解C4/C8、同色barとの切分け、全部品の一意対応、同色marker形の回転aliasは未確認。
推奨次検査：入力で全frame区画・marker support・辺labelを列挙し、全D4と全対応を保持して教師完全一致/唯一性を検査。
証拠参照：observations.json、existing-family-evidence.json、teacher-observation.txt、当該項目の個別出典

対象：7491f3cf
観測：分類: 新規関係表現。線/side点による二source半平面合成は4/4。線上重複はsource2優先。parserは未実装。
既存規則適用結果：baseline: 採用=[]; 既往正答例=0; 未回答=1。当workerはqueryを再実行していない。
不足：詳細な対象/関係/作用/保存/HOLD/prior比較はobservations.jsonの当該項目。
候補：panel抽出を共用し、新しいhalf-plane selectorだけを小さく加える候補。controlは全非背景を一本の連続stroke＋1点として完全所有させる。
反証：直線境界を排他的にどちらか一方へ割り当てると教師の線上模様を失う。重複色を無条件HOLDにするだけでもteacher0/1/3が閉じない。優先は明示prior/教師fitとして扱い、自然一意と呼ばない。
適用範囲：sanitized教師のみ。query/scorer/実装なし。
未確認事項：診断は観測済みpanel座標を使ったためgeneric input-only parserは未実装。別panel寸法/複数off-line点/曲線/未知重複は未確認。query/過去候補の独立性未確認。
推奨次検査：外枠付きequal-panel viewの全役割一意性を先決。境界priorityの有限候補を教師fitし全適合modelを保持。全4教師、色置換/D4、複数役割、範囲外、衝突負例を調べる。
証拠参照：observations.json、existing-family-evidence.json、teacher-observation.txt、当該項目の個別出典

対象：80a900e0
観測：分類: 新規入力view。checkerboard二位相の斜格子viewと外向きray候補。0と中央3は保存。
既存規則適用結果：baseline: 採用=[]; 既往正答例=0; 未回答=1。当workerはqueryを再実行していない。
不足：詳細な対象/関係/作用/保存/HOLD/prior比較はobservations.jsonの当該項目。
候補：まず0/1 checkerboardを入力で証明し、斜格子へ可逆正規化して既存線分/射線primitiveと比較。背景0を単に塗れる空白として扱わない。
反証：通常C4成分抽出では全斜線がsingletonへ割れる。全対角線を両方向に延ばすと中央/反対側や不要領域を侵す。
適用範囲：sanitized教師のみ。query/scorer/実装なし。
未確認事項：全外側3cell motifの解釈、片側rayの始点と停止、色交差時規則、他parity配色への一般化は未確認。
推奨次検査：teacher-onlyで斜座標の各線分と追加集合を記録し、両方向/外向き等の有限仮説を比べる。
証拠参照：observations.json、existing-family-evidence.json、teacher-observation.txt、当該項目の個別出典

対象：8b7bacbf
観測：分類: 新規関係表現。seed/wire/輪郭attachmentが不足。mixed-C8は3/4、教師1に余分な4cell反例。
既存規則適用結果：baseline: 採用=[]; 既往正答例=0; 未回答=2。当workerはqueryを再実行していない。
不足：詳細な対象/関係/作用/保存/HOLD/prior比較はobservations.jsonの当該項目。
候補：typed attachment relationを先に観測し、既存成分graph＋背景領域fillを合成する候補。新しい最短距離tie-breakは入れない。
反証：mixed-C8 floodは教師1に4cell反例、C4だけは教師3で未到達。canvas端のpartial輪郭を全部捨てると教師2に反例。
適用範囲：sanitized教師のみ。query/scorer/実装なし。
未確認事項：teacher1の近接輪郭を除く入力幾何条件、wire端点の向き/継続、branch・cycle・複数seed時の定義は未確定。
推奨次検査：輪郭別の全wire接触を局所方向つきで一覧化し、反例を残したままattachment述語を教師全体で照合。
証拠参照：observations.json、existing-family-evidence.json、teacher-observation.txt、当該項目の個別出典

対象：a32d8b75
観測：分類: 既存primitiveの組合せ。glyph二色交換＋layout cue回転＋角合わせproduct/overlayは3/3。generic parser未証明。
既存規則適用結果：baseline: 採用=[]; 既往正答例=0; 未回答=2。当workerはqueryを再実行していない。
不足：詳細な対象/関係/作用/保存/HOLD/prior比較はobservations.jsonの当該項目。
候補：配置展開のproduct kernelを再利用し、control parserとD4/anchorの小さな合成を検査。元familyの2成分/無回転guardは維持。
反証：swapなし、layout無回転、canvas背景を単色化、stampをclipする仮説はいずれも教師差分と不一致。診断の固定観測panel座標をruntime task専用規則として移してはならない。
適用範囲：sanitized教師のみ。query/scorer/実装なし。
未確認事項：generic parserの一意性、制御色alias、複数glyph、他方向/中央anchor、marker位置の曖昧性は未検査。queryなし。
推奨次検査：separator構造から任意寸法のstrip/slotをinput-only parseできるか先に検査。全teacherと色置換、移動、各cue破壊、複数roleを負例にする。
証拠参照：observations.json、existing-family-evidence.json、teacher-observation.txt、当該項目の個別出典

対象：abc82100
観測：分類: 現行表現では原因未確定。過去keyed-stampはjoint role0/HOLDでREJECT。教師fit再現を新成果にしない。
既存規則適用結果：baseline: 採用=[]; 既往正答例=0; 未回答=1。当workerはqueryを再実行していない。
不足：詳細な対象/関係/作用/保存/HOLD/prior比較はobservations.jsonの当該項目。
候補：新family再投入は保留。独立した入力role表現の証拠が見つかった場合に、旧negativeを保ったteacher-only比較として扱う。
反証：過去56joint-role全探索で0という結果を、成功roleだけ抽出する探索へ変えて救済してはならない。教師4/4だけで再採用しない。
適用範囲：sanitized教師のみ。query/scorer/実装なし。
未確認事項：keyed-stamp parserのどの意味関係が不足していたかは当teacher観測だけでは確定しない。旧query格子/targetは開いていない。
推奨次検査：既存negativeと入力role所有の差分を先に言語化。query-based retryや新たな色/距離例外を加えない。
証拠参照：observations.json、existing-family-evidence.json、teacher-observation.txt、当該項目の個別出典

対象：cbebaa4b
観測：分類: 新規関係表現。marker port接合graph候補。body保存、色2は16→8。全assembly唯一性未測定。
既存規則適用結果：baseline: 採用=[]; 既往正答例=0; 未回答=2。当workerはqueryを再実行していない。
不足：詳細な対象/関係/作用/保存/HOLD/prior比較はobservations.jsonの当該項目。
候補：既存重畳組立の全配置整合/所有検査を参考に、接合marker形による制約graphへ最小置換できるか検査。部品の順番lookupは作らない。
反証：2の全消去も全保存も教師と矛盾。最大pixel overlapだけではport意味とanchor固定を証明できない。
適用範囲：sanitized教師のみ。query/scorer/実装なし。
未確認事項：部品のC4/C8分解、回転可否、全portの一意対応、全完成解数は未検査。
推奨次検査：全部品とport footprint、可能relative offsetを入力から列挙。4anchorを固定する役割証拠を先決し、全assembly合意をteacher-onlyで確認。
証拠参照：observations.json、existing-family-evidence.json、teacher-observation.txt、当該項目の個別出典

対象：db0c5428
観測：分類: 現行表現では原因未確定。3×3tile ringの外/中央へ81cell追加。tile生成関係が未確定。
既存規則適用結果：baseline: 採用=[]; 既往正答例=0; 未回答=1。当workerはqueryを再実行していない。
不足：詳細な対象/関係/作用/保存/HOLD/prior比較はobservations.jsonの当該項目。
候補：全9tile位置（blank含む）と追加9tileのD4形状対応を教師出力で観測し、入力由来の反射軸/結合関係を同定する。実装提案は保留。
反証：元中心二軸だけでは外部canvasのunwitnessed軌道を解決しない。81追加という面積一致だけでパターン生成を説明したとはしない。
適用範囲：sanitized教師のみ。query/scorer/実装なし。
未確認事項：どの原tile/細部から中央/外tileを作るか、全自然仮説の有限範囲、別寸法の規約が未確定。
推奨次検査：既存二軸/格子自己マスクの対象とrendererを変えずに、tile viewだけで教師が閉じるか反証優先で調べる。
証拠参照：observations.json、existing-family-evidence.json、teacher-observation.txt、当該項目の個別出典

対象：de809cff
観測：分類: 新規入力view。noise付き潜在solid領域view＋欠損/halo候補。境界穴と前後関係が未閉。
既存規則適用結果：baseline: 採用=[]; 既往正答例=0; 未回答=1。当workerはqueryを再実行していない。
不足：詳細な対象/関係/作用/保存/HOLD/prior比較はobservations.jsonの当該項目。
候補：先に全大領域の潜在bboxとnoise所有を入力だけで証明し、既存穴/膨張primitiveへ渡す案。binary穴輪郭のrole数guardを外さない。
反証：全0を埋めると外背景が壊れる。全小foregroundを消すだけでは領域内の境界noise/穴を説明できない。閉穴限定は境界へ開く欠損を落とす。
適用範囲：sanitized教師のみ。query/scorer/実装なし。
未確認事項：潜在領域の復元/重なりorder/矩形の一意性、halo競合とnoise分類の全教師一致は未検査。
推奨次検査：入力maskの全bboxと元0位置を列挙し、同じ幾何規約で2教師の全変更集合を説明できるか検査。
証拠参照：observations.json、existing-family-evidence.json、teacher-observation.txt、当該項目の個別出典

対象：e376de54
観測：分類: 現行表現では原因未確定（新関係候補の教師支持のみ）。中央run長＋共通端点は3/3。ただし旧endpoint grammarのquery誤答/rollbackを保持、独立性未証明。
既存規則適用結果：baseline: 採用=[]; 既往正答例=0; 未回答=1。当workerはqueryを再実行していない。
不足：詳細な対象/関係/作用/保存/HOLD/prior比較はobservations.jsonの当該項目。
候補：新規関係表現の候補として記録のみ。過去の新誤答を解消するためにqueryを参照した変更はしない。
反証：過去の唯一教師fit→query誤答は重要な反例経験。単に3/3再現したこと、線の向きが増えたことを改善や独立性にしない。
適用範囲：sanitized教師のみ。query/scorer/実装なし。
未確認事項：共通端点が旧signed endpointと実質同じ選好か、どの意味関係が不足しているか未確定。旧query入力/正解は未閲覧。
推奨次検査：旧候補のteacher-only定義との意味差を先に比較し、独立した入力証拠がない限り実装再投入しない。
証拠参照：observations.json、existing-family-evidence.json、teacher-observation.txt、当該項目の個別出典

対象：f560132c
観測：分類: 現行表現では原因未確定。legend付きsupport回転packing。corner再色したglobal C4別解がありorientation未確定。
既存規則適用結果：baseline: 採用=[]; 既往正答例=0; 未回答=1。当workerはqueryを再実行していない。
不足：詳細な対象/関係/作用/保存/HOLD/prior比較はobservations.jsonの当該項目。
候補：既存組立を使うならまず追加orientation/corner priorを明示し、そのteacher支持と反証範囲を区別。現段階で新family実装を推奨しない。
反証：body色=legend keyという対応は両教師で不可能。legendを消すとsupport60/96になり足りない。C4-onlyでもglobal回転＋corner再色の別解を除去できない。
適用範囲：sanitized教師のみ。query/scorer/実装なし。
未確認事項：hostの角/向きの入力-only決定、square aspect選択、全配置の一意性、D4反射許否が未確定。
推奨次検査：既存negative/ambiguity witnessを保持。出力から得たpiece-color対応をruntime辞書にせず、入力に独立したorientation証拠があるかだけを次観測とする。
証拠参照：observations.json、existing-family-evidence.json、teacher-observation.txt、当該項目の個別出典

