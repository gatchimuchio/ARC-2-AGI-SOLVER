import json
from pathlib import Path
P=Path(__file__).parent
m=next(x for x in json.load(open(P/'teacher-measurements.json'))if x['対象']=='dbff022c')
m.update({
'観測':{'要約':'全3教師は同寸法。孤立した完全占有の二lane凡例と、穴を持つ単色物体。変更は背景セルのみで9/6/2セル、全元前景と凡例は保存。','教師診断':m['観測'],'重要な位相':'教師0の色3はC4では3成分に割れ、閉穴7セルを失う。既存C8抽出で一物体にすると、既存C4非壁閉領域抽出が7セルを回収する。'},
'既存規則適用結果':{'baseline':'採用familyなし、現行暫定原理の適用に必要な観測が不足。再queryなし。','arc2-comparison-011 凡例穴対応':'入力色集合−出力色集合が空のため役割候補群=[]。穴数→prototype色で物体本体を再色する作用であり、この課題の壁色→穴色とは対象も保存条件も異なる。','arc2-comparison-067 領域転写':'純粋rendererは全教師でdual_region_requires_exactly_two_foreground_regions。C8混色領域数4/4/3。二領域の重心最小対応・crop出力を除くためにguardを緩める案は不適切。再利用できるのは_enclosed_non_wall_regions。','arc2-comparison-013 凡例集合':'parse_input全3教師raw_frame_unresolved（raw_frames=[]）。L枠palette集合と物体全体消去は、この有向色対応と穴充填に一致しない。','arc2-comparison-010 凡例矩形':'縦二列・左keyという既存表viewは教師0の2×5表を認識しない。教師1/2でもsourceはsolid矩形/対角二Lでなく有穴輪郭。bbox全体の不透明上書きは元壁保存と異なる。'},
'不足':'既存C8物体＋C4閉領域＋一回色joinを結ぶ入力viewが未接続。凡例のlane方向とkey側の入力だけによる一意性は未成立、とくに2×2凡例。',
'候補':{'分類':'既存primitiveの組合せ','最小候補':'whole混色C4の完全二lane表を入力から列挙し、全向きとkey側を保持。表外のwhole同色C8物体のbboxで既存C4閉領域を抽出し、全穴が元背景なら壁色を凡例keyへ一回join、対応穴のみvalueで塗る。未対応物体、壁、凡例、外背景は保存。','教師で確認済み':'C8＋上row→下row（教師0）、左col→右col（教師1）、上row→下row（教師2）はそれぞれ教師完全一致。これは教師別候補の存在であり、共有したorientation選択規則の成立ではない。','新規prior候補を明記':'二lane表の認識・方向を変える文法・未対応保存・背景穴だけ充填の組合せは提案で、HDSが学習済みとは呼ばない。'},
'反証':['C4物体抽出は教師0で7セル未充填となり教師不一致。C4穴抽出自体をC8穴へ変える根拠ではない。','教師0の逆mappingは6セル不一致、教師1逆mappingは9セル不一致。教師2の左keyは2セルの穴を6で塗り、正しい7と2セル競合。','教師2の2×2表[[2,6],[7,1]]ではrow-keyとcol-keyがともにwhole表・key一意・同じactive物体色2という入力条件を満たす。未使用keyを捨てても向きは解決しない。','orientationをteacherごとに正解で選んだだけで全教師fit、または候補の一つをqueryで落として残りを採用、と主張しない。'],
'適用範囲':'sanitized train3対のみの観測。新family不要の可能性があるが、共有候補文法と全候補合意の検証は未実施。元壁/凡例/未対応物体/対象外背景保存、未知role・異色衝突・向き競合・表複数はHOLDを維持。',
'未確認事項':['平方表の向きに対する共有teacher-learned規則。長軸lane解釈にsquare tieを加える規則は新規priorとして別途限定する必要がある。','同色物体複数、表key/value alias、背景value、他前景を含む穴、表と物体接触、背景最多同率は未検証。','保持全向きが同一完成格子に合意する条件、対照回帰、query側挙動は未確認。'],
'推奨次検査':['まず共有orientation候補を宣言し、教師ごと選択を禁止して3教師の支持/反例を記録する。square tieを任意決定しない。','既存C8抽出と_enclosed_non_wall_regionsをそのまま使うteacher-only試験で閉穴/全foreground所有/不変セルを検証する。','色置換・平行移動・表の縦横化・square曖昧対照・開口一セル・対角閉鎖・未対応色・複数同色物体を合成し、全保持modelのHOLD/合意を確認してから実装採否を判断する。'],
'証拠参照':['teacher-only-tasks.json#/dbff022c/train/0..2','teacher-measurements.json: 対象=dbff022c','teacher_diagnostics.py:hole_diagnostics (pure teacher-only)','学習台帳/ARC2規則台帳_v1.json#/規則/9,10,12,66','接続/ARC2/既存物体特徴.py:23-76','接続/ARC2/既存領域転写.py:146-177,246-330','接続/ARC2/凡例穴対応.py:5-51','接続/ARC2/凡例集合教材.py:19-102','接続/ARC2/凡例矩形教材.py:63-176']
})
(P/'dbff022c-observation.json').write_text(json.dumps(m,ensure_ascii=False,indent=2))
print('dbff022c-observation.json ready; ten fields:',list(m))
