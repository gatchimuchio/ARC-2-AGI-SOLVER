import sys,json,importlib
from pathlib import Path
P=Path(__file__).parent;R=Path('/workspace/scratch/7408259c1ab2/arc2-second-half');sys.path.insert(0,str(R))
T=json.load(open(P/'teacher-only-tasks.json'))
CHECKS={
'142ca369':[('疎点転写教材','inspect_input'),('凡例旋回教材','guarded_render')],
'195c6913':[('凡例旋回教材','guarded_render'),('成分直列教材','guarded_render')],
'247ef758':[('放射組立教材','guarded_radial_assembly'),('基点複製教材','guarded_render')],
'2b83f449':[('周期組修復教材','guarded_tuple_repair'),('凡例旋回教材','guarded_render')],
'409aa875':[('基点複製教材','guarded_render'),('疎点転写教材','inspect_input')],
'4c7dc4dd':[('周期組修復教材','guarded_tuple_repair'),('部分見本教材','guarded_panel_exemplar')],
'5961cc34':[('凡例旋回教材','guarded_render'),('成分直列教材','guarded_render')],
'6ffbe589':[('周期組修復教材','guarded_tuple_repair'),('形状色教材','guarded_template_shape_color')],
'78332cb0':[('成分直列教材','guarded_render'),('反復行教材','guarded_render')],
'88bcf3b4':[('基点複製教材','guarded_render'),('疎点転写教材','inspect_input')],
'9bbf930d':[('成分直列教材','guarded_render'),('凡例旋回教材','guarded_render')],
'a47bf94d':[('成分直列教材','guarded_render'),('凡例旋回教材','guarded_render')],
'b10624e5':[('倍率置換教材','guarded_render'),('基点複製教材','guarded_render')],
'd35bdbdc':[('成分直列教材','guarded_render'),('凡例集合教材','parse_input')],
'dfadab01':[('基点複製教材','guarded_render'),('凡例展開教材','guarded_render')],
'edb79dae':[('凡例展開教材','guarded_render'),('部分見本教材','guarded_panel_exemplar')],
'faa9f03d':[('周期組修復教材','guarded_tuple_repair'),('凡例旋回教材','guarded_render')]}
OUT=[]
for k,checks in CHECKS.items():
 rr=[]
 for mod,fn in checks:
  f=getattr(importlib.import_module('接続.ARC2.'+mod),fn);rows=[]
  for p in T[k]['train']:
   out,record=f(p['input']);rows.append({'candidate_present':out is not None,'teacher_equal':out==p['output'] if fn not in('inspect_input','parse_input')else None,'record':record})
  rr.append({'source':mod+'.py:'+fn,'teachers':rows})
 z={'対象':k,'観測':rr,'既存規則適用結果':'pure current-family input diagnostics; no HDS/query/scorer','不足':None,'候補':None,'反証':None,'適用範囲':'sanitized teachers only','未確認事項':None,'推奨次検査':None,'証拠参照':['teacher-only-tasks.json#/'+k+'/train']};OUT.append(z)
 print(k,[(r['source'],[(v['record'].get('failure')if isinstance(v['record'],dict)else str(v['record'])[:50],v['teacher_equal'])for v in r['teachers']])for r in rr])
(P/'current-family-guard-measurements.json').write_text(json.dumps(OUT,ensure_ascii=False,indent=2,default=list))
