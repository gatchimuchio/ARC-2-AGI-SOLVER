# Observation-only candidate factorization diagnostics; consumes sanitized teachers only.
import sys,json,collections,importlib
from pathlib import Path
R=Path('/workspace/scratch/7408259c1ab2/arc2-second-half');sys.path.insert(0,str(R))
from 接続.ARC2.既存領域転写 import mixed_region_dicts_for_grid
from 接続.ARC2.既存物体特徴 import color_component_dicts_for_grid
from 接続.ARC2.既存倍率置換 import compress_pattern,scaled_pattern_cells
P=Path(__file__).parent;T=json.load(open(P/'teacher-only-tasks.json'))
def quadrant_factorization(g):
 h,w=len(g),len(g[0]);counts=collections.Counter(v for row in g for v in row);bg=counts.most_common(1)[0][0]
 separators=[]
 for co in counts:
  if co==bg:continue
  rows=[r for r in range(h)if all(v==co for v in g[r])];cols=[c for c in range(w)if all(g[r][c]==co for r in range(h))]
  if len(rows)==1 and len(cols)==1:separators.append((co,rows[0],cols[0]))
 if len(separators)!=1:return None,{'failure':'separator_cross_not_unique','candidates':separators}
 sep,sr,sc=separators[0];qs=[(0,0,sr-1,sc-1),(0,sc+1,sr-1,w-1),(sr+1,0,h-1,sc-1),(sr+1,sc+1,h-1,w-1)]
 records=[]
 for i,(t,l,b,r)in enumerate(qs):
  crop=[row[l:r+1]for row in g[t:b+1]];parts=mixed_region_dicts_for_grid(crop,bg,True)
  if len(parts)!=1:return None,{'failure':'quadrant_not_one_object','quadrant':i,'count':len(parts)}
  z=parts[0];z=dict(z,q=i,origin=(t,l));records.append(z)
 sources=[x for x in records if len(x['colors'])>1]
 if len(sources)!=1:return None,{'failure':'source_not_unique'}
 src=sources[0];seeds=[x for x in records if x is not src];seedcolors={x['colors'][0]for x in seeds if len(x['colors'])==1}
 if len(seedcolors)!=1:return None,{'failure':'anchor_color_not_unique'}
 anchor=next(iter(seedcolors));t,l,b,r=src['bbox'];qtop,qleft=src['origin'];pattern=tuple(tuple(g[qtop+y][qleft+x]if(y,x)in set(src['cells']) else None for x in range(l,r+1))for y in range(t,b+1));normscale,primitive=compress_pattern(pattern)
 ph,pw=len(primitive),len(primitive[0]);out=[row[:]for row in g];details=[]
 for seed in seeds:
  st,sl,sb,srr=seed['bbox'];n=sb-st+1
  if n!=srr-sl+1 or seed['size']!=n*n:return None,{'failure':'seed_not_solid_square'}
  flipr=(seed['q']//2)!=(src['q']//2);flipc=(seed['q']%2)!=(src['q']%2)
  pp=primitive[::-1]if flipr else primitive;pp=tuple(row[::-1]for row in pp)if flipc else pp
  ac=[(r,c)for r,row in enumerate(pp)for c,v in enumerate(row)if v==anchor]
  ar0,ac0=min(r for r,c in ac),min(c for r,c in ac);ar1,ac1=max(r for r,c in ac),max(c for r,c in ac);an=ar1-ar0+1
  if an!=ac1-ac0+1 or len(ac)!=an*an or n%an:return None,{'failure':'anchor_scale_not_integer'}
  scale=n//an;top=seed['origin'][0]+st-ar0*scale;left=seed['origin'][1]+sl-ac0*scale
  cells=scaled_pattern_cells(pp,scale,top,left)
  if any(not(0<=r<h and 0<=c<w)for r,c,v in cells):return None,{'failure':'placement_out_of_bounds'}
  for r,c,v in cells:
   if g[r][c]not in(bg,anchor):return None,{'failure':'stationary_overwrite'}
   out[r][c]=v
  details.append({'quadrant':seed['q'],'flip_rows':flipr,'flip_columns':flipc,'seed_size':n,'primitive_scale':scale,'placement':[top,left],'paint_cells':len(cells)})
 return out,{'separator':separators[0],'source_quadrant':src['q'],'source_normalization_scale':normscale,'primitive_shape':[ph,pw],'anchor_color':anchor,'placements':details}
def legend_glyph_factorization(g):
 h,w=len(g),len(g[0]);bg=collections.Counter(v for row in g for v in row).most_common(1)[0][0];frames=[]
 for co in set(v for row in g for v in row)-{bg}:
  for obj in color_component_dicts_for_grid(g,co,False):
   t,l,b,r=obj['bbox'];border={(y,x)for y in range(t,b+1)for x in range(l,r+1)if y in(t,b)or x in(l,r)}
   if b-t>1 and r-l>1 and set(obj['cells'])==border:frames.append((co,t,l,b,r))
 if len(frames)!=1:return None,{'failure':'frame_not_unique','frames':frames}
 fc,t,l,b,r=frames[0];tablemap={};glyphs={};outside=[]
 for z in mixed_region_dicts_for_grid(g,bg,True):
  if any(t<=y<=b and l<=x<=r for y,x in z['cells']):continue
  outside.append(z)
  zt,zl,zb,zr=z['bbox']
  if len(z['colors'])==1:
   co=z['colors'][0]
   if co in glyphs:return None,{'failure':'duplicate_glyph_color'}
   glyphs[co]=[[g[y][x]for x in range(zl,zr+1)]for y in range(zt,zb+1)]
  elif len(z['colors'])==2 and(zb-zt+1,zr-zl+1)==(3,4):
   left={(0,0),(0,1),(1,0),(1,1),(1,2),(2,0),(2,1)};kc=g[zt][zl];vc=g[zt][zr]
   if not all(g[zt+y][zl+x]==(kc if(y,x)in left else vc)for y in range(3)for x in range(4)):return None,{'failure':'legend_arrow_geometry_invalid'}
   if kc in tablemap:return None,{'failure':'duplicate_arrow_key'}
   tablemap[kc]=vc
  else:return None,{'failure':'outside_role_unresolved'}
 out=[row[l:r+1]for row in g[t:b+1]];records=[]
 for co in sorted(set(v for row in out[1:-1]for v in row[1:-1])-{bg}):
  if co not in glyphs or co not in tablemap:return None,{'failure':'missing_legend_or_glyph','color':co}
  for ob in color_component_dicts_for_grid(out,co,True):
   ot,ol,obottom,orr=ob['bbox'];gh,gw=len(glyphs[co]),len(glyphs[co][0]);oh,ow=obottom-ot+1,orr-ol+1
   if(oh,ow)!=(gh,gw)or len(ob['cells'])!=oh*ow:return None,{'failure':'target_not_matching_solid_tile'}
   for dy in range(gh):
    for dx in range(gw):out[ot+dy][ol+dx]=tablemap[co]if glyphs[co][dy][dx]==co else bg
   records.append({'color':co,'target_bbox':list(ob['bbox']),'glyph_shape':[gh,gw],'new_color':tablemap[co]})
 return out,{'frame':frames[0],'arrow_mapping':tablemap,'glyph_shapes':{co:[len(v),len(v[0])]for co,v in glyphs.items()},'target_tiles':records}
def colour_layer_rotation(g):
 bg=collections.Counter(v for row in g for v in row).most_common(1)[0][0];parts=mixed_region_dicts_for_grid(g,bg,True);largest=max(x['size']for x in parts);scenes=[x for x in parts if x['size']==largest]
 if len(scenes)!=1:return None,{'failure':'largest_scene_tie'}
 t,l,b,r=scenes[0]['bbox'];n=b-t+1
 if n!=r-l+1:return None,{'failure':'scene_bbox_not_square'}
 # Include all foreground in the selected bbox, including detached corner cells.
 crop=[row[l:r+1]for row in g[t:b+1]];out=[[bg]*n for _ in range(n)];records=[];owned=set()
 for co in set(v for row in g for v in row)-{bg}:
  inside={(y,x)for y,row in enumerate(crop)for x,v in enumerate(row)if v==co};outside=[(y,x)for y,row in enumerate(g)for x,v in enumerate(row)if v==co and not(t<=y<=b and l<=x<=r)]
  if not inside:return None,{'failure':'outside_color_without_layer'}
  dest=inside
  for _ in range(len(outside)%4):dest={(x,n-1-y)for y,x in dest}
  if owned&dest:return None,{'failure':'rotated_layer_collision'}
  owned|=dest
  for y,x in dest:out[y][x]=co
  records.append({'color':co,'inside_pixels':len(inside),'outside_pixels':len(outside),'clockwise_quarter_turns':len(outside)%4})
 return out,{'scene_bbox':[t,l,b,r],'largest_component_pixels':largest,'bbox_foreground_pixels':len(owned),'layers':records}
def endpoint_tile_substitution(g):
 h,w=len(g),len(g[0]);bg=collections.Counter(v for row in g for v in row).most_common(1)[0][0];tiles=[];owned=set()
 for t in range(h-2):
  for l in range(w-2):
   border={(r,c)for r in range(t,t+3)for c in range(l,l+3)if r in(t,t+2)or c in(l,l+2)};colours={g[r][c]for r,c in border};center=g[t+1][l+1]
   if len(colours)==1 and bg not in colours and center!=bg and center not in colours:
    if owned&border:return None,{'failure':'overlapping_tiles'}
    co=next(iter(colours));tiles.append({'bbox':[t,l,t+2,l+2],'border_color':co,'center_color':center});owned|=border|{(t+1,l+1)}
 wire={(r,c)for r,row in enumerate(g)for c,v in enumerate(row)if v!=bg and(r,c)not in owned}
 if not wire or len({g[r][c]for r,c in wire})!=1:return None,{'failure':'wire_role_not_unique'}
 endpoints=[p for p in wire if sum((p[0]+dr,p[1]+dc)in wire for dr in(-1,0,1)for dc in(-1,0,1)if dr or dc)==1]
 if len(endpoints)!=2:return None,{'failure':'wire_endpoints_not_two','endpoints':endpoints}
 selected=[]
 for p in endpoints:
  hits=[]
  for i,z in enumerate(tiles):
   t,l,b,r=z['bbox'];border={(y,x)for y in range(t,b+1)for x in range(l,r+1)if y in(t,b)or x in(l,r)}
   if any(abs(y-p[0])+abs(x-p[1])==1 for y,x in border):hits.append(i)
  if len(hits)!=1:return None,{'failure':'endpoint_tile_not_unique','endpoint':p,'hits':hits}
  selected+=hits
 lookup={z['border_color']:z['center_color']for z in tiles}
 if len(lookup)!=len(tiles):return None,{'failure':'duplicate_tile_key'}
 out=[[bg]*w for _ in range(h)]
 for r,c in wire:out[r][c]=g[r][c]
 for i in selected:
  z=tiles[i];t,l,b,r=z['bbox']
  if z['center_color']not in lookup:return None,{'failure':'center_key_unmapped'}
  for y in range(t,b+1):
   for x in range(l,r+1):out[y][x]=g[y][x]
  out[t+1][l+1]=lookup[z['center_color']]
 return out,{'tiles':tiles,'wire_size':len(wire),'endpoints':endpoints,'selected_tiles':selected,'lookup':lookup}
allrecords=[]
for label,fn,subset in [('quadrant_reflection_scale',quadrant_factorization,['b10624e5']),('legend_glyph_replace',legend_glyph_factorization,['edb79dae']),('outside_count_layer_rotation',colour_layer_rotation,['6ffbe589']),('endpoint_tile_one_hop',endpoint_tile_substitution,['d35bdbdc'])]:
 for k in subset:
  rr=[]
  for p in T[k]['train']:
   y,d=fn(p['input']);rr.append({'teacher_equal':y==p['output'],'record':d})
  x={'対象':k,'観測':{'diagnostic':label,'teacher_results':rr},'既存規則適用結果':None,'不足':None,'候補':None,'反証':None,'適用範囲':'teacher-only factorization, not adopted solver','未確認事項':'generalized shared grammar and negative regression not tested','推奨次検査':None,'証拠参照':['teacher-only-tasks.json#/'+k+'/train']};allrecords.append(x)
(P/'composition-measurements.json').write_text(json.dumps(allrecords,ensure_ascii=False,indent=2));print(json.dumps(allrecords,ensure_ascii=False,indent=2))
