# Teacher-only observation. No task files beyond sanitized train corpus; no query/scorer calls.
import sys,json,collections,hashlib,inspect
from pathlib import Path
R=Path('/workspace/scratch/7408259c1ab2/arc2-second-half');sys.path.insert(0,str(R))
from 接続.ARC2.既存領域転写 import mixed_region_dicts_for_grid,_enclosed_non_wall_regions
from 接続.ARC2.既存物体特徴 import color_component_dicts_for_grid
from 接続.ARC2.凡例集合教材 import parse_input as set_parse
from 接続.ARC2.凡例穴対応 import 凡例穴教材
from 接続.ARC2.櫛配置教材 import render as comb_render
from 接続.ARC2.対称剪定教材 import guarded_render as prune_render
P=Path(__file__).parent
T=json.load(open(P/'teacher-only-tasks.json'))
def bb(c):return [min(r for r,c in c),min(c for r,c in c),max(r for r,c in c),max(c for r,c in c)]
def counts(g):return dict(sorted(collections.Counter(v for row in g for v in row).items()))
def stats(p):
 a,b=p['input'],p['output'];same=len(a)==len(b)and len(a[0])==len(b[0]);d=collections.Counter((a[r][c],b[r][c])for r in range(len(a))for c in range(len(a[0]))if same and a[r][c]!=b[r][c]);return {'input_shape':[len(a),len(a[0])],'output_shape':[len(b),len(b[0])],'input_colours':counts(a),'output_colours':counts(b),'changes':[[a,b,n]for(a,b),n in sorted(d.items())] if same else 'shape_changed'}
def hole_diagnostics(p, diagonal=False):
 g=p['input'];bg=max(counts(g),key=counts(g).get);regions=mixed_region_dicts_for_grid(g,bg,False);tables=[]
 for reg in regions:
  t,l,b,r=reg['bbox'];h,w=b-t+1,r-l+1
  if min(h,w)==2 and reg['size']==h*w and len(reg['colors'])>1:
   tables.append(reg)
 out={'table_candidates':[{'bbox':list(x['bbox']),'size':x['size'],'colours':x['colors']}for x in tables], 'existing_legend_set_parse':set_parse(g)[1], 'mixed_C4_region_count':len(regions),'object_connectivity':8 if diagonal else 4,'orientations':[]}
 for table in tables:
  t,l,b,r=table['bbox'];h,w=b-t+1,r-l+1;tc=set(table['cells']);modes=[]
  if h==2:
   modes += [('rows_top_key',[(g[t][c],g[b][c])for c in range(l,r+1)]),('rows_bottom_key',[(g[b][c],g[t][c])for c in range(l,r+1)])]
  if w==2:
   modes += [('cols_left_key',[(g[y][l],g[y][r])for y in range(t,b+1)]),('cols_right_key',[(g[y][r],g[y][l])for y in range(t,b+1)])]
  for name,pairs in modes:
   mapping=dict(pairs); rec={'orientation':name,'mapping':pairs,'key_unique':len(mapping)==len(pairs)}
   if len(mapping)!=len(pairs):out['orientations'].append(rec);continue
   y=[row[:]for row in g];objects=[]
   for co in sorted(set(v for row in g for v in row)-{bg}):
    for obj in color_component_dicts_for_grid(g,co,diagonal):
     if set(obj['cells'])&tc:continue
     r0,c0,r1,c1=obj['bbox'];crop=[row[c0:c1+1]for row in g[r0:r1+1]]
     holes=_enclosed_non_wall_regions(crop,co)
     holes=[[(r+r0,c+c0)for r,c in hole]for hole in holes]
     # Only input-background holes; non-background occupancy is explicit uncertainty.
     clean=all(g[r][c]==bg for hole in holes for r,c in hole)
     objects.append({'colour':co,'bbox':list(obj['bbox']),'hole_sizes':[len(x)for x in holes],'all_holes_background':clean,'mapped':co in mapping})
     if clean and co in mapping:
      for hole in holes:
       for r,c in hole:y[r][c]=mapping[co]
   rec.update(objects=objects,teacher_equal=y==p['output'],changed_cells=sum(x!=z for ar,br in zip(g,y)for x,z in zip(ar,br)),mismatched_cells=sum(x!=z for ar,br in zip(p['output'],y)for x,z in zip(ar,br)))
   out['orientations'].append(rec)
 return out
D={k:{'教師計測':[stats(p)for p in v['train']]}for k,v in T.items()}
for k,fn in [('4c3d4a41',comb_render),('8e5c0c38',prune_render)]:
 D[k]['既存候補診断']=[]
 for p in T[k]['train']:
  y,rec=fn(p['input']);D[k]['既存候補診断'].append({'teacher_equal':y==p['output'],'record':rec})
D['dbff022c']['凡例穴教材記録']=凡例穴教材(T['dbff022c']['train'],2).記録()
D['dbff022c']['二列凡例と閉穴の観測']=[{'C4_objects':hole_diagnostics(p,False),'C8_objects':hole_diagnostics(p,True)}for p in T['dbff022c']['train']]
# Reusable data stored under the required ten-field schema.
fields=['対象','観測','既存規則適用結果','不足','候補','反証','適用範囲','未確認事項','推奨次検査','証拠参照']
records=[]
for k,info in D.items():
 z=dict.fromkeys(fields,None);z.update(対象=k,観測=info,適用範囲='sanitized train only; observation, no implementation/adoption',証拠参照=['teacher-only-tasks.json#/'+k+'/train']);records.append(z)
(P/'teacher-measurements.json').write_text(json.dumps(records,ensure_ascii=False,indent=2))
print(json.dumps(D['dbff022c'],ensure_ascii=False,indent=2))
